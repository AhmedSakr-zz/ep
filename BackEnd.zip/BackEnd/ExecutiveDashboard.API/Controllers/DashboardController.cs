using ExecutiveDashboard.API.Models;
using ExecutiveDashboard.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExecutiveDashboard.API.Controllers;

[ApiController]
[Route("api/dashboard")]
[Authorize]
public class DashboardController : ControllerBase
{
    private readonly IDashboardService _dashboardService;

    public DashboardController(IDashboardService dashboardService) => _dashboardService = dashboardService;

    [HttpGet("filters")]
    public async Task<IActionResult> GetFilters()
    {
        var filters = await _dashboardService.GetFiltersAsync();
        return Ok(filters);
    }

    [HttpGet("overview")]
    public async Task<IActionResult> GetOverview(
        [FromQuery] string? departmentId, [FromQuery] string? stage,
        [FromQuery] string? timePeriod, [FromQuery] string? status,
        [FromQuery] string? priority, [FromQuery] string? investmentValueRangeId)
    {
        var overview = await _dashboardService.GetOverviewAsync(departmentId, stage, timePeriod, status, priority, investmentValueRangeId);
        return Ok(overview);
    }
}
