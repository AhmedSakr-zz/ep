using ExecutiveDashboard.API.Models;
using ExecutiveDashboard.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExecutiveDashboard.API.Controllers;

[ApiController]
[Route("api/deals")]
[Authorize]
public class DealsController : ControllerBase
{
    private readonly IDealService _dealService;

    public DealsController(IDealService dealService) => _dealService = dealService;

    [HttpGet]
    public async Task<IActionResult> GetDeals(
        [FromQuery] int page = 1, [FromQuery] int limit = 5,
        [FromQuery] string? sortBy = null, [FromQuery] string? sortOrder = "asc",
        [FromQuery] string? departmentId = null, [FromQuery] string? stage = null,
        [FromQuery] string? status = null, [FromQuery] string? priority = null,
        [FromQuery] string? investmentValueRangeId = null, [FromQuery] string? searchTerm = null)
    {
        var result = await _dealService.GetDealsAsync(page, limit, sortBy, sortOrder,
            departmentId, stage, status, priority, investmentValueRangeId, searchTerm);
        return Ok(result);
    }

    [HttpGet("{dealId}")]
    public async Task<IActionResult> GetDealById(string dealId)
    {
        var deal = await _dealService.GetDealByIdAsync(dealId);
        if (deal == null)
            return NotFound(new ErrorResponse { Error = "DEAL_NOT_FOUND", Message = $"Deal with ID '{dealId}' not found." });
        return Ok(deal);
    }
}
