using ExecutiveDashboard.API.Models;
using ExecutiveDashboard.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExecutiveDashboard.API.Controllers;

[ApiController]
[Route("api/pipeline")]
[Authorize]
public class PipelineController : ControllerBase
{
    private readonly IPipelineService _pipelineService;

    public PipelineController(IPipelineService pipelineService) => _pipelineService = pipelineService;

    [HttpGet("details")]
    public async Task<IActionResult> GetStageDetails(
        [FromQuery] string stage = "L4",
        [FromQuery] int page = 1, [FromQuery] int limit = 5)
    {
        var result = await _pipelineService.GetStageDetailsAsync(stage, page, limit);
        if (result == null)
            return BadRequest(new ErrorResponse { Error = "INVALID_STAGE", Message = "Stage must be L0-L5." });
        return Ok(result);
    }
}
