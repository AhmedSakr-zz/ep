using System.Security.Claims;
using ExecutiveDashboard.API.Models;
using ExecutiveDashboard.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ExecutiveDashboard.API.Controllers;

[ApiController]
[Route("api/users")]
[Authorize]
public class UsersController : ControllerBase
{
    private readonly IUserService _userService;

    public UsersController(IUserService userService) => _userService = userService;

    [HttpGet("profile")]
    public async Task<IActionResult> GetProfile()
    {
        var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(userId))
            return Unauthorized(new ErrorResponse { Error = "UNAUTHORIZED", Message = "User not authenticated." });

        var profile = await _userService.GetProfileAsync(userId);
        if (profile == null)
            return NotFound(new ErrorResponse { Error = "NOT_FOUND", Message = "User profile not found." });

        return Ok(profile);
    }
}
