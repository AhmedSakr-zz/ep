using ExecutiveDashboard.API.Models;

namespace ExecutiveDashboard.API.Data;

public static class MockDataStore
{
    public static List<UserProfile> Users = GenerateUsers();
    public static List<DealSummary> Deals = GenerateDeals();
    public static List<StageDeal> StageDeals = GenerateStageDeals();
    public static List<DealDetail> DealDetails = GenerateDealDetails();

    private static List<UserProfile> GenerateUsers() =>
    [
        new() { Id = "usr_001", FirstName = "Abdullah", LastName = "Al-Huzaymi", Email = "abdullah.al-huzaymi@qfz.gov.qa",
            Role = "Manager", Department = "Investment Department", AvatarUrl = null,
            Permissions = ["view_dashboard", "view_deals", "manage_deals"] },
        new() { Id = "usr_002", FirstName = "Ahmed", LastName = "Hassan", Email = "ahmed.hassan@qfz.gov.qa",
            Role = "Senior Officer", Department = "Investment Department", AvatarUrl = null,
            Permissions = ["view_dashboard", "view_deals"] },
        new() { Id = "usr_003", FirstName = "Sara", LastName = "Ali", Email = "sara.ali@qfz.gov.qa",
            Role = "Officer", Department = "Development", AvatarUrl = null,
            Permissions = ["view_dashboard", "view_deals"] },
    ];

    public static List<DealSummary> GenerateDeals()
    {
        var data = new List<DealSummary>
        {
            new() { DealId = "deal_al_noor_01", DealName = "Al Noor Industrial Complex", Department = "Investment", OwnerName = "Ahmed Hassan", Stage = "L4", StageLabel = "Construction Started", DueDate = "2026-05-19", DaysRemaining = 1, SlaStatus = "DELAYED", RequiredAction = "Review missing license document", Priority = "HIGH", CapexAmount = 220000000, CapexCurrency = "QAR", CapexLabel = "QAR 220M" },
            new() { DealId = "deal_green_valley_02", DealName = "Green Valley Tech Park", Department = "Development", OwnerName = "Sara Ali", Stage = "L2", StageLabel = "Application Approved", DueDate = "2026-05-21", DaysRemaining = 2, SlaStatus = "BLOCKED", RequiredAction = "Resolve blocked approval", Priority = "HIGH", CapexAmount = 150000000, CapexCurrency = "QAR", CapexLabel = "QAR 150M" },
            new() { DealId = "deal_sunrise_03", DealName = "Sunrise Business Hub", Department = "Marketing", OwnerName = "John Doe", Stage = "L3", StageLabel = "License Granted", DueDate = "2026-05-24", DaysRemaining = 4, SlaStatus = "PENDING", RequiredAction = "Schedule team brainstorming session", Priority = "MEDIUM", CapexAmount = 85000000, CapexCurrency = "QAR", CapexLabel = "QAR 85M" },
            new() { DealId = "deal_al_noor_04", DealName = "Al Noor Industrial Complex", Department = "Investment", OwnerName = "Ahmed Hassan", Stage = "L4", StageLabel = "Construction Started", DueDate = "2026-05-29", DaysRemaining = 4, SlaStatus = "ON_TRACK", RequiredAction = "Resolve blocked approval", Priority = "HIGH", CapexAmount = 220000000, CapexCurrency = "QAR", CapexLabel = "QAR 220M" },
            new() { DealId = "deal_blue_lagoon_05", DealName = "Blue Lagoon Workspace", Department = "Operations", OwnerName = "Lina Mansour", Stage = "L3", StageLabel = "License Granted", DueDate = "2026-05-29", DaysRemaining = 0, SlaStatus = "SLA_BREACH", RequiredAction = "Update project timeline for Q3", Priority = "HIGH", CapexAmount = 220000000, CapexCurrency = "QAR", CapexLabel = "QAR 220M" },
            new() { DealId = "deal_medina_06", DealName = "Medina Logistics Hub", Department = "Investment", OwnerName = "Khalid Al-Naimi", Stage = "L1", StageLabel = "Application Submission", DueDate = "2026-06-15", DaysRemaining = 30, SlaStatus = "ACTIVE", RequiredAction = "Initial review pending", Priority = "MEDIUM", CapexAmount = 95000000, CapexCurrency = "QAR", CapexLabel = "QAR 95M" },
            new() { DealId = "deal_west_bay_07", DealName = "West Bay Financial Tower", Department = "Development", OwnerName = "Noora Al-Mansoori", Stage = "L2", StageLabel = "Application Approved", DueDate = "2026-06-01", DaysRemaining = 16, SlaStatus = "ON_TRACK", RequiredAction = "Complete feasibility study", Priority = "HIGH", CapexAmount = 500000000, CapexCurrency = "QAR", CapexLabel = "QAR 500M" },
            new() { DealId = "deal_pearl_08", DealName = "Pearl Innovation Center", Department = "Marketing", OwnerName = "John Doe", Stage = "L3", StageLabel = "License Granted", DueDate = "2026-06-05", DaysRemaining = 20, SlaStatus = "DELAYED", RequiredAction = "Submit environmental impact assessment", Priority = "MEDIUM", CapexAmount = 175000000, CapexCurrency = "QAR", CapexLabel = "QAR 175M" },
            new() { DealId = "deal_lusail_09", DealName = "Lusail Smart City Phase 2", Department = "Investment", OwnerName = "Abdullah Al-Huzaymi", Stage = "L4", StageLabel = "Construction Started", DueDate = "2026-06-20", DaysRemaining = 35, SlaStatus = "ON_TRACK", RequiredAction = "Monitor construction progress", Priority = "LOW", CapexAmount = 780000000, CapexCurrency = "QAR", CapexLabel = "QAR 780M" },
            new() { DealId = "deal_qfz_tech_10", DealName = "QFZ Tech Park Expansion", Department = "Operations", OwnerName = "Lina Mansour", Stage = "L1", StageLabel = "Application Submission", DueDate = "2026-07-01", DaysRemaining = 46, SlaStatus = "PENDING", RequiredAction = "Awaiting board approval", Priority = "MEDIUM", CapexAmount = 320000000, CapexCurrency = "QAR", CapexLabel = "QAR 320M" },
        };

        for (int i = 11; i <= 48; i++)
        {
            var stages = new[] { "L1", "L2", "L3", "L4", "L5" };
            var depts = new[] { "Investment", "Development", "Operations", "Marketing" };
            var owners = new[] { "Ahmed Hassan", "Sara Ali", "John Doe", "Lina Mansour", "Khalid Al-Naimi", "Noora Al-Mansoori", "Fatma Elsayed", "Marco George" };
            var statuses = new[] { "ACTIVE", "DELAYED", "BLOCKED", "PENDING", "ON_TRACK", "SLA_BREACH" };
            var priorities = new[] { "HIGH", "MEDIUM", "LOW" };
            var stage = stages[i % 5];
            var random = new Random(i);
            data.Add(new DealSummary
            {
                DealId = $"deal_mock_{i:D2}", DealName = $"Project {i} - {depts[i % 4]} Initiative", Department = depts[i % 4],
                OwnerName = owners[i % 8], Stage = stage, StageLabel = GetStageLabel(stage),
                DueDate = DateTime.Now.AddDays(random.Next(0, 60)).ToString("yyyy-MM-dd"),
                DaysRemaining = random.Next(0, 60), SlaStatus = statuses[random.Next(statuses.Length)],
                RequiredAction = "Routine follow-up required", Priority = priorities[random.Next(priorities.Length)],
                CapexAmount = random.Next(10, 800) * 1000000M, CapexCurrency = "QAR", CapexLabel = $"QAR {random.Next(10, 800)}M"
            });
        }
        return data;
    }

    private static string GetStageLabel(string stage) => stage switch
    {
        "L1" => "Application Submission", "L2" => "Application Approved",
        "L3" => "License Granted", "L4" => "Construction Started",
        "L5" => "Construction Completed", _ => stage
    };

    private static List<StageDeal> GenerateStageDeals()
    {
        var data = new List<StageDeal>
        {
            new() { DealId = "deal_anablon_11", DealName = "Anablon Biotech Production", OwnerName = "Fatma Elsayed Qassem", CapexAmount = 174700000, CapexCurrency = "QAR", CapexLabel = "QAR 174.7M", CurrentStage = "L3", CurrentStageLabel = "License Granted", ForecastDate = "2026-05-19", DealStatus = "ACTIVE", LandSizeSqm = null, PowerDemandMw = 3.35m },
            new() { DealId = "deal_air_liquide_12", DealName = "Air Liquide Maritime", OwnerName = "Menna Alaa Hanafi", CapexAmount = 65100000, CapexCurrency = "QAR", CapexLabel = "QAR 65.1M", CurrentStage = "L3", CurrentStageLabel = "License Granted", ForecastDate = "2026-05-21", DealStatus = "ACTIVE", LandSizeSqm = 22592, PowerDemandMw = null },
            new() { DealId = "deal_apex_water_13", DealName = "Apex Water Solutions and Service", OwnerName = "Marco George Zikri", CapexAmount = 54600000, CapexCurrency = "QAR", CapexLabel = "QAR 54.6M", CurrentStage = "L3", CurrentStageLabel = "License Granted", ForecastDate = "2026-05-24", DealStatus = "ACTIVE", LandSizeSqm = 10361, PowerDemandMw = 0.63m },
            new() { DealId = "deal_gulf_green_14", DealName = "Gulf Green", OwnerName = "Reem Salehman Ali", CapexAmount = 10000000, CapexCurrency = "QAR", CapexLabel = "QAR 10M", CurrentStage = "L3", CurrentStageLabel = "License Granted", ForecastDate = "2026-05-29", DealStatus = "ACTIVE", LandSizeSqm = 30740, PowerDemandMw = null },
            new() { DealId = "deal_bin_juamh_15", DealName = "Bin Juamh Soft Drinks", OwnerName = "Mokhtar Gamal Mukhtar", CapexAmount = 6500000, CapexCurrency = "QAR", CapexLabel = "QAR 6.5M", CurrentStage = "L3", CurrentStageLabel = "License Granted", ForecastDate = "2026-05-29", DealStatus = "ACTIVE", LandSizeSqm = 26958, PowerDemandMw = 0.63m },
        };

        for (int i = 16; i <= 48; i++)
        {
            var random = new Random(i);
            data.Add(new StageDeal
            {
                DealId = $"deal_mock_{i:D2}", DealName = $"Stage Deal Project {i}", OwnerName = $"Owner {i}",
                CapexAmount = random.Next(5, 500) * 1000000M, CapexCurrency = "QAR", CapexLabel = $"QAR {random.Next(5, 500)}M",
                CurrentStage = "L3", CurrentStageLabel = "License Granted",
                ForecastDate = DateTime.Now.AddDays(random.Next(1, 60)).ToString("yyyy-MM-dd"),
                DealStatus = "ACTIVE", LandSizeSqm = random.Next(0, 50000), PowerDemandMw = random.Next(0, 20)
            });
        }
        return data;
    }

    private static List<DealDetail> GenerateDealDetails()
    {
        var details = new List<DealDetail>();
        foreach (var deal in Deals)
        {
            var r = new Random(deal.DealId.GetHashCode());
            var assetTypes = new[] { "Industrial", "Technology", "Logistics", "Commercial", "Mixed-Use", "Manufacturing", "Warehousing", "Office" };
            var speakers = new[] { "Ministry of Commerce", "Ministry of Energy", "Ministry of Transport", "QFZA Board", "Investment Promotion Agency" };
            var situations = new Dictionary<string, string>
            {
                ["ACTIVE"] = "All documentation is in order. The application is being processed according to standard procedure.",
                ["DELAYED"] = "Infrastructure approval is delayed due to pending environmental clearance.",
                ["BLOCKED"] = "A cross-departmental approval is currently blocked pending clarification from the investor.",
                ["PENDING"] = "Awaiting additional documentation from the investor before proceeding to the next stage.",
                ["ON_TRACK"] = "The project is progressing as planned. All milestones are being met on schedule.",
                ["SLA_BREACH"] = "SLA has been breached. Escalation to DO management has been initiated."
            };
            var stages = GenerateDefaultStages(deal.Stage);

            details.Add(new DealDetail
            {
                DealId = deal.DealId,
                DealName = deal.DealName,
                SlaStatus = deal.SlaStatus,
                LastUpdated = DateTime.UtcNow.AddDays(-r.Next(1, 10)),
                CurrentStage = deal.Stage,
                CurrentStageLabel = deal.StageLabel,
                Stages = stages,
                Reviewer = new ReviewerInfo
                {
                    Name = new[] { "Abdullah Al-Huzaymi", "Khalid Al-Naimi", "Noora Al-Mansoori", "Fatma Elsayed" }[r.Next(4)],
                    Department = deal.Department
                },
                Overview = new DealOverview
                {
                    CompanyOverview = $"{deal.DealName} is a flagship initiative under {deal.Department} department. The company has a strong track record and is looking to establish a significant presence in Qatar's free zone ecosystem. This investment aligns with Qatar National Vision 2030 goals of economic diversification.",
                    ProjectOverview = $"The project involves the development of a {assetTypes[r.Next(assetTypes.Length)].ToLower()} facility spanning approximately {r.Next(10, 100)} hectares. The facility will incorporate sustainable design principles and cutting-edge technology to ensure operational excellence."
                },
                InvestmentDetails = new InvestmentDetails
                {
                    Status = "Active",
                    DealOwner = deal.OwnerName,
                    AssetType = assetTypes[r.Next(assetTypes.Length)],
                    FreeZone = "QFZA",
                    NationalSpeaker = speakers[r.Next(speakers.Length)],
                    DealCapex = new MoneyValue { Amount = deal.CapexAmount ?? 0, Currency = deal.CapexCurrency, Label = deal.CapexLabel ?? "" },
                    QfzCapex = new MoneyValue { Amount = (deal.CapexAmount ?? 0) * (r.Next(80, 100)) / 100, Currency = deal.CapexCurrency, Label = $"QAR {(deal.CapexAmount ?? 0) * (r.Next(80, 100)) / 100 / 1000000}M" },
                    LandSizeSqm = r.Next(5000, 100000),
                    LandSizeLabel = $"{r.Next(5, 100):N0} sqm",
                    PowerDemandMw = r.Next(1, 50),
                    PowerDemandLabel = $"{r.Next(1, 50)} MW"
                },
                InvestmentStatusUpdate = new StatusUpdate
                {
                    Status = deal.SlaStatus,
                    CurrentSituation = situations.GetValueOrDefault(deal.SlaStatus, "Processing according to standard procedures.")
                },
                ActionableNextSteps = new ActionableSteps
                {
                    TargetDate = deal.DueDate ?? DateTime.Now.AddDays(r.Next(7, 90)).ToString("yyyy-MM-dd"),
                    Steps =
                    [
                        "Complete required documentation for the next stage.",
                        "Coordinate with relevant government entities for approvals.",
                        "Schedule investor meeting to discuss project timeline.",
                        "Update project financial model with latest projections."
                    ]
                },
                Milestones = new MilestoneInfo
                {
                    LastContactWithInvestor = DateTime.Now.AddDays(-r.Next(3, 30)).ToString("yyyy-MM-dd"),
                    NextContactWithInvestor = DateTime.Now.AddDays(r.Next(1, 14)).ToString("yyyy-MM-dd"),
                    CompletionDateOfPreviousStage = DateTime.Now.AddDays(-r.Next(15, 60)).ToString("yyyy-MM-dd"),
                    TargetDateToNextStage = deal.DueDate ?? DateTime.Now.AddDays(r.Next(15, 90)).ToString("yyyy-MM-dd"),
                    TargetDateToL3OrL4 = deal.Stage is "L1" or "L2"
                        ? DateTime.Now.AddDays(r.Next(30, 120)).ToString("yyyy-MM-dd")
                        : DateTime.Now.AddDays(r.Next(15, 60)).ToString("yyyy-MM-dd")
                },
                Notes = deal.Stage is "L1" or "L2"
                    ? "Target date to L3 for deals in early stages."
                    : "Target date to L4 for deals in later stages."
            });
        }
        return details;
    }

    private static List<StageProgress> GenerateDefaultStages(string currentStage)
    {
        var allStages = new[] { "L1", "L2", "L3", "L4", "L5" };
        var labels = new[] { "Application Submission", "Application Approved", "License Granted", "Construction Started", "Construction Completed" };
        var result = new List<StageProgress>();
        bool passed = true;
        for (int i = 0; i < allStages.Length; i++)
        {
            string status;
            if (allStages[i] == currentStage) { status = "ACTIVE"; passed = false; }
            else if (passed) status = "COMPLETED";
            else status = "UPCOMING";
            result.Add(new StageProgress { Stage = allStages[i], Label = labels[i], Status = status });
        }
        return result;
    }

}
