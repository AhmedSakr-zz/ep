namespace ExecutiveDashboard.API.Models;

public class UserProfile
{
    public string Id { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string? AvatarUrl { get; set; }
    public List<string> Permissions { get; set; } = [];
}
