namespace ExecutiveDashboard.API.Models;

public class PipelineStageDetail
{
    public string Stage { get; set; } = string.Empty;
    public string StageLabel { get; set; } = string.Empty;
    public string? SubLabel { get; set; }
    public DateTime LastUpdated { get; set; }
    public StageSummaryMetrics SummaryMetrics { get; set; } = new();
    public List<StageDeal> Deals { get; set; } = [];
    public PaginationInfo Pagination { get; set; } = new();
}

public class StageSummaryMetrics
{
    public decimal PipelineValue { get; set; }
    public string? PipelineValueLabel { get; set; }
    public decimal Target { get; set; }
    public string? TargetLabel { get; set; }
    public decimal ProgressPercentage { get; set; }
}

public class StageDeal
{
    public string DealId { get; set; } = string.Empty;
    public string DealName { get; set; } = string.Empty;
    public string OwnerName { get; set; } = string.Empty;
    public string? OwnerAvatar { get; set; }
    public decimal? CapexAmount { get; set; }
    public string CapexCurrency { get; set; } = "QAR";
    public string? CapexLabel { get; set; }
    public string CurrentStage { get; set; } = string.Empty;
    public string CurrentStageLabel { get; set; } = string.Empty;
    public string? ForecastDate { get; set; }
    public string DealStatus { get; set; } = string.Empty;
    public decimal? LandSizeSqm { get; set; }
    public decimal? PowerDemandMw { get; set; }
}
