namespace ExecutiveDashboard.API.Models;

public class FilterOptions
{
    public List<FilterItem> Departments { get; set; } = [];
    public List<FilterItem> Stages { get; set; } = [];
    public List<FilterItem> Statuses { get; set; } = [];
    public List<FilterItem> Priorities { get; set; } = [];
    public List<InvestmentValueRange> InvestmentValueRanges { get; set; } = [];
    public List<FilterItem> TimePeriods { get; set; } = [];
}

public class FilterItem
{
    public string Id { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string? Name { get; set; }
}

public class InvestmentValueRange
{
    public string Id { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public decimal? Min { get; set; }
    public decimal? Max { get; set; }
}

public class DashboardOverview
{
    public DateTime LastUpdated { get; set; }
    public KeyMetrics KeyMetrics { get; set; } = new();
    public PipelineSummary Pipeline { get; set; } = new();
    public InvestmentForecast InvestmentValueForecast { get; set; } = new();
    public TargetHealth TargetHealth { get; set; } = new();
}

public class KeyMetrics
{
    public MetricValue L3VsTarget { get; set; } = new();
    public MetricValue L4VsTarget { get; set; } = new();
    public LicensesAchievement LicensesAchievement { get; set; } = new();
    public DealsRequiringAction DealsRequiringActions { get; set; } = new();
}

public class MetricValue
{
    public decimal Value { get; set; }
    public string Currency { get; set; } = "USD";
    public string ValueLabel { get; set; } = string.Empty;
    public decimal Target { get; set; }
    public string TargetLabel { get; set; } = string.Empty;
    public decimal Target2027 { get; set; }
    public string Target2027Label { get; set; } = string.Empty;
    public decimal Percentage { get; set; }
    public decimal GrowthVsLastQuarter { get; set; }
}

public class LicensesAchievement
{
    public int Achieved { get; set; }
    public int Target { get; set; }
    public int VarianceVsLastQuarter { get; set; }
    public string VarianceLabel { get; set; } = string.Empty;
}

public class DealsRequiringAction
{
    public int Total { get; set; }
    public int BreachedCount { get; set; }
    public int AtRiskCount { get; set; }
    public int PendingCount { get; set; }
}

public class PipelineSummary
{
    public int TotalDeals { get; set; }
    public decimal TotalValue { get; set; }
    public string TotalCurrency { get; set; } = "USD";
    public string TotalValueLabel { get; set; } = string.Empty;
    public List<StageInfo> Stages { get; set; } = [];
}

public class StageInfo
{
    public string Stage { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public int DealCount { get; set; }
    public int GrowthCountVsLastMonth { get; set; }
    public decimal Value { get; set; }
    public string ValueLabel { get; set; } = string.Empty;
}

public class InvestmentForecast
{
    public string L3ActualValue { get; set; } = string.Empty;
    public string L3PipelineValue { get; set; } = string.Empty;
    public string L4ActualValue { get; set; } = string.Empty;
    public string L4PipelineValue { get; set; } = string.Empty;
    public decimal CombinedForecastValue { get; set; }
    public string CombinedForecastLabel { get; set; } = string.Empty;
    public decimal GrowthPercentage { get; set; }
    public List<QuarterlyForecast> QuarterlyBreakdown { get; set; } = [];
}

public class QuarterlyForecast
{
    public string Quarter { get; set; } = string.Empty;
    public decimal L3ForecastValue { get; set; }
    public decimal L3ForecastDelayedValue { get; set; }
    public decimal L3ForecastOnTrackValue { get; set; }
    public decimal L3ForecastNeedAttentionValue { get; set; }
    public decimal L4ForecastValue { get; set; }
    public decimal L4ForecastDelayedValue { get; set; }
    public decimal L4ForecastOnTrackValue { get; set; }
    public decimal L4ForecastNeedAttentionValue { get; set; }
}

public class TargetHealth
{
    public TargetHealthMetric L3 { get; set; } = new();
    public TargetHealthMetric L4 { get; set; } = new();
}

public class TargetHealthMetric
{
    public decimal AchievedPercentage { get; set; }
    public decimal CurrentProgress { get; set; }
    public string CurrentProgressLabel { get; set; } = string.Empty;
    public decimal AnnualTarget { get; set; }
    public string AnnualTargetLabel { get; set; } = string.Empty;
    public decimal ForecastedValue { get; set; }
    public string ForecastedValueLabel { get; set; } = string.Empty;
    public decimal RemainingGap { get; set; }
    public string RemainingGapLabel { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string StatusText { get; set; } = string.Empty;
}
