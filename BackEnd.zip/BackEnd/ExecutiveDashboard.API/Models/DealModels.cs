namespace ExecutiveDashboard.API.Models;

public class DealSummary
{
    public string DealId { get; set; } = string.Empty;
    public string RequestNumber { get; set; } = string.Empty;
    public string DealName { get; set; } = string.Empty;
    public string Requester { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string OwnerName { get; set; } = string.Empty;
    public string? OwnerAvatar { get; set; }
    public string Stage { get; set; } = string.Empty;
    public string StageLabel { get; set; } = string.Empty;
    public string? DueDate { get; set; }
    public int DaysRemaining { get; set; }
    public string SlaStatus { get; set; } = string.Empty;
    public string? RequiredAction { get; set; }
    public string Priority { get; set; } = string.Empty;
    public decimal? CapexAmount { get; set; }
    public string CapexCurrency { get; set; } = "QAR";
    public string? CapexLabel { get; set; }
    public string State { get; set; } = string.Empty;
    public string InternalStatus { get; set; } = string.Empty;
    public string ProcessTemplate { get; set; } = string.Empty;


}

public class DealDetail
{
    public string DealId { get; set; } = string.Empty;
    public string DealName { get; set; } = string.Empty;
    public string SlaStatus { get; set; } = string.Empty;
    public DateTime LastUpdated { get; set; }
    public string CurrentStage { get; set; } = string.Empty;
    public string CurrentStageLabel { get; set; } = string.Empty;
    public List<StageProgress> Stages { get; set; } = [];
    public ReviewerInfo Reviewer { get; set; } = new();
    public DealOverview Overview { get; set; } = new();
    public InvestmentDetails InvestmentDetails { get; set; } = new();
    public StatusUpdate InvestmentStatusUpdate { get; set; } = new();
    public ActionableSteps ActionableNextSteps { get; set; } = new();
    public MilestoneInfo Milestones { get; set; } = new();
    public string? Notes { get; set; }
}

public class StageProgress
{
    public string Stage { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
}

public class ReviewerInfo
{
    public string Name { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string? AvatarUrl { get; set; }
}

public class DealOverview
{
    public string CompanyOverview { get; set; } = string.Empty;
    public string ProjectOverview { get; set; } = string.Empty;
}

public class InvestmentDetails
{
    public string Status { get; set; } = string.Empty;
    public string DealOwner { get; set; } = string.Empty;
    public string AssetType { get; set; } = string.Empty;
    public decimal? FirmSizeSqm { get; set; }
    public string? FirmSizeLabel { get; set; }
    public MoneyValue DealCapex { get; set; } = new();
    public MoneyValue QfzCapex { get; set; } = new();
}

public class MoneyValue
{
    public decimal Amount { get; set; }
    public string Currency { get; set; } = "QAR";
    public string Label { get; set; } = string.Empty;
}

public class StatusUpdate
{
    public string Status { get; set; } = string.Empty;
    public string CurrentSituation { get; set; } = string.Empty;
    public string? ActionCategory { get; set; }
    public string? ActionableNextStep { get; set; }
    public string? KeyChallenges { get; set; }
}

public class ActionableSteps
{
    public string TargetDate { get; set; } = string.Empty;
    public List<string> Steps { get; set; } = [];
    public string? Source { get; set; }
}

public class MilestoneInfo
{
    public string? LastContactWithInvestor { get; set; }
    public string? NextContactWithInvestor { get; set; }
    public string? CompletionDateOfPreviousStage { get; set; }
    public string? TargetDateToNextStage { get; set; }
    public string? TargetDateToL3OrL4 { get; set; }
}
