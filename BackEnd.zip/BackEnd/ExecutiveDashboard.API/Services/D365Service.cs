using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.Extensions.Options;

namespace ExecutiveDashboard.API.Services;

public class D365Options
{
    public string TenantId { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
    public string OrganizationUrl { get; set; } = string.Empty;
    public string WebApiBase { get; set; } = string.Empty;
}

public interface ID365Service
{
    Task<string?> GetAccessTokenAsync();
    Task<JsonElement> GetAsync(string path);
    Task<JsonElement> GetListAsync(string entitySet, string query);
    Task<JsonElement?> GetFirstAsync(string entitySet, string filter);
    string? GetString(JsonElement el, string property);
    decimal? GetDecimal(JsonElement el, string property);
    int? GetInt(JsonElement el, string property);
    bool? GetBool(JsonElement el, string property);
    List<JsonElement> GetValueArray(JsonElement response);
    string? GetFormattedValue(JsonElement el, string property);
    Guid? GetGuid(JsonElement el, string property);
    DateTime? GetDateTime(JsonElement el, string property);
    string? GetNestedString(JsonElement el, string expandProperty, string innerProperty);
    Guid? GetNestedGuid(JsonElement el, string expandProperty, string innerProperty);
}

public class D365Service : ID365Service
{
    private readonly D365Options _options;
    private readonly HttpClient _http;
    private string? _cachedToken;
    private DateTime _tokenExpiry = DateTime.MinValue;

    public D365Service(IOptions<D365Options> options)
    {
        _options = options.Value;
        _http = new HttpClient();
        _options.WebApiBase = $"{_options.OrganizationUrl.TrimEnd('/')}/api/data/v9.0/";
    }

    public async Task<string?> GetAccessTokenAsync()
    {
        try { 
        if (!string.IsNullOrEmpty(_cachedToken) && DateTime.UtcNow < _tokenExpiry)
            return _cachedToken;

        var tokenUrl = $"https://login.microsoftonline.com/{_options.TenantId}/oauth2/token";
        var body = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_id"] = _options.ClientId,
            ["client_secret"] = _options.ClientSecret,
            ["resource"] = _options.OrganizationUrl,
            ["grant_type"] = "client_credentials"
        });

        var response = await _http.PostAsync(tokenUrl, body);
        response.EnsureSuccessStatusCode();
        var json = await response.Content.ReadFromJsonAsync<JsonElement>();
        _cachedToken = json.GetProperty("access_token").GetString();
        var expiresIn = json.GetProperty("expires_in").ValueKind == JsonValueKind.Number
            ? json.GetProperty("expires_in").GetInt32()
            : int.Parse(json.GetProperty("expires_in").GetString()!);
        _tokenExpiry = DateTime.UtcNow.AddSeconds(expiresIn - 60);
        return _cachedToken;
        }
        catch
        {
            throw;
        }
    }

    public async Task<JsonElement> GetAsync(string path)
    {
        var token = await GetAccessTokenAsync();
        var request = new HttpRequestMessage(HttpMethod.Get, $"{_options.WebApiBase}{path}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Headers.Add("OData-Version", "4.0");
        request.Headers.Add("OData-MaxVersion", "4.0");
        request.Headers.Add("Prefer", "odata.include-annotations=\"*\"");

        var response = await _http.SendAsync(request);
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<JsonElement>();
    }

    public async Task<JsonElement> GetListAsync(string entitySet, string query)
    {
        return await GetAsync($"{entitySet}?{query}");
    }

    public async Task<JsonElement?> GetFirstAsync(string entitySet, string filter)
    {
        var json = await GetListAsync(entitySet, $"$top=1&$filter={filter}");
        var arr = GetValueArray(json);
        return arr.Count > 0 ? arr[0] : null;
    }

    public List<JsonElement> GetValueArray(JsonElement response)
    {
        if (response.TryGetProperty("value", out var value) && value.ValueKind == JsonValueKind.Array)
            return value.EnumerateArray().ToList();
        return [];
    }

    public string? GetString(JsonElement el, string property)
    {
        if (el.TryGetProperty(property, out var val) && val.ValueKind == JsonValueKind.String)
            return val.GetString();
        return null;
    }

    public decimal? GetDecimal(JsonElement el, string property)
    {
        if (el.TryGetProperty(property, out var val))
        {
            if (val.ValueKind == JsonValueKind.Number) return val.GetDecimal();
            if (val.ValueKind == JsonValueKind.String && decimal.TryParse(val.GetString(), out var d)) return d;
        }
        return null;
    }

    public int? GetInt(JsonElement el, string property)
    {
        if (el.TryGetProperty(property, out var val))
        {
            if (val.ValueKind == JsonValueKind.Number) return val.GetInt32();
            if (val.ValueKind == JsonValueKind.String && int.TryParse(val.GetString(), out var i)) return i;
        }
        return null;
    }

    public bool? GetBool(JsonElement el, string property)
    {
        if (el.TryGetProperty(property, out var val))
        {
            if (val.ValueKind == JsonValueKind.True) return true;
            if (val.ValueKind == JsonValueKind.False) return false;
        }
        return null;
    }

    public string? GetFormattedValue(JsonElement el, string property)
    {
        var formatted = $"{property}@OData.Community.Display.V1.FormattedValue";
        if (el.TryGetProperty(formatted, out var fv) && fv.ValueKind == JsonValueKind.String)
            return fv.GetString();
        return GetString(el, property);
    }

    public Guid? GetGuid(JsonElement el, string property)
    {
        var s = GetString(el, property);
        if (s != null && Guid.TryParse(s, out var g)) return g;
        return null;
    }

    public DateTime? GetDateTime(JsonElement el, string property)
    {
        var s = GetString(el, property);
        if (s != null && DateTime.TryParse(s, out var dt)) return dt;
        return null;
    }

    public string? GetNestedString(JsonElement el, string expandProperty, string innerProperty)
    {
        if (el.TryGetProperty(expandProperty, out var nested) && nested.ValueKind == JsonValueKind.Object)
        {
            if (nested.TryGetProperty(innerProperty, out var val) && val.ValueKind == JsonValueKind.String)
                return val.GetString();
        }
        return null;
    }

    public Guid? GetNestedGuid(JsonElement el, string expandProperty, string innerProperty)
    {
        var s = GetNestedString(el, expandProperty, innerProperty);
        if (s != null && Guid.TryParse(s, out var g)) return g;
        return null;
    }
}
