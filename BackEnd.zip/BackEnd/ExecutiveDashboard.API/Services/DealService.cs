using System.Text.Json;
using ExecutiveDashboard.API.Models;

namespace ExecutiveDashboard.API.Services;

public interface IDealService
{
    Task<PaginatedResponse<DealSummary>> GetDealsAsync(int page, int limit, string? sortBy, string? sortOrder,
        string? departmentId, string? stage, string? status, string? priority, string? investmentValueRangeId, string? searchTerm);
    Task<DealDetail?> GetDealByIdAsync(string dealId);
}

public class DealService : IDealService
{
    private readonly ID365Service _d365;

    private static readonly Dictionary<int, string> SlaStatusMap = new()
    {
        [0] = "PENDING",
        [1] = "ON_TRACK",
        [2] = "ACTIVE",
        [3] = "DELAYED",
        [4] = "SLA_BREACH"
    };


    public DealService(ID365Service d365)
    {
        _d365 = d365;
    }

    // Deals Requiring Attention: open (qfza_actionstatus eq 401820000) action tracker steps, each
    // representing one deal in progress. Request Number/Deal Name come from the linked request and
    // the step itself; DealId stays the request's own ID so "view details" still resolves via
    // GetDealByIdAsync -> GetRequestDealDetailAsync.
    public async Task<PaginatedResponse<DealSummary>> GetDealsAsync(int page, int limit, string? sortBy, string? sortOrder,
        string? departmentId, string? stage, string? status, string? priority, string? investmentValueRangeId, string? searchTerm)
    {
        try
        {
            var json = await _d365.GetListAsync("qfza_actiontrackerstepses",
                "$expand=modifiedby($select=fullname),qfza_requestid($select=hexa_name)" +
                "&$filter=qfza_actionstatus eq 401820000" +
                "&$top=5000");
            var allDeals = _d365.GetValueArray(json).Select(ToDealSummaryFromActionTrackerStep).ToList();

            var totalItems = allDeals.Count;
            var totalPages = totalItems > 0 ? (int)Math.Ceiling((double)totalItems / limit) : 1;
            var skip = (page - 1) * limit;
            var pagedDeals = allDeals.Skip(skip).Take(limit).ToList();

            return new PaginatedResponse<DealSummary>
            {
                Data = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = totalItems, TotalPages = totalPages,
                    CurrentPage = page, ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return new PaginatedResponse<DealSummary>
            {
                Data = [],
                Pagination = new PaginationInfo { TotalItems = 0, TotalPages = 0, CurrentPage = page, ItemsPerPage = limit }
            };
        }
    }

    private DealSummary ToDealSummaryFromActionTrackerStep(JsonElement r)
    {
        var pipelineCode = _d365.GetInt(r, "qfza_pipeline");
        var (stage, stageLabel) = pipelineCode.HasValue && PipelineStageMap.TryGetValue(pipelineCode.Value, out var mapped)
            ? mapped
            : ("", "");

        return new DealSummary
        {
            DealId = StripBraces(_d365.GetNestedGuid(r, "qfza_requestid", "hexa_requestid")?.ToString() ?? ""),
            RequestNumber = _d365.GetNestedString(r, "qfza_requestid", "hexa_name") ?? "",
            DealName = _d365.GetString(r, "qfza_stepname") ?? "",
            Requester = _d365.GetNestedString(r, "modifiedby", "fullname") ?? "",
            Stage = stage,
            StageLabel = stageLabel,
        };
    }

    private static readonly Dictionary<int, (string Stage, string Label)> PipelineStageMap = new()
    {
        [401820000] = ("L0", "PreApplication Created"),
        [401820001] = ("L1", "Application Submission"),
        [401820002] = ("L2", "Application Approved"),
        [401820003] = ("L3", "License Granted"),
        [401820004] = ("L4", "Construction Started"),
        [401820005] = ("L5", "Construction Completed"),
    };

    // qfza_actionstatus optionset: Completed = 401820005, Cancelled = 401820007. Any other value
    // (Need Attention, On Hold, No Response, Escalated, In Progress, Awaiting Customer) counts as "open".
    private const int ActionStatusCompleted = 401820005;
    private const int ActionStatusCancelled = 401820007;

    private static readonly int[] PipelineCodesInOrder =
        [401820000, 401820001, 401820002, 401820003, 401820004, 401820005];

    private class AccountPipelineResult
    {
        public List<StageProgress> Stages { get; set; } = [];
        public string CurrentStage { get; set; } = "";
        public string CurrentStageLabel { get; set; } = "";
        public Guid? MasterStepId { get; set; }
    }

    // Master Action Tracker Steps against an account: for each pipeline stage (qfza_pipeline), the
    // stage is COMPLETED only if every step tagged with that stage has qfza_actionstatus = Completed;
    // if any step is still open the stage is ACTIVE (in progress); if the account has no step at all
    // for that stage yet, it's UPCOMING. The "master" step (fed into the action tracker lookup below)
    // is whichever open step was modified most recently - the one currently being worked.
    private async Task<AccountPipelineResult?> FetchAccountPipelineDataAsync(Guid accountId)
    {
        try
        {
            var json = await _d365.GetListAsync("qfza_actiontrackerstepses",
                "$select=qfza_actiontrackerstepsid,qfza_pipeline,qfza_actionstatus,modifiedon"
                + $"&$filter=_qfza_accountid_value eq {accountId:D}");
            var steps = _d365.GetValueArray(json)
                .Select(s => new
                {
                    Id = _d365.GetGuid(s, "qfza_actiontrackerstepsid"),
                    Pipeline = _d365.GetInt(s, "qfza_pipeline"),
                    Status = _d365.GetInt(s, "qfza_actionstatus"),
                    Modified = _d365.GetDateTime(s, "modifiedon") ?? DateTime.MinValue
                })
                .Where(s => s.Id.HasValue && s.Pipeline.HasValue)
                .ToList();

            if (steps.Count == 0) return null;

            var byPipeline = steps.GroupBy(s => s.Pipeline!.Value).ToDictionary(g => g.Key, g => g.ToList());

            var stageStatuses = new Dictionary<string, string>();
            foreach (var code in PipelineCodesInOrder)
            {
                var (stageKey, _) = PipelineStageMap[code];
                stageStatuses[stageKey] = !byPipeline.TryGetValue(code, out var group) || group.Count == 0
                    ? "UPCOMING"
                    : group.All(s => s.Status == ActionStatusCompleted) ? "COMPLETED" : "ACTIVE";
            }

            var stageOrder = PipelineCodesInOrder.Select(c => PipelineStageMap[c].Stage).ToArray();
            var currentStage = stageOrder.Reverse().FirstOrDefault(s => stageStatuses[s] == "ACTIVE")
                ?? stageOrder.Reverse().FirstOrDefault(s => stageStatuses[s] == "COMPLETED");

            var stages = stageOrder
                .Select(s => new StageProgress { Stage = s, Label = StageDisplayLabelsForDeal[s], Status = stageStatuses[s] })
                .ToList();

            var openSteps = steps
                .Where(s => s.Status.HasValue && s.Status != ActionStatusCompleted && s.Status != ActionStatusCancelled)
                .OrderByDescending(s => s.Modified)
                .ToList();
            var masterStepId = openSteps.Count > 0
                ? openSteps[0].Id
                : steps.OrderByDescending(s => s.Modified).FirstOrDefault()?.Id;

            return new AccountPipelineResult
            {
                Stages = stages,
                CurrentStage = currentStage ?? "",
                CurrentStageLabel = currentStage != null ? StageDisplayLabelsForDeal.GetValueOrDefault(currentStage, "") : "",
                MasterStepId = masterStepId
            };
        }
        catch
        {
            return null;
        }
    }

    private static readonly Dictionary<string, string> StageDisplayLabelsForDeal = new()
    {
        ["L0"] = "PreApplication Created",
        ["L1"] = "Application Submission", ["L2"] = "Application Approved",
        ["L3"] = "License Granted", ["L4"] = "Construction Started",
        ["L5"] = "Construction Completed"
    };

    // Action Tracker rows tied to the account's currently active ("master") action tracker step:
    // Current Situation, Action Category, Actionable Next Step, Key Challenges, Last/Next contact.
    // A step can have more than one qfza_actiontrackers row - all of them are returned (most recently
    // modified first), not just one merged/latest record.
    private async Task<List<JsonElement>> FetchActionTrackersAsync(Guid stepId)
    {
        try
        {
            var json = await _d365.GetListAsync("qfza_actiontrackers",
                $"$filter=_qfza_actiontrackerstepid_value eq {stepId:D}"
                + "&$orderby=modifiedon desc");
            return _d365.GetValueArray(json);
        }
        catch
        {
            return [];
        }
    }

    // qfza_issuecategorycode optionset - drives the "Current Situation" grid column.
    private static readonly Dictionary<int, string> IssueCategoryLabels = new()
    {
        [401820000] = "Establishing demand",
        [401820001] = "Restricted activities",
        [401820002] = "Loan",
        [401820003] = "Insufficient utilities",
        [401820004] = "Asset reservation delay",
        [401820005] = "UBO due diligence",
        [401820006] = "Financial due diligence",
        [401820007] = "Approval process",
        [401820008] = "Registration process",
        [401820009] = "Leasing process",
        [401820010] = "Payment process",
        [401820011] = "Notice of Default",
        [401820012] = "Immigration",
        [401820013] = "Shareholder Change",
        [401820014] = "Activities (add, remove, amend)",
        [401820015] = "Scheme Update",
        [401820016] = "Asset Readiness & Maintenance Delays",
        [401820017] = "Renewal of Tiered License",
        [401820018] = "Rent Addendum",
        [401820019] = "External Permits",
    };

    // qfza_actioncategorycode optionset - drives the "Action Category" grid column.
    private static readonly Dictionary<int, string> ActionCategoryLabels = new()
    {
        [401820000] = "Engage stakeholders",
        [401820001] = "Engage QDB/Banks",
        [401820002] = "Secure funding to develop land",
        [401820003] = "Provide clear advice to investor on permits",
        [401820004] = "Faster estimation of timeline & cost for asset readiness",
        [401820005] = "Pre-approval from CEO to issue land proposal",
        [401820006] = "Meet investor to discuss missing details",
        [401820007] = "Approving authority (CEO/TSC)",
        [401820008] = "Approve undertaking letter",
        [401820009] = "Penalty or cancellation of approved deal",
        [401820010] = "Legal review of lease term adjustments",
        [401820011] = "Penalty scheme",
        [401820012] = "Engage stakeholders for visa approval (delayed nationalities)",
        [401820013] = "Internal approval enhancement",
        [401820014] = "Faster TAT for amending activities",
        [401820015] = "Faster process/approval to upgrade scheme",
        [401820016] = "Faster approval for asset readiness & maintenance",
        [401820017] = "Faster approval for Tiered License renewal",
        [401820018] = "Faster approval for rent addendum cases",
        [401820019] = "Faster approval from stakeholders (MOPH, MOCI, etc.)",
        [401820020] = "Faster TAT for PTW approvals",
        [401820021] = "Faster approval from stakeholders (Kahramaa)",
        [401820022] = "Engage QCCI",
        [401820023] = "Engage Customs",
        [401820024] = "Automated process to send notices",
        [401820025] = "Faster refund of fit-out deposit (LIU investor)",
        [401820026] = "Internal approvals to terminate investor",
    };

    // Shared Investment Status Update builder for the account's active action tracker step - returns
    // one entry per qfza_actiontrackers row (not merged down to a single "latest" record), used by
    // both the request-based and account-based deal detail lookups.
    private List<StatusUpdate> BuildStatusUpdates(string slaStatus, List<JsonElement> actionTrackers)
    {
        if (actionTrackers.Count == 0)
            return [new StatusUpdate { Status = slaStatus, CurrentSituation = "" }];

        return actionTrackers.Select(at =>
        {
            var issueCode = _d365.GetInt(at, "qfza_issuecategorycode");
            var actionCode = _d365.GetInt(at, "qfza_actioncategorycode");

            return new StatusUpdate
            {
                Status = slaStatus,
                CurrentSituation = issueCode.HasValue ? IssueCategoryLabels.GetValueOrDefault(issueCode.Value, issueCode.Value.ToString()) : "",
                ActionCategory = actionCode.HasValue ? ActionCategoryLabels.GetValueOrDefault(actionCode.Value, actionCode.Value.ToString()) : null,
                ActionableNextStep = _d365.GetString(at, "qfza_actionablenextstep"),
                KeyChallenges = _d365.GetString(at, "qfza_remarks"),
                LastContactWithInvestor = _d365.GetDateTime(at, "qfza_lastcontactwithinvestor")?.ToString("yyyy-MM-dd"),
                NextContactWithInvestor = _d365.GetDateTime(at, "qfza_nextcontactwithinvestor")?.ToString("yyyy-MM-dd"),
                CreatedOn = _d365.GetDateTime(at, "createdon")?.ToString("yyyy-MM-ddTHH:mm:ssZ")
            };
        }).ToList();
    }

    // Actionable Next Steps: same qfza_actiontrackers rows as BuildStatusUpdates, projected down to
    // just the actionable-next-step text and its creation date.
    private List<ActionableNextStepItem> BuildActionableNextSteps(List<JsonElement> actionTrackers) =>
        actionTrackers.Select(at => new ActionableNextStepItem
        {
            ActionableNextStep = _d365.GetString(at, "qfza_actionablenextstep"),
            CreatedOn = _d365.GetDateTime(at, "createdon")?.ToString("yyyy-MM-ddTHH:mm:ssZ")
        }).ToList();

    // Last/Next contact dates come from the most recently modified action tracker row (first in the
    // list, since FetchActionTrackersAsync orders by modifiedon desc).
    private MilestoneInfo BuildMilestones(List<JsonElement> actionTrackers, string? completionDateOfPreviousStage)
    {
        JsonElement? latest = actionTrackers.Count > 0 ? actionTrackers[0] : null;
        return new MilestoneInfo
        {
            LastContactWithInvestor = latest.HasValue ? _d365.GetDateTime(latest.Value, "qfza_lastcontactwithinvestor")?.ToString("yyyy-MM-dd") : null,
            NextContactWithInvestor = latest.HasValue ? _d365.GetDateTime(latest.Value, "qfza_nextcontactwithinvestor")?.ToString("yyyy-MM-dd") : null,
            CompletionDateOfPreviousStage = completionDateOfPreviousStage
        };
    }

    // Cost CAPEX: filter qfza_grandeconomicanalysis on the deal's investor account, sum qfza_totalcapex.
    // Same source/entity as PipelineService.FetchCapexBatchAsync, scoped to a single account.
    private async Task<decimal?> FetchCapexForAccountAsync(Guid accountId)
    {
        try
        {
            var fetchXml = "<fetch><entity name=\"qfza_grandeconomicanalysis\">" +
                           "<attribute name=\"qfza_totalcapex\" />" +
                           "<filter><condition attribute=\"qfza_investorid\" operator=\"eq\" value=\"" +
                           accountId.ToString("D") + "\" /></filter>" +
                           "</entity></fetch>";
            var json = await _d365.GetListAsync("qfza_grandeconomicanalysises", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var items = _d365.GetValueArray(json);
            return items.Count > 0 ? items.Sum(i => _d365.GetDecimal(i, "qfza_totalcapex") ?? 0) : null;
        }
        catch
        {
            return null;
        }
    }

    public async Task<DealDetail?> GetDealByIdAsync(string dealId)
    {
        var detail = await GetRequestDealDetailAsync(dealId);
        if (detail != null) return detail;
        detail = await GetLeadDealDetailAsync(dealId);
        if (detail != null) return detail;
        return await GetAccountDealDetailAsync(dealId);
    }

    private async Task<DealDetail?> GetRequestDealDetailAsync(string dealId)
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests",
                $"$select=hexa_name,hexa_requestid,hexa_slastatustypecode,qfza_qualified,createdon,"
                + $"hexa_duedate,qfza_capexmil,qfza_cumulativeinvestmentmoney,qfza_assett,qfza_zone,"
                + $"qfza_businessdescription,qfza_futureplansinthefreezone,qfza_facilitysizeinsqme,"
                + $"qfza_legalentitytype,statecode,statuscode,"
                + $"_hexa_internalstatus_value,_hexa_processtemplate_value,_hexa_customer_value"
                + $"&$expand=owninguser($select=fullname),owningteam($select=name),hexa_Customer_account($select=name)"
                + $"&$filter=hexa_requestid eq {dealId}");
            var items = _d365.GetValueArray(json);
            if (items.Count == 0) return null;

            var r = items[0];
            var state           = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                                  ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");
            var internalStatus  = _d365.GetFormattedValue(r, "_hexa_internalstatus_value") ?? "";
            var processTemplate = _d365.GetFormattedValue(r, "_hexa_processtemplate_value") ?? "";
            var (stage, stageLabel) = ResolveStage(processTemplate, state, internalStatus);

            var ownerName = ResolveOwnerName(r);
            var requestIdValue = _d365.GetGuid(r, "hexa_requestid")?.ToString() ?? dealId;

            // The request's own internalStatus/processTemplate only ever resolves L1-L3 (it reflects
            // the lead/license workflow, which stays "Submitted"/"Approved" even after this specific
            // deal physically advances further). The account's Master Action Tracker Steps
            // (qfza_actiontrackerstepses) are the source of truth for the live pipeline state - each
            // qfza_pipeline stage is COMPLETED only once every step tagged with it is Completed, so
            // this both resolves the current stage/label and drives the Stages progress array.
            var customerAccountId = _d365.GetGuid(r, "_hexa_customer_value");
            var pipelineResult = customerAccountId.HasValue
                ? await FetchAccountPipelineDataAsync(customerAccountId.Value)
                : null;
            if (pipelineResult != null && !string.IsNullOrEmpty(pipelineResult.CurrentStage))
            {
                stage = pipelineResult.CurrentStage;
                stageLabel = pipelineResult.CurrentStageLabel;
            }
            var stages = pipelineResult?.Stages ?? GenerateDefaultStages(stage);

            // Current Situation / Action Category / Actionable Next Step / Key Challenges / contact
            // dates come from the qfza_actiontrackers rows tied to the account's currently active step.
            var actionTrackers = pipelineResult?.MasterStepId.HasValue == true
                ? await FetchActionTrackersAsync(pipelineResult.MasterStepId.Value)
                : [];

            var dealOwnerName = await GetDealOwnerNameAsync(requestIdValue);
            if (string.IsNullOrEmpty(dealOwnerName)) dealOwnerName = ownerName;
            var companyName = _d365.GetNestedString(r, "hexa_Customer_account", "name") ?? "";
            var assetTypeCode = _d365.GetInt(r, "qfza_assett");
            var assetType = assetTypeCode switch { 548240000 => "Land", 548240001 => "Office", 548240004 => "Warehouse", _ => "" };
            var capexMil = _d365.GetDecimal(r, "qfza_capexmil");
            var cumulativeInv = _d365.GetDecimal(r, "qfza_cumulativeinvestmentmoney");

            // Cost CAPEX now comes from qfza_grandeconomicanalysis.qfza_totalcapex for the investor
            // account, falling back to the request's own capex fields if the account has no analysis record.
            var accountCapex = customerAccountId.HasValue ? await FetchCapexForAccountAsync(customerAccountId.Value) : null;
            var capexAmount = accountCapex ?? cumulativeInv ?? (capexMil.HasValue ? capexMil * 1000000 : null);

            // qfza_facilitysizeinsqme is a CRM choice field (e.g. "3,000 - 10,000"), not a raw number —
            // resolve its label rather than reading it as a decimal.
            var firmSizeLabel = _d365.GetFormattedValue(r, "qfza_facilitysizeinsqme");

            return new DealDetail
            {
                DealId = StripBraces(_d365.GetGuid(r, "hexa_requestid")?.ToString() ?? dealId),
                DealName = _d365.GetString(r, "hexa_name") ?? "Unnamed Request",
                SlaStatus = MapSlaStatus(_d365.GetInt(r, "hexa_slastatustypecode")),
                LastUpdated = DateTime.UtcNow,
                CurrentStage = stage,
                CurrentStageLabel = stageLabel,
                Stages = stages,
                Reviewer = new ReviewerInfo { Name = ownerName },
                Overview = new DealOverview
                {
                    CompanyOverview = _d365.GetString(r, "qfza_businessdescription") ?? "",
                    ProjectOverview = _d365.GetString(r, "qfza_futureplansinthefreezone") ?? ""
                },
                InvestmentDetails = new InvestmentDetails
                {
                    Status = _d365.GetInt(r, "statecode") == 0 ? "Active" : "Inactive",
                    DealOwner = dealOwnerName,
                    AssetType = assetType,
                    FirmSizeSqm = null,
                    FirmSizeLabel = firmSizeLabel,
                    DealCapex = new MoneyValue
                    {
                        Amount = capexAmount ?? 0,
                        Currency = "QAR",
                        Label = FormatMoney(capexAmount ?? 0)
                    },
                    QfzCapex = new MoneyValue()
                },
                InvestmentStatusUpdate = BuildStatusUpdates(MapSlaStatus(_d365.GetInt(r, "hexa_slastatustypecode")), actionTrackers),
                ActionableNextSteps = BuildActionableNextSteps(actionTrackers),
                Milestones = BuildMilestones(actionTrackers, _d365.GetDateTime(r, "createdon")?.ToString("yyyy-MM-dd"))
            };
        }
        catch
        {
            return null;
        }
    }

    // qfza_assettypecode optionset - drives L0's "Asset Type" field (distinct from hexa_request's
    // qfza_assett used by GetRequestDealDetailAsync, which has its own value set).
    private static readonly Dictionary<int, string> LeadAssetTypeLabels = new()
    {
        [548240000] = "Office",
        [548240001] = "Smartdesk",
        [548240002] = "LIU",
        [548240003] = "Land",
        [548240004] = "BTS",
        [548240005] = "Co-Working",
    };

    // L0: leads with no QFZ number assigned yet have no hexa_request record, so they're looked up
    // separately from the leads entity. Same source as DealService.FetchL0LeadDealsAsync.
    private async Task<DealDetail?> GetLeadDealDetailAsync(string dealId)
    {
        try
        {
            var json = await _d365.GetListAsync("leads",
                "$select=leadid,subject,fullname,createdon,statecode,statuscode,"
                + "qfza_projectdescription,description,qfza_landsizesqm,qfza_capexqarmn,qfza_assettypecode"
                + $"&$filter=leadid eq {dealId}"
                + "&$expand=owninguser($select=fullname),owningteam($select=name)");
            var items = _d365.GetValueArray(json);
            if (items.Count == 0) return null;

            var r = items[0];
            var state = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");
            var ownerName = ResolveOwnerName(r);
            var leadId = _d365.GetGuid(r, "leadid");

            // Investment Status / Milestones for L0 come from qfza_actiontrackers tied directly to the
            // lead (_qfza_leadid_value), not via an account/action-tracker-step like L1-L5.
            var actionTrackers = leadId.HasValue ? await FetchActionTrackersForLeadAsync(leadId.Value) : [];

            var assetTypeCode = _d365.GetInt(r, "qfza_assettypecode");
            var assetType = assetTypeCode.HasValue ? LeadAssetTypeLabels.GetValueOrDefault(assetTypeCode.Value, "") : "";

            var landSizeSqm = _d365.GetDecimal(r, "qfza_landsizesqm");

            // qfza_capexqarmn is CAPEX in QAR millions, same convention as hexa_request's qfza_capexmil.
            var capexQarMn = _d365.GetDecimal(r, "qfza_capexqarmn");
            var capexAmount = capexQarMn.HasValue ? capexQarMn * 1000000 : null;

            return new DealDetail
            {
                DealId = StripBraces(leadId?.ToString() ?? dealId),
                DealName = _d365.GetString(r, "subject") ?? _d365.GetString(r, "fullname") ?? "Unnamed Lead",
                SlaStatus = "PENDING",
                LastUpdated = DateTime.UtcNow,
                CurrentStage = "L0",
                CurrentStageLabel = "PreApplication Created",
                Stages = GenerateDefaultStages("L0"),
                Reviewer = new ReviewerInfo { Name = ownerName },
                Overview = new DealOverview
                {
                    CompanyOverview = _d365.GetString(r, "qfza_projectdescription") ?? "",
                    ProjectOverview = _d365.GetString(r, "description") ?? ""
                },
                InvestmentDetails = new InvestmentDetails
                {
                    Status = state,
                    DealOwner = ownerName,
                    AssetType = assetType,
                    FirmSizeSqm = landSizeSqm,
                    FirmSizeLabel = landSizeSqm.HasValue ? $"{landSizeSqm:N0} sqm" : null,
                    DealCapex = new MoneyValue
                    {
                        Amount = capexAmount ?? 0,
                        Currency = "QAR",
                        Label = FormatMoney(capexAmount ?? 0)
                    },
                    QfzCapex = new MoneyValue()
                },
                InvestmentStatusUpdate = BuildStatusUpdates("PENDING", actionTrackers),
                ActionableNextSteps = BuildActionableNextSteps(actionTrackers),
                Milestones = BuildMilestones(actionTrackers, _d365.GetDateTime(r, "createdon")?.ToString("yyyy-MM-dd"))
            };
        }
        catch
        {
            return null;
        }
    }

    // L0 Investment Status / Milestones: qfza_actiontrackers tied directly to the lead — same shape as
    // FetchActionTrackersAsync (used by L1-L5) but filtered by _qfza_leadid_value instead of the
    // action-tracker-step lookup, since L0 leads have no step/account of their own yet.
    private async Task<List<JsonElement>> FetchActionTrackersForLeadAsync(Guid leadId)
    {
        try
        {
            var json = await _d365.GetListAsync("qfza_actiontrackers",
                $"$filter=_qfza_leadid_value eq {leadId:D}"
                + "&$orderby=modifiedon desc");
            return _d365.GetValueArray(json);
        }
        catch
        {
            return [];
        }
    }

    // L4/L5 (and any other account whose current pipeline stage isn't tracked on a hexa_request/lead)
    // resolve entirely from the account's Master Action Tracker Steps via FetchAccountPipelineDataAsync.
    private async Task<DealDetail?> GetAccountDealDetailAsync(string dealId)
    {
        if (!Guid.TryParse(dealId, out var accountId)) return null;

        try
        {
            var pipelineResult = await FetchAccountPipelineDataAsync(accountId);
            if (pipelineResult == null || string.IsNullOrEmpty(pipelineResult.CurrentStage)) return null;

            var acctJson = await _d365.GetListAsync("accounts",
                $"$select=accountid,name,createdon,statecode"
                + $"&$expand=owninguser($select=fullname),owningteam($select=name)"
                + $"&$filter=accountid eq {accountId:D}");
            var accountItems = _d365.GetValueArray(acctJson);
            if (accountItems.Count == 0) return null;
            var record = accountItems[0];

            var state = _d365.GetString(record, "statecode@OData.Community.Display.V1.FormattedValue")
                ?? (_d365.GetInt(record, "statecode") == 1 ? "Inactive" : "Active");
            var ownerName = ResolveOwnerName(record);

            var actionTrackers = pipelineResult.MasterStepId.HasValue
                ? await FetchActionTrackersAsync(pipelineResult.MasterStepId.Value)
                : [];
            var capexAmount = await FetchCapexForAccountAsync(accountId);

            return new DealDetail
            {
                DealId = StripBraces(_d365.GetGuid(record, "accountid")?.ToString() ?? dealId),
                DealName = _d365.GetString(record, "name") ?? "Unnamed Account",
                SlaStatus = "ACTIVE",
                LastUpdated = DateTime.UtcNow,
                CurrentStage = pipelineResult.CurrentStage,
                CurrentStageLabel = pipelineResult.CurrentStageLabel,
                Stages = pipelineResult.Stages,
                Reviewer = new ReviewerInfo { Name = ownerName },
                Overview = new DealOverview(),
                InvestmentDetails = new InvestmentDetails
                {
                    Status = state,
                    DealOwner = ownerName,
                    DealCapex = new MoneyValue
                    {
                        Amount = capexAmount ?? 0,
                        Currency = "QAR",
                        Label = FormatMoney(capexAmount ?? 0)
                    },
                    QfzCapex = new MoneyValue()
                },
                InvestmentStatusUpdate = BuildStatusUpdates("ACTIVE", actionTrackers),
                ActionableNextSteps = BuildActionableNextSteps(actionTrackers),
                Milestones = BuildMilestones(actionTrackers, _d365.GetDateTime(record, "createdon")?.ToString("yyyy-MM-dd"))
            };
        }
        catch
        {
            return null;
        }
    }

    private static (string Id, string Label) ResolveStage(string processTemplate, string state, string internalStatus) =>
        (processTemplate, state, internalStatus) switch
        {
            ("Lead Application",    var st, var s) when st != "Inactive" && s != "Draft" => ("L1", "Application Submission"),
            ("Lead Application",    "Inactive", "Approved")  => ("L2", "Application Approved"),
            ("License Application", "Inactive", "Approved")  => ("L3", "License Granted"),
            _                                                 => ("",   "")
        };

    private string ResolveOwnerName(JsonElement r) =>
        _d365.GetNestedString(r, "owninguser", "fullname")
        ?? _d365.GetNestedString(r, "owningteam", "name")
        ?? "";

    private async Task<string> GetDealOwnerNameAsync(string requestId)
    {
        try
        {
            var stepJson = await _d365.GetListAsync("hexa_requeststeps",
                $"$select=_ownerid_value&$filter=_hexa_request_value eq {requestId} and hexa_name eq 'BD%20Review%20Stage%201'"
                + "&$orderby=createdon desc&$top=1");
            var steps = _d365.GetValueArray(stepJson);
            if (steps.Count == 0) return "";

            var ownerId = _d365.GetGuid(steps[0], "_ownerid_value");
            if (!ownerId.HasValue) return "";

            var userJson = await _d365.GetListAsync("systemusers", $"$filter=systemuserid eq {ownerId.Value:D}");
            var users = _d365.GetValueArray(userJson);
            return users.Count > 0 ? (_d365.GetString(users[0], "fullname") ?? "") : "";
        }
        catch
        {
            return "";
        }
    }

    private static string MapSlaStatus(int? code) =>
        code.HasValue && SlaStatusMap.TryGetValue(code.Value, out var s) ? s : "ACTIVE";

    private static string StripBraces(string id) => id.Replace("{", "").Replace("}", "");

    private static string FormatMoney(decimal value) =>
        value >= 1000000000 ? $"${value / 1000000000M:F2}B"
        : value >= 1000000 ? $"${value / 1000000M:F2}M"
        : $"${value:N0}";

    private static List<StageProgress> GenerateDefaultStages(string currentStage)
    {
        var allStages = new[] { "L0", "L1", "L2", "L3", "L4", "L5" };
        var labels = new[] { "PreApplication Created", "Application Submission", "Application Approved", "License Granted", "Construction Started", "Construction Completed" };
        var currentIndex = Array.IndexOf(allStages, currentStage);
        var result = new List<StageProgress>();
        for (int i = 0; i < allStages.Length; i++)
        {
            // currentIndex < 0 covers any unresolved stage: nothing has started yet.
            var status = currentIndex < 0 ? "UPCOMING"
                : i < currentIndex ? "COMPLETED"
                : i == currentIndex ? "ACTIVE"
                : "UPCOMING";
            result.Add(new StageProgress { Stage = allStages[i], Label = labels[i], Status = status });
        }
        return result;
    }
}
