using System.Text.Json;
using ExecutiveDashboard.API.Models;

namespace ExecutiveDashboard.API.Services;

public interface IDealService
{
    Task<PaginatedResponse<DealSummary>> GetDealsAsync(int page, int limit, string? sortBy, string? sortOrder,
        string? departmentId, string? stage, string? status, string? priority, string? investmentValueRangeId, string? searchTerm);
    Task<DealDetail?> GetDealByIdAsync(string dealId);
}

public class DealService : IDealService
{
    private readonly ID365Service _d365;

    private static readonly Dictionary<int, string> SlaStatusMap = new()
    {
        [0] = "PENDING",
        [1] = "ON_TRACK",
        [2] = "ACTIVE",
        [3] = "DELAYED",
        [4] = "SLA_BREACH"
    };


    public DealService(ID365Service d365)
    {
        _d365 = d365;
    }

    public async Task<PaginatedResponse<DealSummary>> GetDealsAsync(int page, int limit, string? sortBy, string? sortOrder,
        string? departmentId, string? stage, string? status, string? priority, string? investmentValueRangeId, string? searchTerm)
    {
        var fetchXml = BuildDealListFetchXml(page, limit, searchTerm, status);

        try
        {
            var json = await _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var items = _d365.GetValueArray(json);

            var deals = items.Select(r => ToDealSummaryFromFetchXml(r)).ToList();

            var totalItems = (page - 1) * limit + deals.Count;
            try
            {
                var countFetchXml = BuildDealCountFetchXml(searchTerm, status);
                var countJson = await _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(countFetchXml)}");
                var cv = _d365.GetValueArray(countJson);
                if (cv.Count > 0 && cv[0].TryGetProperty("count", out var ct))
                    totalItems = ct.GetInt32();
            }
            catch { }

            var totalPages = totalItems > 0 ? (int)Math.Ceiling((double)totalItems / limit) : 1;

            return new PaginatedResponse<DealSummary>
            {
                Data = deals,
                Pagination = new PaginationInfo
                {
                    TotalItems = totalItems, TotalPages = totalPages,
                    CurrentPage = page, ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return new PaginatedResponse<DealSummary>
            {
                Data = [],
                Pagination = new PaginationInfo { TotalItems = 0, TotalPages = 0, CurrentPage = page, ItemsPerPage = limit }
            };
        }
    }

    private static string BuildDealListFetchXml(int page, int limit, string? searchTerm, string? status)
    {
        var extraFilters = new System.Text.StringBuilder();

        if (!string.IsNullOrEmpty(searchTerm))
            extraFilters.Append($"<condition attribute=\"hexa_name\" operator=\"like\" value=\"%{searchTerm.Replace("'", "&apos;")}%\" />");

        if (!string.IsNullOrEmpty(status))
        {
            var slaCode = StatusToSlaCode(status);
            if (slaCode.HasValue)
                extraFilters.Append($"<condition attribute=\"hexa_slastatustypecode\" operator=\"eq\" value=\"{slaCode}\" />");
        }

        return $"<fetch count=\"{limit}\" page=\"{page}\">" +
               "<entity name=\"hexa_request\">" +
               "<attribute name=\"hexa_duedate\" />" +
               "<attribute name=\"hexa_slastatustypecode\" />" +
               "<attribute name=\"hexa_name\" />" +
               "<attribute name=\"hexa_requestid\" />" +
               "<filter>" +
               "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
               extraFilters +
               "</filter>" +
               "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"account\">" +
               "<attribute name=\"name\" />" +
               "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionTrackerSteps\">" +
               "<attribute name=\"qfza_pipeline\" />" +
               "<filter><condition attribute=\"qfza_actionstatus\" operator=\"eq\" value=\"401820000\" /></filter>" +
               "</link-entity>" +
               "</link-entity>" +
               "</entity>" +
               "</fetch>";
    }

    private static string BuildDealCountFetchXml(string? searchTerm, string? status)
    {
        var extraFilters = new System.Text.StringBuilder();

        if (!string.IsNullOrEmpty(searchTerm))
            extraFilters.Append($"<condition attribute=\"hexa_name\" operator=\"like\" value=\"%{searchTerm.Replace("'", "&apos;")}%\" />");

        if (!string.IsNullOrEmpty(status))
        {
            var slaCode = StatusToSlaCode(status);
            if (slaCode.HasValue)
                extraFilters.Append($"<condition attribute=\"hexa_slastatustypecode\" operator=\"eq\" value=\"{slaCode}\" />");
        }

        return "<fetch aggregate=\"true\">" +
               "<entity name=\"hexa_request\">" +
               "<attribute name=\"hexa_requestid\" alias=\"count\" aggregate=\"count\" />" +
               "<filter>" +
               "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
               extraFilters +
               "</filter>" +
               "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"account\">" +
               "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionTrackerSteps\">" +
               "<filter><condition attribute=\"qfza_actionstatus\" operator=\"eq\" value=\"401820000\" /></filter>" +
               "</link-entity>" +
               "</link-entity>" +
               "</entity>" +
               "</fetch>";
    }

    private static readonly Dictionary<int, (string Stage, string Label)> PipelineStageMap = new()
    {
        [401820000] = ("L0", "PreApplication Created"),
        [401820001] = ("L1", "Application Submission"),
        [401820002] = ("L2", "Application Approved"),
        [401820003] = ("L3", "License Granted"),
        [401820004] = ("L4", "Construction Started"),
        [401820005] = ("L5", "Construction Completed"),
    };

    private DealSummary ToDealSummaryFromFetchXml(JsonElement r)
    {
        var pipelineCode = _d365.GetInt(r, "actionTrackerSteps.qfza_pipeline");
        var (stage, stageLabel) = pipelineCode.HasValue && PipelineStageMap.TryGetValue(pipelineCode.Value, out var mapped)
            ? mapped
            : ("", "");

        var dueDate = _d365.GetDateTime(r, "hexa_duedate");
        var slaStatus = dueDate.HasValue && dueDate.Value.Date < DateTime.UtcNow.Date ? "DELAYED" : "ON_TRACK";

        return new DealSummary
        {
            DealId = StripBraces(_d365.GetGuid(r, "hexa_requestid")?.ToString() ?? ""),
            DealName = _d365.GetString(r, "hexa_name") ?? "Unnamed Request",
            OwnerName = "",
            Department = _d365.GetString(r, "account.name") ?? "",
            Stage = stage,
            StageLabel = stageLabel,
            DueDate = dueDate?.ToString("yyyy-MM-dd"),
            DaysRemaining = dueDate.HasValue ? (int)(dueDate.Value.Date - DateTime.UtcNow.Date).TotalDays : 0,
            SlaStatus = slaStatus,
            RequiredAction = MapRequiredAction(slaStatus),
            Priority = "LOW",
            CapexAmount = null,
            CapexCurrency = "QAR",
            CapexLabel = null,
            State = "Active",
            InternalStatus = "",
            ProcessTemplate = "",
        };
    }

    public async Task<DealDetail?> GetDealByIdAsync(string dealId)
    {
        var detail = await GetRequestDealDetailAsync(dealId);
        if (detail != null) return detail;
        detail = await GetLeadDealDetailAsync(dealId);
        if (detail != null) return detail;
        return await GetAccountDealDetailAsync(dealId);
    }

    private async Task<DealDetail?> GetRequestDealDetailAsync(string dealId)
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests",
                $"$select=hexa_name,hexa_requestid,hexa_slastatustypecode,qfza_qualified,createdon,"
                + $"hexa_duedate,qfza_capexmil,qfza_cumulativeinvestmentmoney,qfza_assett,qfza_zone,"
                + $"qfza_businessdescription,qfza_legalentitytype,statecode,statuscode,"
                + $"_hexa_internalstatus_value,_hexa_processtemplate_value,_hexa_customer_value"
                + $"&$expand=owninguser($select=fullname),owningteam($select=name),hexa_Customer_account($select=name)"
                + $"&$filter=hexa_requestid eq {dealId}");
            var items = _d365.GetValueArray(json);
            if (items.Count == 0) return null;

            var r = items[0];
            var state           = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                                  ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");
            var internalStatus  = _d365.GetFormattedValue(r, "_hexa_internalstatus_value") ?? "";
            var processTemplate = _d365.GetFormattedValue(r, "_hexa_processtemplate_value") ?? "";
            var (stage, stageLabel) = ResolveStage(processTemplate, state, internalStatus);

            var ownerName = ResolveOwnerName(r);
            var requestIdValue = _d365.GetGuid(r, "hexa_requestid")?.ToString() ?? dealId;

            // The request's own internalStatus/processTemplate only ever resolves L1-L3 (it reflects
            // the lead/license workflow, which stays "Submitted"/"Approved" even after this specific
            // deal physically advances further). qfza_actiontrackersteps has a direct link to the
            // request (_qfza_requestid_value) - scoping by that (not by account) is required because
            // one account can have several concurrent requests each with their own open step at a
            // different pipeline stage; a dedicated request-level step is preferred when one exists.
            // Most requests don't have their own step though - the list endpoint attributes a deal to
            // whatever open pipeline stage its account currently has, so fall back to that same
            // account-level lookup here too, or detail and list disagree on a deal's current stage.
            var requestPipelineStage = await FetchRequestPipelineStageAsync(requestIdValue);
            var customerAccountId = _d365.GetGuid(r, "_hexa_customer_value");
            var pipelineStage = requestPipelineStage
                ?? (customerAccountId.HasValue ? await FetchAccountOpenPipelineStageAsync(customerAccountId.Value) : null);
            if (pipelineStage.HasValue)
            {
                (stage, stageLabel) = pipelineStage.Value;
            }
            var dealOwnerName = await GetDealOwnerNameAsync(requestIdValue);
            if (string.IsNullOrEmpty(dealOwnerName)) dealOwnerName = ownerName;
            var companyName = _d365.GetNestedString(r, "hexa_Customer_account", "name") ?? "";
            var assetTypeCode = _d365.GetInt(r, "qfza_assett");
            var assetType = assetTypeCode switch { 548240000 => "Land", 548240001 => "Office", 548240004 => "Warehouse", _ => "" };
            var capexMil = _d365.GetDecimal(r, "qfza_capexmil");
            var cumulativeInv = _d365.GetDecimal(r, "qfza_cumulativeinvestmentmoney");
            var capexAmount = cumulativeInv ?? (capexMil.HasValue ? capexMil * 1000000 : null);

            return new DealDetail
            {
                DealId = StripBraces(_d365.GetGuid(r, "hexa_requestid")?.ToString() ?? dealId),
                DealName = _d365.GetString(r, "hexa_name") ?? "Unnamed Request",
                SlaStatus = MapSlaStatus(_d365.GetInt(r, "hexa_slastatustypecode")),
                LastUpdated = DateTime.UtcNow,
                CurrentStage = stage,
                CurrentStageLabel = stageLabel,
                Stages = GenerateDefaultStages(stage),
                Reviewer = new ReviewerInfo { Name = ownerName },
                Overview = new DealOverview
                {
                    CompanyOverview = companyName,
                    ProjectOverview = _d365.GetString(r, "qfza_businessdescription") ?? ""
                },
                InvestmentDetails = new InvestmentDetails
                {
                    Status = _d365.GetInt(r, "statecode") == 0 ? "Active" : "Inactive",
                    DealOwner = dealOwnerName,
                    AssetType = assetType,
                    FreeZone = _d365.GetString(r, "qfza_zone") ?? "QFZA",
                    DealCapex = new MoneyValue
                    {
                        Amount = capexAmount ?? 0,
                        Currency = "QAR",
                        Label = FormatMoney(capexAmount ?? 0)
                    },
                    QfzCapex = new MoneyValue()
                },
                InvestmentStatusUpdate = new StatusUpdate
                {
                    Status = MapSlaStatus(_d365.GetInt(r, "hexa_slastatustypecode")),
                    CurrentSituation = ""
                },
                ActionableNextSteps = new ActionableSteps(),
                Milestones = new MilestoneInfo
                {
                    LastContactWithInvestor = _d365.GetDateTime(r, "modifiedon")?.ToString("yyyy-MM-dd"),
                    CompletionDateOfPreviousStage = _d365.GetDateTime(r, "createdon")?.ToString("yyyy-MM-dd"),
                }
            };
        }
        catch
        {
            return null;
        }
    }

    // L0: leads with no QFZ number assigned yet have no hexa_request record, so they're looked up
    // separately from the leads entity. Same source as DealService.FetchL0LeadDealsAsync.
    private async Task<DealDetail?> GetLeadDealDetailAsync(string dealId)
    {
        try
        {
            var json = await _d365.GetListAsync("leads",
                "$select=leadid,subject,fullname,createdon,statecode,statuscode"
                + $"&$filter=leadid eq {dealId}"
                + "&$expand=owninguser($select=fullname),owningteam($select=name)");
            var items = _d365.GetValueArray(json);
            if (items.Count == 0) return null;

            var r = items[0];
            var state = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");
            var ownerName = ResolveOwnerName(r);

            return new DealDetail
            {
                DealId = StripBraces(_d365.GetGuid(r, "leadid")?.ToString() ?? dealId),
                DealName = _d365.GetString(r, "subject") ?? _d365.GetString(r, "fullname") ?? "Unnamed Lead",
                SlaStatus = "PENDING",
                LastUpdated = DateTime.UtcNow,
                CurrentStage = "L0",
                CurrentStageLabel = "PreApplication Created",
                Stages = GenerateDefaultStages("L0"),
                Reviewer = new ReviewerInfo { Name = ownerName },
                Overview = new DealOverview(),
                InvestmentDetails = new InvestmentDetails
                {
                    Status = state,
                    DealOwner = ownerName,
                    DealCapex = new MoneyValue(),
                    QfzCapex = new MoneyValue()
                },
                InvestmentStatusUpdate = new StatusUpdate { Status = "PENDING", CurrentSituation = "" },
                ActionableNextSteps = new ActionableSteps(),
                Milestones = new MilestoneInfo
                {
                    CompletionDateOfPreviousStage = _d365.GetDateTime(r, "createdon")?.ToString("yyyy-MM-dd"),
                }
            };
        }
        catch
        {
            return null;
        }
    }

    // qfza_actiontrackersteps links to a specific request via _qfza_requestid_value, not just to the
    // account - one account can have several concurrent requests each with their own open step at a
    // different pipeline stage, so this must be scoped by request, not by account, to avoid picking
    // up a sibling deal's stage. "Open" excludes Completed (401820005) and Cancelled (401820007).
    private const string RequestPipelineStepFetchXmlTemplate =
        "<fetch><entity name=\"qfza_actiontrackersteps\">" +
        "<attribute name=\"qfza_pipeline\" />" +
        "<filter>" +
        "<condition attribute=\"qfza_requestid\" operator=\"eq\" value=\"{0}\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" uiname=\"Completed\" uitype=\"qfza_actionstatus\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820007\" uiname=\"Cancelled\" uitype=\"qfza_actionstatus\" />" +
        "</filter>" +
        "</entity></fetch>";

    private async Task<(string Stage, string Label)?> FetchRequestPipelineStageAsync(string requestId)
    {
        try
        {
            var fetchXml = string.Format(RequestPipelineStepFetchXmlTemplate, requestId);
            var json = await _d365.GetListAsync("qfza_actiontrackersteps", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var codes = _d365.GetValueArray(json)
                .Select(i => _d365.GetInt(i, "qfza_pipeline"))
                .Where(c => c.HasValue)
                .Select(c => c!.Value)
                .ToList();
            if (codes.Count == 0) return null;

            // If a request somehow has multiple open steps, the highest stage reached wins.
            return PipelineStageMap.TryGetValue(codes.Max(), out var mapped) ? mapped : null;
        }
        catch
        {
            return null;
        }
    }

    // Fallback when the request has no dedicated step of its own: same account + status filter as
    // BuildDealListFetchXml, so a deal's stage here always agrees with what the deals list shows for it.
    private const string AccountOpenPipelineStepFetchXmlTemplate =
        "<fetch><entity name=\"qfza_actiontrackersteps\">" +
        "<attribute name=\"qfza_pipeline\" />" +
        "<filter>" +
        "<condition attribute=\"qfza_accountid\" operator=\"eq\" value=\"{0}\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"eq\" value=\"401820000\" />" +
        "</filter>" +
        "</entity></fetch>";

    private async Task<(string Stage, string Label)?> FetchAccountOpenPipelineStageAsync(Guid accountId)
    {
        try
        {
            var fetchXml = string.Format(AccountOpenPipelineStepFetchXmlTemplate, accountId.ToString("D"));
            var json = await _d365.GetListAsync("qfza_actiontrackersteps", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var codes = _d365.GetValueArray(json)
                .Select(i => _d365.GetInt(i, "qfza_pipeline"))
                .Where(c => c.HasValue)
                .Select(c => c!.Value)
                .ToList();
            if (codes.Count == 0) return null;

            return PipelineStageMap.TryGetValue(codes.Max(), out var mapped) ? mapped : null;
        }
        catch
        {
            return null;
        }
    }

    // L4/L5: deals at these stages live on the account's action tracker steps (qfza_actiontrackersteps),
    // not on hexa_requests or leads. Same source as DashboardService's L4/L5 pipeline counts and
    // PipelineService's L4/L5 stage details. "Open" excludes Completed (401820005) and Cancelled
    // (401820007) action statuses - per the qfza_actiontrackerstepses docs, a pipeline stage is
    // "in progress" only while it has a step that isn't Completed/Cancelled.
    private const string AccountPipelineFetchXmlTemplate =
        "<fetch><entity name=\"account\">" +
        "<attribute name=\"accountid\" /><attribute name=\"name\" /><attribute name=\"ownerid\" /><attribute name=\"createdon\" /><attribute name=\"statecode\" />" +
        "<filter><condition attribute=\"accountid\" operator=\"eq\" value=\"{0}\" /></filter>" +
        "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionSteps\">" +
        "<filter>" +
        "<condition attribute=\"qfza_pipeline\" operator=\"eq\" value=\"{1}\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" uiname=\"Completed\" uitype=\"qfza_actionstatus\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820007\" uiname=\"Cancelled\" uitype=\"qfza_actionstatus\" />" +
        "</filter>" +
        "</link-entity></entity></fetch>";

    private async Task<DealDetail?> GetAccountDealDetailAsync(string dealId)
    {
        if (!Guid.TryParse(dealId, out var accountId)) return null;

        try
        {
            var (r, stage, stageLabel) = await FindAccountPipelineRecordAsync(accountId);
            if (r == null) return null;
            var record = r.Value;

            var state = _d365.GetString(record, "statecode@OData.Community.Display.V1.FormattedValue")
                ?? (_d365.GetInt(record, "statecode") == 1 ? "Inactive" : "Active");
            var ownerName = _d365.GetFormattedValue(record, "_ownerid_value") ?? "";

            return new DealDetail
            {
                DealId = StripBraces(_d365.GetGuid(record, "accountid")?.ToString() ?? dealId),
                DealName = _d365.GetString(record, "name") ?? "Unnamed Account",
                SlaStatus = "ACTIVE",
                LastUpdated = DateTime.UtcNow,
                CurrentStage = stage,
                CurrentStageLabel = stageLabel,
                Stages = GenerateDefaultStages(stage),
                Reviewer = new ReviewerInfo { Name = ownerName },
                Overview = new DealOverview(),
                InvestmentDetails = new InvestmentDetails
                {
                    Status = state,
                    DealOwner = ownerName,
                    DealCapex = new MoneyValue(),
                    QfzCapex = new MoneyValue()
                },
                InvestmentStatusUpdate = new StatusUpdate { Status = "ACTIVE", CurrentSituation = "" },
                ActionableNextSteps = new ActionableSteps(),
                Milestones = new MilestoneInfo
                {
                    CompletionDateOfPreviousStage = _d365.GetDateTime(record, "createdon")?.ToString("yyyy-MM-dd"),
                }
            };
        }
        catch
        {
            return null;
        }
    }

    // Checks L5 before L4 so an account active in both shows as the further-along stage.
    private async Task<(JsonElement? Record, string Stage, string Label)> FindAccountPipelineRecordAsync(Guid accountId)
    {
        foreach (var (pipelineCode, stage, label) in new[]
        {
            ("401820005", "L5", "Construction Completed"),
            ("401820004", "L4", "Construction Started"),
        })
        {
            var fetchXml = string.Format(AccountPipelineFetchXmlTemplate, accountId.ToString("D"), pipelineCode);
            var json = await _d365.GetListAsync("accounts", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var items = _d365.GetValueArray(json);
            if (items.Count > 0) return (items[0], stage, label);
        }
        return (null, "", "");
    }

    private static (string Id, string Label) ResolveStage(string processTemplate, string state, string internalStatus) =>
        (processTemplate, state, internalStatus) switch
        {
            ("Lead Application",    "Active",   "Submitted") => ("L1", "Application Submission"),
            ("Lead Application",    "Inactive", "Approved")  => ("L2", "Application Approved"),
            ("License Application", "Inactive", "Approved")  => ("L3", "License Granted"),
            _                                                 => ("",   "")
        };

    private string ResolveOwnerName(JsonElement r) =>
        _d365.GetNestedString(r, "owninguser", "fullname")
        ?? _d365.GetNestedString(r, "owningteam", "name")
        ?? "";

    private async Task<string> GetDealOwnerNameAsync(string requestId)
    {
        try
        {
            var stepJson = await _d365.GetListAsync("hexa_requeststeps",
                $"$select=_ownerid_value&$filter=_hexa_request_value eq {requestId} and hexa_name eq 'BD%20Review%20Stage%201'"
                + "&$orderby=createdon desc&$top=1");
            var steps = _d365.GetValueArray(stepJson);
            if (steps.Count == 0) return "";

            var ownerId = _d365.GetGuid(steps[0], "_ownerid_value");
            if (!ownerId.HasValue) return "";

            var userJson = await _d365.GetListAsync("systemusers", $"$filter=systemuserid eq {ownerId.Value:D}");
            var users = _d365.GetValueArray(userJson);
            return users.Count > 0 ? (_d365.GetString(users[0], "fullname") ?? "") : "";
        }
        catch
        {
            return "";
        }
    }

    private static int? StatusToSlaCode(string status) => status switch
    {
        "PENDING" => 0,
        "ON_TRACK" => 1,
        "ACTIVE" => 2,
        "DELAYED" => 3,
        "SLA_BREACH" => 4,
        _ => null
    };

    private static string MapSlaStatus(int? code) =>
        code.HasValue && SlaStatusMap.TryGetValue(code.Value, out var s) ? s : "ACTIVE";


    private static string? MapRequiredAction(string slaStatus) => slaStatus switch
    {
        "SLA_BREACH" => "SLA breached — immediate review required",
        "DELAYED" => "Deal delayed — review and update required",
        "PENDING" => "Awaiting action",
        _ => null
    };

    private static string StripBraces(string id) => id.Replace("{", "").Replace("}", "");

    private static string FormatMoney(decimal value) =>
        value >= 1000000000 ? $"${value / 1000000000M:F2}B"
        : value >= 1000000 ? $"${value / 1000000M:F2}M"
        : $"${value:N0}";

    private static List<StageProgress> GenerateDefaultStages(string currentStage)
    {
        var allStages = new[] { "L1", "L2", "L3", "L4", "L5" };
        var labels = new[] { "Application Submission", "Application Approved", "License Granted", "Construction Started", "Construction Completed" };
        var currentIndex = Array.IndexOf(allStages, currentStage);
        var result = new List<StageProgress>();
        for (int i = 0; i < allStages.Length; i++)
        {
            // currentIndex < 0 covers L0 and any unresolved stage: nothing has started yet.
            var status = currentIndex < 0 ? "UPCOMING"
                : i < currentIndex ? "COMPLETED"
                : i == currentIndex ? "ACTIVE"
                : "UPCOMING";
            result.Add(new StageProgress { Stage = allStages[i], Label = labels[i], Status = status });
        }
        return result;
    }
}
