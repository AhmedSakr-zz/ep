using System.Text.Json;
using ExecutiveDashboard.API.Models;

namespace ExecutiveDashboard.API.Services;

public interface IDashboardService
{
    Task<FilterOptions> GetFiltersAsync();
    Task<DashboardOverview> GetOverviewAsync(string? departmentId, string? stage, string? timePeriod,
        string? status, string? priority, string? investmentValueRangeId);
}

public class DashboardService : IDashboardService
{
    private readonly ID365Service _d365;

    private static readonly Dictionary<int, string> SlaStatusMap = new()
    {
        [0] = "PENDING",
        [1] = "ON_TRACK",
        [2] = "ACTIVE",
        [3] = "DELAYED",
        [4] = "SLA_BREACH"
    };

    private static readonly string[] StageIds = ["L1", "L2", "L3", "L4", "L5"];
    private static readonly string[] StageLabels = ["Application Submission", "Application Approved", "License Granted", "Construction Started", "Construction Completed"];

    public DashboardService(ID365Service d365)
    {
        _d365 = d365;
    }

    public Task<FilterOptions> GetFiltersAsync()
    {
        return Task.FromResult(new FilterOptions
        {
            Departments =
            [
                new() { Id = "dept_investment", Label = "Investment", Name = "Investment" },
                new() { Id = "dept_development", Label = "Development", Name = "Development" },
                new() { Id = "dept_operations", Label = "Operations", Name = "Operations" },
                new() { Id = "dept_marketing", Label = "Marketing", Name = "Marketing" },
            ],
            Stages = StageIds.Select((s, i) => new FilterItem { Id = s, Label = $"{s} ({StageLabels[i]})", Name = StageLabels[i] }).ToList(),
            Statuses =
            [
                new() { Id = "ACTIVE", Label = "Active" }, new() { Id = "DELAYED", Label = "Delayed" },
                new() { Id = "BLOCKED", Label = "Blocked" }, new() { Id = "PENDING", Label = "Pending" },
                new() { Id = "ON_TRACK", Label = "On Track" }, new() { Id = "SLA_BREACH", Label = "SLA Breach" },
            ],
            Priorities =
            [
                new() { Id = "HIGH", Label = "High" }, new() { Id = "MEDIUM", Label = "Medium" }, new() { Id = "LOW", Label = "Low" },
            ],
            InvestmentValueRanges =
            [
                new() { Id = "under_100m", Label = "Under QAR 100M", Min = 0, Max = 100000000 },
                new() { Id = "100m_500m", Label = "QAR 100M - QAR 500M", Min = 100000000, Max = 500000000 },
                new() { Id = "above_500m", Label = "Above QAR 500M", Min = 500000000, Max = null },
            ],
            TimePeriods = [new() { Id = "2026", Label = "2026" }, new() { Id = "2025", Label = "2025" }]
        });
    }

    public async Task<DashboardOverview> GetOverviewAsync(string? departmentId, string? stage, string? timePeriod,
        string? status, string? priority, string? investmentValueRangeId)
    {
        // Fetch all data sources in parallel
        var dealListTask = FetchRequestDetailsAsync();
        var totalCapexTask = FetchTotalCapexAsync();
        var monthlyGrowthTask = FetchMonthlyGrowthAsync();
        var licenseDataTask = FetchLicenseDataAsync();
        var qtrGrowthTask = FetchQuarterlyStageGrowthAsync();
        var dealsActionTask = FetchDealsRequiringActionCountAsync();
        var l0CountTask = FetchL0LeadsCountAsync();
        var l4CountTask = FetchL4PipelineCountAsync();
        var l5CountTask = FetchL5PipelineCountAsync();

        await Task.WhenAll(dealListTask, totalCapexTask, monthlyGrowthTask, licenseDataTask, qtrGrowthTask,
            dealsActionTask, l0CountTask, l4CountTask, l5CountTask);

        var dealList = await dealListTask;
        var totalCapexD365 = await totalCapexTask;
        var licenseData = await licenseDataTask;
        var quarterlyGrowth = await qtrGrowthTask;
        var dealsAction = await dealsActionTask;
        var l0Count = await l0CountTask;
        var l4Count = await l4CountTask;
        var l5Count = await l5CountTask;

        // FIX: totalCapex comes from the D365 full aggregate; fall back to sample sum only if query failed
        var totalCapex = totalCapexD365 ?? dealList.Sum(d => d.CapexAmount ?? 0);
        var sampleCapex = dealList.Sum(d => d.CapexAmount ?? 0);

        // L3/L4 "Total Investment Value" cards: sum qfza_totalinvestmentsize returned by a
        // dedicated fetchXml query per stage (not capex-based like other stages). The same records
        // (with createdon) drive the quarterly forecast breakdown below.
        var l3RecordsTask = FetchL3InvestmentRecordsAsync();
        var l4RecordsTask = FetchL4InvestmentRecordsAsync();
        // TargetHealth "Current Progress": approved-only investment totals per stage.
        var l3ApprovedTask = FetchInvestmentSumAsync(L3ApprovedInvestmentFetchXml);
        var l4ApprovedTask = FetchInvestmentSumAsync(L4ApprovedInvestmentFetchXml);
        await Task.WhenAll(l3RecordsTask, l4RecordsTask, l3ApprovedTask, l4ApprovedTask);
        var l3Records = await l3RecordsTask;
        var l4Records = await l4RecordsTask;
        var l3Capex = l3Records.Sum(r => r.Amount);
        var l4Capex = l4Records.Sum(r => r.Amount);
        var l3CurrentProgress = await l3ApprovedTask;
        var l4CurrentProgress = await l4ApprovedTask;

        var monthlyGrowth = await monthlyGrowthTask;
        var stageGrowth = StageIds.ToDictionary(
            s => s,
            s => monthlyGrowth.TryGetValue(s, out var g) ? g : 0);

        var projectionTargets = await FetchProjectionTargetsAsync(dealList);

        // FIX: actual total deal count from D365 (licenseData.Target = full count query)
        var totalDealCount = licenseData.Target > 0 ? licenseData.Target : dealList.Count;

        // FIX: combined target = L3 + L4 targets (consistent with investmentValueForecast)
        var combinedTarget = l3Capex + l4Capex;
        var l3StaticTarget = 5000000000;
        var l4StaticTarget = 6000000000;

        return new DashboardOverview
        {
            LastUpdated = DateTime.UtcNow,
            KeyMetrics = new KeyMetrics
            {
                L3VsTarget = new MetricValue
                {
                    Value = l3Capex,
                    Currency = "QAR",
                    ValueLabel = FormatMoney(l3Capex),
                    Target = l3StaticTarget,
                    TargetLabel = FormatMoney(l3StaticTarget),
                    Percentage = ComputePercentage(l3Capex, l3StaticTarget),
                    // FIX: dynamic QoQ growth instead of hardcoded 8.7
                    GrowthVsLastQuarter = quarterlyGrowth.GetValueOrDefault("L3", 0)
                },
                L4VsTarget = new MetricValue
                {
                    Value = l4Capex,
                    Currency = "QAR",
                    ValueLabel = FormatMoney(l4Capex),
                    Target = l4StaticTarget,
                    TargetLabel = FormatMoney(l4StaticTarget),
                    Percentage = ComputePercentage(l4Capex, l4StaticTarget),
                    // FIX: dynamic QoQ growth instead of hardcoded 8.7
                    GrowthVsLastQuarter = quarterlyGrowth.GetValueOrDefault("L4", 0)
                },
                LicensesAchievement = licenseData,
                // FIX: use D365 aggregate counts instead of scanning 100-record sample
                DealsRequiringActions = dealsAction
            },
            Pipeline = new PipelineSummary
            {
                // FIX: real total count from D365 instead of sample size (100)
                TotalDeals = totalDealCount,
                TotalValue = totalCapex,
                TotalCurrency = "QAR",
                TotalValueLabel = FormatMoney(totalCapex),
                Stages = new List<StageInfo>
                {
                    // L0: leads with no QFZ number yet (no hexa_request record), so it's a separate count
                    // outside the StageIds/L1-L5 machinery.
                    new()
                    {
                        Stage = "L0",
                        Label = "PreApplication Created",
                        DealCount = l0Count,
                        GrowthCountVsLastMonth = 0,
                        Value = 0,
                        ValueLabel = FormatMoney(0)
                    }
                }.Concat(StageIds.Select((s, i) =>
                {
                    // L4/L5: deals at these stages live on the account (qfza_actiontrackersteps pipeline),
                    // not on hexa_requests, so their counts come from FetchL4/L5PipelineCountAsync instead
                    // of the dealList grouping used for L1-L3.
                    int dealCount; decimal stageValue;
                    if (s == "L4" || s == "L5")
                    {
                        dealCount = s == "L4" ? l4Count : l5Count;
                        stageValue = totalDealCount > 0 ? totalCapex * dealCount / totalDealCount : 0;
                    }
                    else
                    {
                        var sg = dealList
                            .Where(d => d.Stage == s && MatchesStageFilter(d, s))
                            .ToList();
                        var sampleStageCapex = sg.Sum(d => d.CapexAmount ?? 0);
                        dealCount = sg.Count;
                        stageValue = sampleCapex > 0
                            ? totalCapex * sampleStageCapex / sampleCapex
                            : totalCapex * sg.Count / Math.Max(1, dealList.Count);
                    }
                    return new StageInfo
                    {
                        Stage = s,
                        Label = StageLabels[i],
                        DealCount = dealCount,
                        GrowthCountVsLastMonth = stageGrowth.GetValueOrDefault(s, 0),
                        Value = stageValue,
                        ValueLabel = FormatMoney(stageValue)
                    };
                })).ToList()
            },
            InvestmentValueForecast = new InvestmentForecast
            {
                L3PipelineValue = FormatMoney(l3StaticTarget),
                L3ActualValue = FormatMoney(l3Capex),
                L4PipelineValue  = FormatMoney(l4StaticTarget),
                L4ActualValue = FormatMoney(l4Capex),
                // FIX: combined = L3 + L4 (not the broken Year1 annualTarget)
                CombinedForecastValue = combinedTarget,
                CombinedForecastLabel = FormatMoney(combinedTarget),
                // FIX: % of combined L3+L4 target already achieved (not ComputeGrowthPct vs wrong annualTarget)
                GrowthPercentage = ComputePercentage(l3Capex + l4Capex, combinedTarget),
                QuarterlyBreakdown = GenerateQuarterlyBreakdown(l3Records, l4Records)
            },
            TargetHealth = new TargetHealth
            {
                L3 = BuildTargetHealthMetric(l3CurrentProgress, l3StaticTarget, l3Capex),
                L4 = BuildTargetHealthMetric(l4CurrentProgress, l4StaticTarget, l4Capex)
            }
        };
    }

    // TargetHealth per stage: currentProgress = approved-only investment total, annualTarget = static
    // target, forecastedValue = "Pipeline Value" (in-progress investment total), remainingGap =
    // annualTarget - forecastedValue (floored at 0), achievedPercentage = currentProgress / annualTarget.
    private static TargetHealthMetric BuildTargetHealthMetric(decimal currentProgress, decimal annualTarget, decimal pipelineValue)
    {
        var remainingGap = Math.Max(0, annualTarget - pipelineValue);
        var achievedPercentage = ComputePercentage(currentProgress, annualTarget);
        return new TargetHealthMetric
        {
            CurrentProgress = currentProgress,
            CurrentProgressLabel = FormatMoney(currentProgress),
            AnnualTarget = annualTarget,
            AnnualTargetLabel = FormatMoney(annualTarget),
            ForecastedValue = pipelineValue,
            ForecastedValueLabel = FormatMoney(pipelineValue),
            RemainingGap = remainingGap,
            RemainingGapLabel = FormatMoney(remainingGap),
            AchievedPercentage = achievedPercentage,
            Status = currentProgress >= annualTarget ? "ACHIEVED"
                : currentProgress >= annualTarget * 0.8m ? "ON_TRACK"
                : currentProgress >= annualTarget * 0.5m ? "AT_RISK"
                : "OFF_TRACK",
            StatusText = $"{achievedPercentage:F0}% achieved against annual projection target."
        };
    }

    // L3 "Total Investment Value" / quarterly forecast: qualifying Lead Application requests
    // (excl. Cancelled/Draft/Rejected), joined through their investor account to
    // qfza_grandeconomicanalysis, returning qfza_totalinvestmentsize + createdon per record.
    private const string L3InvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><attribute name=\"hexa_name\" /><attribute name=\"createdon\" /><attribute name=\"hexa_duedate\" />" +
        "<filter>" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"56c1a88f-96db-ee11-904b-000d3a683c1b\" uiname=\"Cancelled\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"8deb3274-437e-ee11-8179-0022489fd7a3\" uiname=\"Draft\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"c0f16dfa-c4db-ee11-904b-000d3a64f065\" uiname=\"Rejected\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"43bf51a5-20d7-4d85-a080-f6491bd75d0e\" uiname=\"Lead Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<attribute name=\"name\" />" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    // L4 "Total Investment Value" / quarterly forecast: qualifying License Application requests
    // (excl. Cancelled/Rejected), joined through their investor account to
    // qfza_grandeconomicanalysis, returning qfza_totalinvestmentsize + createdon per record.
    private const string L4InvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><attribute name=\"hexa_name\" /><attribute name=\"createdon\" /><attribute name=\"hexa_duedate\" />" +
        "<filter>" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"56c1a88f-96db-ee11-904b-000d3a683c1b\" uiname=\"Cancelled\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"c0f16dfa-c4db-ee11-904b-000d3a64f065\" uiname=\"Rejected\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"70681513-8c21-ef11-840a-0022489c4c2a\" uiname=\"License Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<attribute name=\"name\" />" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    // L3 TargetHealth "Current Progress": sum of qfza_totalinvestmentsize for approved Lead
    // Application requests (statecode Inactive), joined through the investor account.
    private const string L3ApprovedInvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><filter>" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"eq\" value=\"be3c386e-437e-ee11-8179-0022489fd7a3\" uiname=\"Approved\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"1\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"43bf51a5-20d7-4d85-a080-f6491bd75d0e\" uiname=\"Lead Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    // L4 TargetHealth "Current Progress": sum of qfza_totalinvestmentsize for approved License
    // Application requests (statecode Inactive), joined through the investor account.
    private const string L4ApprovedInvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><attribute name=\"createdon\" /><filter>" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"eq\" value=\"be3c386e-437e-ee11-8179-0022489fd7a3\" uiname=\"Approved\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"70681513-8c21-ef11-840a-0022489c4c2a\" uiname=\"License Application\" uitype=\"hexa_processtemplate\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"1\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    private async Task<decimal> FetchInvestmentSumAsync(string fetchXml)
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            return _d365.GetValueArray(json).Sum(i => _d365.GetDecimal(i, "grandEconomicData.qfza_totalinvestmentsize") ?? 0);
        }
        catch
        {
            return 0;
        }
    }

    // L4/L5 pipeline counts: registered accounts (active, company status 548240000) that have an
    // action tracker step at the corresponding pipeline stage (401820004 = L4, 401820005 = L5) whose
    // actionstatus is Open (401820004) and not Completed (401820005).
    private const string L4PipelineAccountsFetchXml =
        "<fetch distinct=\"true\"><entity name=\"account\"><filter>" +
        "<condition attribute=\"qfza_companystatus\" operator=\"eq\" value=\"548240000\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
        "</filter>" +
        "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionSteps\">" +
        "<filter>" +
        "<condition attribute=\"qfza_pipeline\" operator=\"eq\" value=\"401820004\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"eq\" value=\"401820004\" />" +
        "</filter>" +
        "</link-entity></entity></fetch>";

    private const string L5PipelineAccountsFetchXml =
        "<fetch distinct=\"true\"><entity name=\"account\"><filter>" +
        "<condition attribute=\"qfza_companystatus\" operator=\"eq\" value=\"548240000\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
        "</filter>" +
        "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionSteps\">" +
        "<filter>" +
        "<condition attribute=\"qfza_pipeline\" operator=\"eq\" value=\"401820005\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"eq\" value=\"401820004\" />" +
        "</filter>" +
        "</link-entity></entity></fetch>";

    private Task<int> FetchL4PipelineCountAsync() => FetchPipelineAccountsCountAsync(L4PipelineAccountsFetchXml);

    private Task<int> FetchL5PipelineCountAsync() => FetchPipelineAccountsCountAsync(L5PipelineAccountsFetchXml);

    private async Task<int> FetchPipelineAccountsCountAsync(string fetchXml)
    {
        try
        {
            var json = await _d365.GetListAsync("accounts", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            return _d365.GetValueArray(json).Count;
        }
        catch
        {
            return 0;
        }
    }

    private record InvestmentRecord(DateTime CreatedOn, decimal Amount, DateTime? DueDate);

    private Task<List<InvestmentRecord>> FetchL3InvestmentRecordsAsync() => FetchInvestmentRecordsFromFetchXmlAsync(L3InvestmentFetchXml);

    private Task<List<InvestmentRecord>> FetchL4InvestmentRecordsAsync() => FetchInvestmentRecordsFromFetchXmlAsync(L4InvestmentFetchXml);

    private async Task<List<InvestmentRecord>> FetchInvestmentRecordsFromFetchXmlAsync(string fetchXml)
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var items = _d365.GetValueArray(json);
            return items
                .Select(i => new InvestmentRecord(
                    _d365.GetDateTime(i, "createdon") ?? DateTime.MinValue,
                    _d365.GetDecimal(i, "grandEconomicData.qfza_totalinvestmentsize") ?? 0,
                    _d365.GetDateTime(i, "hexa_duedate")))
                .Where(r => r.CreatedOn != DateTime.MinValue)
                .ToList();
        }
        catch
        {
            return [];
        }
    }

    private record ProjectionTargets(decimal L3Target, decimal L4Target);

    private async Task<ProjectionTargets> FetchProjectionTargetsAsync(List<DealSummary> dealList)
    {
        try
        {
            var json = await _d365.GetListAsync("qfza_finantialprojectionses",
                "$select=qfza_totalsalesrevenues,qfza_year,_qfza_requestid_value&$top=5000");
            var items = _d365.GetValueArray(json);

            // Group projections by request: sum all-year revenues per request
            var byRequest = new Dictionary<string, decimal>();
            foreach (var p in items)
            {
                var reqId = _d365.GetGuid(p, "_qfza_requestid_value")?.ToString();
                if (reqId == null) continue;
                var sales = _d365.GetDecimal(p, "qfza_totalsalesrevenues") ?? 0;
                byRequest[reqId] = byRequest.GetValueOrDefault(reqId) + sales;
            }

            var totalProjections = byRequest.Values.Sum();

            var sampleStageMap = dealList.ToDictionary(d => StripBraces(d.DealId), d => d.Stage);
            var sampleL3Ids = sampleStageMap.Where(kv => kv.Value == "L3").Select(kv => kv.Key).ToHashSet();
            var sampleL4Ids = sampleStageMap.Where(kv => kv.Value == "L4").Select(kv => kv.Key).ToHashSet();

            var l3Projections = byRequest.Where(kv => sampleL3Ids.Contains(kv.Key)).Sum(kv => kv.Value);
            var l4Projections = byRequest.Where(kv => sampleL4Ids.Contains(kv.Key)).Sum(kv => kv.Value);
            var mappedProjections = byRequest.Where(kv => sampleStageMap.ContainsKey(kv.Key)).Sum(kv => kv.Value);

            decimal l3Target, l4Target;
            if (mappedProjections > 0 && totalProjections > 0)
            {
                var ratio = totalProjections / mappedProjections;
                l3Target = l3Projections * ratio;
                l4Target = l4Projections * ratio;
            }
            else
            {
                l3Target = totalProjections * 0.3m;
                l4Target = totalProjections * 0.7m;
            }

            // FIX: annualTarget removed — callers use l3Target + l4Target as combined target
            return new ProjectionTargets(l3Target, l4Target);
        }
        catch
        {
            return new ProjectionTargets(5000000000m, 2200000000m);
        }
    }

    private async Task<decimal?> FetchTotalCapexAsync()
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests",
                "$apply=aggregate(qfza_cumulativeinvestmentmoney with sum as total)");
            var arr = _d365.GetValueArray(json);
            if (arr.Count > 0 && arr[0].TryGetProperty("total", out var t))
                return t.GetDecimal();
        }
        catch { }
        return null;
    }

    private static readonly string StageSelect =
        "hexa_requestid,statecode,_hexa_internalstatus_value,_hexa_processtemplate_value";

    private string ResolveStage(JsonElement r)
    {
        var state           = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                              ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");
        var internalStatus  = _d365.GetFormattedValue(r, "_hexa_internalstatus_value") ?? "";
        var processTemplate = _d365.GetFormattedValue(r, "_hexa_processtemplate_value") ?? "";

        return (processTemplate, state, internalStatus) switch
        {
            ("Lead Application",    var st, var s) when st != "Inactive" && s != "Draft" => "L1",
            ("Lead Application",    "Inactive", "Approved")  => "L2",
            ("License Application", "Inactive", "Approved")  => "L3",
            _                                                 => ""
        };
    }

    private async Task<Dictionary<string, int>> FetchMonthlyGrowthAsync()
    {
        var result = new Dictionary<string, int>();
        try
        {
            var now = DateTime.UtcNow;
            var thisMonthStart = new DateTime(now.Year, now.Month, 1, 0, 0, 0, DateTimeKind.Utc);
            var lastMonthStart = thisMonthStart.AddMonths(-1);

            var current = await _d365.GetListAsync("hexa_requests",
                $"$select={StageSelect}&$filter=createdon ge {thisMonthStart:yyyy-MM-ddTHH:mm:ssZ}&$top=200");
            foreach (var r in _d365.GetValueArray(current))
            {
                var stage = ResolveStage(r);
                if (!string.IsNullOrEmpty(stage))
                    result[stage] = result.GetValueOrDefault(stage) + 1;
            }

            var prev = await _d365.GetListAsync("hexa_requests",
                $"$select={StageSelect}&$filter=createdon ge {lastMonthStart:yyyy-MM-ddTHH:mm:ssZ} and createdon lt {thisMonthStart:yyyy-MM-ddTHH:mm:ssZ}&$top=200");
            var prevCounts = new Dictionary<string, int>();
            foreach (var r in _d365.GetValueArray(prev))
            {
                var stage = ResolveStage(r);
                if (!string.IsNullOrEmpty(stage))
                    prevCounts[stage] = prevCounts.GetValueOrDefault(stage) + 1;
            }

            foreach (var stageId in StageIds)
                result[stageId] = result.GetValueOrDefault(stageId) - prevCounts.GetValueOrDefault(stageId);
        }
        catch { }
        return result;
    }

    // FIX: calculate actual QoQ deal-count growth % per stage (replaces hardcoded 8.7)
    private async Task<Dictionary<string, decimal>> FetchQuarterlyStageGrowthAsync()
    {
        var result = new Dictionary<string, decimal>();
        try
        {
            var now = DateTime.UtcNow;
            var currentQtrMonth = (now.Month - 1) / 3 * 3 + 1;
            var currentQtrStart = new DateTime(now.Year, currentQtrMonth, 1, 0, 0, 0, DateTimeKind.Utc);
            var prevQtrStart = currentQtrStart.AddMonths(-3);

            var current = await _d365.GetListAsync("hexa_requests",
                $"$select={StageSelect}&$filter=createdon ge {currentQtrStart:yyyy-MM-ddTHH:mm:ssZ}&$top=500");
            var currentCounts = new Dictionary<string, int>();
            foreach (var r in _d365.GetValueArray(current))
            {
                var stage = ResolveStage(r);
                if (!string.IsNullOrEmpty(stage))
                    currentCounts[stage] = currentCounts.GetValueOrDefault(stage) + 1;
            }

            var prev = await _d365.GetListAsync("hexa_requests",
                $"$select={StageSelect}&$filter=createdon ge {prevQtrStart:yyyy-MM-ddTHH:mm:ssZ} and createdon lt {currentQtrStart:yyyy-MM-ddTHH:mm:ssZ}&$top=500");
            var prevCounts = new Dictionary<string, int>();
            foreach (var r in _d365.GetValueArray(prev))
            {
                var stage = ResolveStage(r);
                if (!string.IsNullOrEmpty(stage))
                    prevCounts[stage] = prevCounts.GetValueOrDefault(stage) + 1;
            }

            foreach (var stageId in StageIds)
            {
                var curr  = (decimal)currentCounts.GetValueOrDefault(stageId);
                var prevC = (decimal)prevCounts.GetValueOrDefault(stageId);
                result[stageId] = prevC > 0
                    ? Math.Round((curr - prevC) / prevC * 100, 1)
                    : (curr > 0 ? 100m : 0m);
            }
        }
        catch { }
        return result;
    }

    private async Task<LicensesAchievement> FetchLicenseDataAsync()
    {
        try
        {
            var approved = await _d365.GetListAsync("hexa_requests",
                "$filter=statuscode eq 110000001&$apply=aggregate($count as cnt)");
            var approvedCount = 0;
            var av = _d365.GetValueArray(approved);
            if (av.Count > 0 && av[0].TryGetProperty("cnt", out var ac))
                approvedCount = ac.GetInt32();

            var total = await _d365.GetListAsync("hexa_requests",
                "$apply=aggregate($count as cnt)");
            var totalCount = 0;
            var tv = _d365.GetValueArray(total);
            if (tv.Count > 0 && tv[0].TryGetProperty("cnt", out var tc))
                totalCount = tc.GetInt32();

            // FIX: dynamic quarter date ranges instead of hardcoded 2026-04-01 / 2026-01-01
            var now = DateTime.UtcNow;
            var currentQtrMonth = (now.Month - 1) / 3 * 3 + 1;
            var currentQtrStart = new DateTime(now.Year, currentQtrMonth, 1, 0, 0, 0, DateTimeKind.Utc);
            var prevQtrStart = currentQtrStart.AddMonths(-3);
            var nextQtrStart = currentQtrStart.AddMonths(3);

            var currentQtr = await _d365.GetListAsync("hexa_requests",
                $"$filter=createdon ge {currentQtrStart:yyyy-MM-ddTHH:mm:ssZ} and createdon lt {nextQtrStart:yyyy-MM-ddTHH:mm:ssZ}&$apply=aggregate($count as cnt)");
            var qtrCount = 0;
            var qv = _d365.GetValueArray(currentQtr);
            if (qv.Count > 0 && qv[0].TryGetProperty("cnt", out var qc))
                qtrCount = qc.GetInt32();

            var prevQtr = await _d365.GetListAsync("hexa_requests",
                $"$filter=createdon ge {prevQtrStart:yyyy-MM-ddTHH:mm:ssZ} and createdon lt {currentQtrStart:yyyy-MM-ddTHH:mm:ssZ}&$apply=aggregate($count as cnt)");
            var prevQtrCount = 0;
            var pq = _d365.GetValueArray(prevQtr);
            if (pq.Count > 0 && pq[0].TryGetProperty("cnt", out var pc))
                prevQtrCount = pc.GetInt32();

            return new LicensesAchievement
            {
                Achieved = approvedCount,
                Target = totalCount,
                VarianceVsLastQuarter = qtrCount - prevQtrCount,
                VarianceLabel = "Net new this quarter"
            };
        }
        catch
        {
            return new LicensesAchievement { Achieved = 0, Target = 0 };
        }
    }

    // FIX: query all records via D365 aggregate grouped by SLA status (not just the 100-sample)
    private async Task<DealsRequiringAction> FetchDealsRequiringActionCountAsync()
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests",
                "$apply=groupby((hexa_slastatustypecode),aggregate($count as cnt))");
            var items = _d365.GetValueArray(json);

            var breached = 0; var delayed = 0; var pending = 0;
            foreach (var item in items)
            {
                var code = _d365.GetInt(item, "hexa_slastatustypecode");
                var cnt = item.TryGetProperty("cnt", out var c) ? c.GetInt32() : 0;
                switch (code)
                {
                    case 4: breached = cnt; break; // SLA_BREACH
                    case 3: delayed = cnt; break; // DELAYED
                    case 0: pending = cnt; break; // PENDING
                }
            }

            return new DealsRequiringAction
            {
                Total = breached + delayed + pending,
                BreachedCount = breached,
                AtRiskCount = delayed,
                PendingCount = pending
            };
        }
        catch
        {
            return new DealsRequiringAction();
        }
    }

    // L0: leads with no QFZ number assigned yet (qfza_qfznumber eq null) have no hexa_request record.
    private async Task<int> FetchL0LeadsCountAsync()
    {
        try
        {
            var json = await _d365.GetListAsync("leads",
                "$filter=qfza_qfznumber eq null&$apply=aggregate($count as cnt)");
            var arr = _d365.GetValueArray(json);
            if (arr.Count > 0 && arr[0].TryGetProperty("cnt", out var c))
                return c.GetInt32();
        }
        catch { }
        return 0;
    }

    private async Task<List<DealSummary>> FetchRequestDetailsAsync()
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests",
                "$select=hexa_name,hexa_requestid,hexa_slastatustypecode,qfza_qualified,createdon,"
                + "hexa_duedate,qfza_capexmil,qfza_cumulativeinvestmentmoney,qfza_assett,qfza_zone,"
                + "qfza_businessdescription,qfza_legalentitytype,statecode,statuscode,_hexa_internalstatus_value,_hexa_processtemplate_value"
                + "&$expand=owninguser($select=fullname),owningteam($select=name),"
                + "hexa_Customer_account($select=name)&$top=5000");

            return _d365.GetValueArray(json).Select(ToDealSummary).ToList();
        }
        catch
        {
            return [];
        }
    }

    private DealSummary ToDealSummary(JsonElement r)
    {
        var state           = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                              ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");
        var internalStatus  = _d365.GetFormattedValue(r, "_hexa_internalstatus_value") ?? "";
        var processTemplate = _d365.GetFormattedValue(r, "_hexa_processtemplate_value") ?? "";

        var (stageId, stageLabel) = (processTemplate, state, internalStatus) switch
        {
            ("Lead Application",    var st, var s) when st != "Inactive" && s != "Draft" => ("L1", "Application Submission"),
            ("Lead Application",    "Inactive", "Approved")  => ("L2", "Application Approved"),
            ("License Application", "Inactive", "Approved")  => ("L3", "License Granted"),
            _                                                 => ("",   "")
        };

        var capexMil = _d365.GetDecimal(r, "qfza_capexmil");
        var cumulativeInv = _d365.GetDecimal(r, "qfza_cumulativeinvestmentmoney");

        return new DealSummary
        {
            DealId = StripBraces(_d365.GetGuid(r, "hexa_requestid")?.ToString() ?? ""),
            DealName = _d365.GetString(r, "hexa_name") ?? "Unnamed Request",
            OwnerName = ResolveOwnerName(r),
            Department = "",
            Stage = stageId,
            StageLabel = stageLabel,
            DueDate = _d365.GetDateTime(r, "hexa_duedate")?.ToString("yyyy-MM-dd"),
            SlaStatus = MapSlaStatus(_d365.GetInt(r, "hexa_slastatustypecode")),
            Priority = MapPriority(_d365.GetBool(r, "qfza_qualified")),
            CapexAmount = cumulativeInv ?? (capexMil.HasValue ? capexMil * 1000000 : null),
            CapexCurrency = "QAR",

            State = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active"),
            InternalStatus = _d365.GetFormattedValue(r, "_hexa_internalstatus_value") ?? "",
            ProcessTemplate = _d365.GetFormattedValue(r, "_hexa_processtemplate_value") ?? "",
        };
    }

    // Per-stage business rules for counting deals in the pipeline
    private static bool MatchesStageFilter(DealSummary d, string stage) => stage switch
    {
        "L1" => d.ProcessTemplate == "Lead Application" && d.State != "Inactive" && d.InternalStatus != "Draft",
        "L2" => d.ProcessTemplate == "Lead Application" && d.State == "Inactive" && d.InternalStatus == "Approved",
        "L3" => d.ProcessTemplate == "License Application" && d.State == "Inactive" && d.InternalStatus == "Approved",
        _ => true
    };

    private string ResolveOwnerName(JsonElement r) =>
        _d365.GetNestedString(r, "owninguser", "fullname")
        ?? _d365.GetNestedString(r, "owningteam", "name")
        ?? "";

    private static string MapSlaStatus(int? code) =>
        code.HasValue && SlaStatusMap.TryGetValue(code.Value, out var s) ? s : "ACTIVE";

    private static string MapPriority(bool? qualified) => qualified == true ? "HIGH" : "LOW";

    private static string StripBraces(string id) => id.Replace("{", "").Replace("}", "");

    private static string FormatMoney(decimal value)
    {
        if (value >= 1_000_000_000) return $"${value / 1_000_000_000M:F2}B";
        if (value >= 1_000_000) return $"${value / 1_000_000M:F2}M";
        if (value >= 1_000) return $"${value / 1_000M:F1}K";
        return $"${value:N0}";
    }

    private static decimal ComputePercentage(decimal value, decimal target) =>
        target > 0 ? Math.Round(value / target * 100, 1) : 0;

    private const int QuarterlyBreakdownYear = 2026;

    private static List<QuarterlyForecast> GenerateQuarterlyBreakdown(List<InvestmentRecord> l3Records, List<InvestmentRecord> l4Records)
    {
        var today = DateTime.UtcNow.Date;

        List<InvestmentRecord> RecordsForQuarter(List<InvestmentRecord> records, int quarter) => records
            .Where(r => r.CreatedOn.Year == QuarterlyBreakdownYear && (r.CreatedOn.Month - 1) / 3 + 1 == quarter)
            .ToList();

        // Delayed/OnTrack ratio (%) within a quarter's records, per the DueDate < today rule.
        (decimal Delayed, decimal OnTrack) StatusRatio(List<InvestmentRecord> quarterRecords)
        {
            if (quarterRecords.Count == 0) return (0, 0);
            var delayedCount = quarterRecords.Count(r => r.DueDate.HasValue && r.DueDate.Value.Date < today);
            var delayedPct = Math.Round((decimal)delayedCount / quarterRecords.Count * 100, 1);
            return (delayedPct, 100 - delayedPct);
        }

        return Enumerable.Range(1, 4).Select(q =>
        {
            var l3Quarter = RecordsForQuarter(l3Records, q);
            var l4Quarter = RecordsForQuarter(l4Records, q);
            var (l3Delayed, l3OnTrack) = StatusRatio(l3Quarter);
            var (l4Delayed, l4OnTrack) = StatusRatio(l4Quarter);

            return new QuarterlyForecast
            {
                Quarter = $"Q{q}-{QuarterlyBreakdownYear}",
                L3ForecastValue = l3Quarter.Sum(r => r.Amount),
                L3ForecastDelayedValue = l3Delayed,
                L3ForecastOnTrackValue = l3OnTrack,
                L4ForecastValue = l4Quarter.Sum(r => r.Amount),
                L4ForecastDelayedValue = l4Delayed,
                L4ForecastOnTrackValue = l4OnTrack
            };
        }).ToList();
    }
}
