using ExecutiveDashboard.API.Models;

namespace ExecutiveDashboard.API.Services;

public interface IUserService
{
    Task<UserProfile?> GetProfileAsync(string userId);
}

public class UserService : IUserService
{
    private readonly ID365Service _d365;

    private static readonly List<UserProfile> FallbackUsers =
    [
        new() { Id = "usr_001", FirstName = "Abdullah", LastName = "Al-Huzaymi", Email = "abdullah.al-huzaymi@qfz.gov.qa",
            Role = "Manager", Department = "Investment Department", Permissions = ["view_dashboard", "view_deals", "manage_deals"] },
        new() { Id = "usr_002", FirstName = "Ahmed", LastName = "Hassan", Email = "ahmed.hassan@qfz.gov.qa",
            Role = "Senior Officer", Department = "Investment Department", Permissions = ["view_dashboard", "view_deals"] },
        new() { Id = "usr_003", FirstName = "Sara", LastName = "Ali", Email = "sara.ali@qfz.gov.qa",
            Role = "Officer", Department = "Development", Permissions = ["view_dashboard", "view_deals"] },
    ];

    public UserService(ID365Service d365)
    {
        _d365 = d365;
    }

    public async Task<UserProfile?> GetProfileAsync(string userId)
    {
        try
        {
            var cleanId = userId.Replace("{", "").Replace("}", "");
            var json = await _d365.GetListAsync("systemusers",
                $"$select=systemuserid,fullname,firstname,lastname,internalemailaddress&$filter=systemuserid eq {cleanId}");
            var arr = _d365.GetValueArray(json);
            if (arr.Count == 0) return FallbackUsers.FirstOrDefault(u => u.Id == userId);

            var u = arr[0];
            return new UserProfile
            {
                Id = _d365.GetGuid(u, "systemuserid")?.ToString() ?? userId,
                FirstName = _d365.GetString(u, "firstname") ?? "",
                LastName = _d365.GetString(u, "lastname") ?? "",
                Email = _d365.GetString(u, "internalemailaddress") ?? "",
                Role = "User",
                Department = "",
                Permissions = ["view_dashboard", "view_deals"]
            };
        }
        catch
        {
            return FallbackUsers.FirstOrDefault(u => u.Id == userId);
        }
    }
}
