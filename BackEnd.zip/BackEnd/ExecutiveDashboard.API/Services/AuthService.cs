using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ExecutiveDashboard.API.Data;
using ExecutiveDashboard.API.Models;
using Microsoft.IdentityModel.Tokens;

namespace ExecutiveDashboard.API.Services;

public class AuthService : IAuthService
{
    private readonly IConfiguration _config;
    private static readonly Dictionary<string, string> RefreshTokens = new();

    public AuthService(IConfiguration config)
    {
        _config = config;
    }

    public Task<LoginResponse?> LoginAsync(LoginRequest request)
    {
        var user = MockDataStore.Users.FirstOrDefault(u =>
            u.Email.Equals(request.Email, StringComparison.OrdinalIgnoreCase));

        if (user == null || request.Password != "password123")
            return Task.FromResult<LoginResponse?>(null);

        var token = GenerateJwtToken(user);
        var refreshToken = Guid.NewGuid().ToString();
        RefreshTokens[refreshToken] = user.Id;

        return Task.FromResult<LoginResponse?>(new LoginResponse
        {
            Token = token,
            RefreshToken = refreshToken,
            ExpiresIn = 3600,
            User = user
        });
    }

    public Task<LoginResponse?> RefreshTokenAsync(RefreshTokenRequest request)
    {
        if (!RefreshTokens.TryGetValue(request.RefreshToken, out var userId))
            return Task.FromResult<LoginResponse?>(null);

        var user = MockDataStore.Users.FirstOrDefault(u => u.Id == userId);
        if (user == null)
            return Task.FromResult<LoginResponse?>(null);

        var newToken = GenerateJwtToken(user);
        var newRefreshToken = Guid.NewGuid().ToString();
        RefreshTokens.Remove(request.RefreshToken);
        RefreshTokens[newRefreshToken] = user.Id;

        return Task.FromResult<LoginResponse?>(new LoginResponse
        {
            Token = newToken,
            RefreshToken = newRefreshToken,
            ExpiresIn = 3600,
            User = user
        });
    }

    public Task<bool> LogoutAsync(string refreshToken)
    {
        return Task.FromResult(RefreshTokens.Remove(refreshToken));
    }

    private string GenerateJwtToken(UserProfile user)
    {
        var key = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(_config["Jwt:Key"] ?? "ExecutiveDashboardSecretKey2026!@#$%^&*()VeryLongKeyMustBe32Chars"));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim("department", user.Department),
            new Claim("firstName", user.FirstName),
            new Claim("lastName", user.LastName),
        };

        var token = new JwtSecurityToken(
            issuer: _config["Jwt:Issuer"] ?? "ExecutiveDashboard",
            audience: _config["Jwt:Audience"] ?? "ExecutiveDashboard",
            claims: claims,
            expires: DateTime.UtcNow.AddHours(1),
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
