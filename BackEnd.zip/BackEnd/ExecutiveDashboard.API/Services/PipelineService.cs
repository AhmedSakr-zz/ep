using System.Text.Json;
using ExecutiveDashboard.API.Models;

namespace ExecutiveDashboard.API.Services;

public interface IPipelineService
{
    Task<PipelineStageDetail?> GetStageDetailsAsync(string stage, int page, int limit);
}

public class PipelineService : IPipelineService
{
    private readonly ID365Service _d365;

    // Matches DashboardService's l3StaticTarget/l4StaticTarget so the pipeline stage detail card
    // and the overview's L3VsTarget/L4VsTarget card agree on the same targets.
    private const decimal L3StaticTarget = 5000000000m;
    private const decimal L4StaticTarget = 6000000000m;

    // L3/L4 pipeline value: same source as DashboardService's L3VsTarget/L4VsTarget — qualifying
    // requests joined through their investor account to qfza_grandeconomicanalysis, summing
    // qfza_totalinvestmentsize. Kept identical to DashboardService.L3InvestmentFetchXml/L4InvestmentFetchXml.
    private const string L3InvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><attribute name=\"hexa_name\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"56c1a88f-96db-ee11-904b-000d3a683c1b\" uiname=\"Cancelled\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"8deb3274-437e-ee11-8179-0022489fd7a3\" uiname=\"Draft\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"c0f16dfa-c4db-ee11-904b-000d3a64f065\" uiname=\"Rejected\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"43bf51a5-20d7-4d85-a080-f6491bd75d0e\" uiname=\"Lead Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<attribute name=\"name\" />" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    private const string L4InvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><attribute name=\"hexa_name\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"56c1a88f-96db-ee11-904b-000d3a683c1b\" uiname=\"Cancelled\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"c0f16dfa-c4db-ee11-904b-000d3a64f065\" uiname=\"Rejected\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"70681513-8c21-ef11-840a-0022489c4c2a\" uiname=\"License Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<attribute name=\"name\" />" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    private async Task<decimal> FetchInvestmentTotalAsync(string fetchXml)
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            return _d365.GetValueArray(json).Sum(i => _d365.GetDecimal(i, "grandEconomicData.qfza_totalinvestmentsize") ?? 0);
        }
        catch
        {
            return 0;
        }
    }

    private static readonly Dictionary<string, string> StageLabels = new()
    {
        ["L0"] = "L0 (PreApplication Created)",
        ["L1"] = "L1 (Application Submission)", ["L2"] = "L2 (Application Approved)",
        ["L3"] = "L3 (License Granted)", ["L4"] = "L4 (Construction Started)",
        ["L5"] = "L5 (Construction Completed)"
    };

    private static readonly Dictionary<string, string> StageDisplayLabels = new()
    {
        ["L0"] = "PreApplication Created",
        ["L1"] = "Application Submission", ["L2"] = "Application Approved",
        ["L3"] = "License Granted", ["L4"] = "Construction Started",
        ["L5"] = "Construction Completed"
    };

    // Server-side OData filters per stage — replaces the $top=5000 + in-memory filter.
    // GUIDs match the processTemplate values in L3InvestmentFetchXml / L4InvestmentFetchXml.
    private static readonly Dictionary<string, string> StageODataFilters = new()
    {
        ["L1"] = "_hexa_processtemplate_value eq 43bf51a5-20d7-4d85-a080-f6491bd75d0e and statecode eq 0",
        // statuscode eq 110000001 narrows inactive records to the specific approval reason code,
        // avoiding a full scan of all historical inactive requests (which causes timeouts).
        ["L2"] = "_hexa_processtemplate_value eq 43bf51a5-20d7-4d85-a080-f6491bd75d0e and statecode eq 1 and statuscode eq 110000001",
        ["L3"] = "_hexa_processtemplate_value eq 70681513-8c21-ef11-840a-0022489c4c2a and statecode eq 1 and statuscode eq 110000001",
    };

    // L4/L5: registered accounts (active, company status 548240000) with an open action tracker step
    // at the corresponding pipeline stage (401820004 = L4, 401820005 = L5). "Open" excludes Completed
    // (401820005) and Cancelled (401820007) action statuses - per the qfza_actiontrackerstepses docs,
    // a pipeline stage is "in progress" only while it has a step that isn't Completed/Cancelled.
    // Same source query used by DashboardService for the L4/L5 pipeline counts.
    private const string L4PipelineAccountsFetchXml =
        "<fetch><entity name=\"account\">" +
        "<attribute name=\"accountid\" /><attribute name=\"name\" /><attribute name=\"ownerid\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"qfza_companystatus\" operator=\"eq\" value=\"548240000\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
        "</filter>" +
        "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionSteps\">" +
        "<filter>" +
        "<condition attribute=\"qfza_pipeline\" operator=\"eq\" value=\"401820004\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" uiname=\"Completed\" uitype=\"qfza_actionstatus\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820007\" uiname=\"Cancelled\" uitype=\"qfza_actionstatus\" />" +
        "</filter>" +
        "</link-entity></entity></fetch>";

    private const string L5PipelineAccountsFetchXml =
        "<fetch><entity name=\"account\">" +
        "<attribute name=\"accountid\" /><attribute name=\"name\" /><attribute name=\"ownerid\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"qfza_companystatus\" operator=\"eq\" value=\"548240000\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
        "</filter>" +
        "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionSteps\">" +
        "<filter>" +
        "<condition attribute=\"qfza_pipeline\" operator=\"eq\" value=\"401820005\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" uiname=\"Completed\" uitype=\"qfza_actionstatus\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820007\" uiname=\"Cancelled\" uitype=\"qfza_actionstatus\" />" +
        "</filter>" +
        "</link-entity></entity></fetch>";

    public PipelineService(ID365Service d365)
    {
        _d365 = d365;
    }

    private static string ResolveStage(string processTemplate, string state, string internalStatus) =>
        (processTemplate, state, internalStatus) switch
        {
            ("Lead Application",    "Active",   "Submitted") => "L1",
            ("Lead Application",    "Inactive", "Approved")  => "L2",
            ("License Application", "Inactive", "Approved")  => "L3",
            _                                                 => ""
        };

    public Task<PipelineStageDetail?> GetStageDetailsAsync(string stage, int page, int limit)
    {
        if (!StageLabels.ContainsKey(stage))
            return Task.FromResult<PipelineStageDetail?>(null);

        return stage switch
        {
            "L0" => GetL0StageDetailsAsync(page, limit),
            "L4" => GetAccountPipelineStageDetailsAsync("L4", L4PipelineAccountsFetchXml, page, limit),
            "L5" => GetAccountPipelineStageDetailsAsync("L5", L5PipelineAccountsFetchXml, page, limit),
            _ => GetRequestStageDetailsAsync(stage, page, limit)
        };
    }

    // L1-L3: deals tracked on hexa_requests.
    private async Task<PipelineStageDetail?> GetRequestStageDetailsAsync(string stage, int page, int limit)
    {
        try
        {
            var selectFields = "hexa_name,hexa_requestid,hexa_slastatustypecode,qfza_qualified,createdon,"
                + "hexa_duedate,qfza_capexmil,qfza_cumulativeinvestmentmoney,qfza_assett,qfza_zone,"
                + "qfza_businessdescription,qfza_legalentitytype,statecode,statuscode,"
                + "_hexa_internalstatus_value,_hexa_processtemplate_value,_hexa_customer_value";
            var expand = "owninguser($select=fullname),owningteam($select=name),hexa_Customer_account($select=name)";

            // Fix 3: server-side filter per stage instead of $top=5000 + in-memory scan
            var stageFilter = StageODataFilters[stage];
            var dataTask = _d365.GetListAsync("hexa_requests",
                $"$select={selectFields}&$expand={expand}&$filter={stageFilter}");

            // Fix 1: fetch investment total in parallel with main data query
            var investTask = stage == "L3"
                ? FetchInvestmentTotalAsync(L3InvestmentFetchXml)
                : Task.FromResult(0m);

            await Task.WhenAll(dataTask, investTask);

            var items = _d365.GetValueArray(dataTask.Result);
            var allDeals = items
                .Select(r => (Deal: ToStageDeal(r), AccountId: _d365.GetGuid(r, "_hexa_customer_value")))
                .Where(x => x.Deal.CurrentStage == stage)
                .ToList();

            var filteredDeals = allDeals.Select(x => x.Deal).ToList();
            var pipelineValue = stage == "L3"
                ? investTask.Result
                : filteredDeals.Sum(d => d.CapexAmount ?? 0);

            var skip = (page - 1) * limit;
            var pagedSlice = allDeals.Skip(skip).Take(limit).ToList();

            // Fix 2: single batch CAPEX query for the page instead of one call per deal
            var accountIds = pagedSlice
                .Where(x => x.AccountId.HasValue)
                .Select(x => x.AccountId!.Value)
                .ToList();
            var capexByAccount = await FetchCapexBatchAsync(accountIds);
            foreach (var (deal, accountId) in pagedSlice)
            {
                if (accountId.HasValue && capexByAccount.TryGetValue(accountId.Value, out var capex))
                    deal.CapexAmount = capex;
            }
            var pagedDeals = pagedSlice.Select(x => x.Deal).ToList();

            return new PipelineStageDetail
            {
                Stage = stage,
                StageLabel = StageLabels[stage],
                SubLabel = $"Deals converted to {stage} from Jan 2026",
                LastUpdated = DateTime.UtcNow,
                SummaryMetrics = new StageSummaryMetrics
                {
                    PipelineValue = pipelineValue,
                    PipelineValueLabel = FormatBillions(pipelineValue),
                    Target = stage == "L3" ? L3StaticTarget : pipelineValue,
                    TargetLabel = stage == "L3" ? FormatBillions(L3StaticTarget) : FormatBillions(pipelineValue),
                    ProgressPercentage = stage == "L3" ? ComputePercentage(pipelineValue, L3StaticTarget) : 100
                },
                Deals = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = filteredDeals.Count,
                    TotalPages = (int)Math.Ceiling((double)filteredDeals.Count / limit),
                    CurrentPage = page,
                    ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return null;
        }
    }

    // L0: leads with no QFZ number assigned yet (qfza_qfznumber eq null) have no hexa_request record,
    // so they're sourced from the leads entity instead. Same source query as DealService's L0 handling.
    private async Task<PipelineStageDetail?> GetL0StageDetailsAsync(int page, int limit)
    {
        try
        {
            var json = await _d365.GetListAsync("leads",
                "$select=leadid,subject,fullname,createdon,statecode,statuscode"
                + "&$filter=qfza_qfznumber eq null"
                + "&$expand=owninguser($select=fullname),owningteam($select=name)");
            var allDeals = _d365.GetValueArray(json).Select(ToLeadStageDeal).ToList();

            var skip = (page - 1) * limit;
            var pagedDeals = allDeals.Skip(skip).Take(limit).ToList();

            return new PipelineStageDetail
            {
                Stage = "L0",
                StageLabel = StageLabels["L0"],
                SubLabel = "Leads with no QFZ number assigned yet",
                LastUpdated = DateTime.UtcNow,
                SummaryMetrics = new StageSummaryMetrics
                {
                    PipelineValue = 0,
                    PipelineValueLabel = FormatBillions(0),
                    Target = 0,
                    TargetLabel = FormatBillions(0),
                    ProgressPercentage = 0
                },
                Deals = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = allDeals.Count,
                    TotalPages = (int)Math.Ceiling((double)allDeals.Count / limit),
                    CurrentPage = page,
                    ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return null;
        }
    }

    private StageDeal ToLeadStageDeal(JsonElement r)
    {
        var state = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
            ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");

        return new StageDeal
        {
            DealId = StripBraces(_d365.GetGuid(r, "leadid")?.ToString() ?? ""),
            DealName = _d365.GetString(r, "subject") ?? _d365.GetString(r, "fullname") ?? "Unnamed Lead",
            OwnerName = ResolveOwnerName(r),
            CurrentStage = "L0",
            CurrentStageLabel = StageDisplayLabels["L0"],
            DealStatus = state,
            CapexAmount = null,
            CapexCurrency = "QAR",
        };
    }

    // L4/L5: deals at these stages live on the account's action tracker steps, not hexa_requests.
    private async Task<PipelineStageDetail?> GetAccountPipelineStageDetailsAsync(string stage, string fetchXml, int page, int limit)
    {
        try
        {
            // Fix 1: run accounts fetch and investment total in parallel
            var accountsTask = _d365.GetListAsync("accounts", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var investTask = stage == "L4" ? FetchInvestmentTotalAsync(L4InvestmentFetchXml) : Task.FromResult(0m);
            await Task.WhenAll(accountsTask, investTask);

            var allDeals = _d365.GetValueArray(accountsTask.Result).Select(r => ToAccountStageDeal(r, stage)).ToList();
            var pipelineValue = investTask.Result;
            var target = stage == "L4" ? L4StaticTarget : 0;

            var skip = (page - 1) * limit;
            var pagedDeals = allDeals.Skip(skip).Take(limit).ToList();

            return new PipelineStageDetail
            {
                Stage = stage,
                StageLabel = StageLabels[stage],
                SubLabel = $"Accounts active in the {stage} pipeline",
                LastUpdated = DateTime.UtcNow,
                SummaryMetrics = new StageSummaryMetrics
                {
                    PipelineValue = pipelineValue,
                    PipelineValueLabel = FormatBillions(pipelineValue),
                    Target = target,
                    TargetLabel = FormatBillions(target),
                    ProgressPercentage = ComputePercentage(pipelineValue, target)
                },
                Deals = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = allDeals.Count,
                    TotalPages = (int)Math.Ceiling((double)allDeals.Count / limit),
                    CurrentPage = page,
                    ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return null;
        }
    }

    private StageDeal ToAccountStageDeal(JsonElement r, string stage)
    {
        var state = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
            ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");

        return new StageDeal
        {
            DealId = StripBraces(_d365.GetGuid(r, "accountid")?.ToString() ?? ""),
            DealName = _d365.GetString(r, "name") ?? "Unnamed Account",
            OwnerName = _d365.GetFormattedValue(r, "_ownerid_value") ?? "",
            CurrentStage = stage,
            CurrentStageLabel = StageDisplayLabels[stage],
            DealStatus = state,
            CapexAmount = null,
            CapexCurrency = "QAR",
        };
    }

    private StageDeal ToStageDeal(JsonElement r)
    {
        var state           = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
                              ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");
        var internalStatus  = _d365.GetFormattedValue(r, "_hexa_internalstatus_value") ?? "";
        var processTemplate = _d365.GetFormattedValue(r, "_hexa_processtemplate_value") ?? "";
        var stage           = ResolveStage(processTemplate, state, internalStatus);

        var capexMil    = _d365.GetDecimal(r, "qfza_capexmil");
        var cumulativeInv = _d365.GetDecimal(r, "qfza_cumulativeinvestmentmoney");
        var capexAmount = cumulativeInv ?? (capexMil.HasValue ? capexMil * 1000000 : null);

        return new StageDeal
        {
            DealId = StripBraces(_d365.GetGuid(r, "hexa_requestid")?.ToString() ?? ""),
            DealName = _d365.GetString(r, "hexa_name") ?? "Unnamed Request",
            OwnerName = ResolveOwnerName(r),
            CurrentStage = stage,
            CurrentStageLabel = StageDisplayLabels.GetValueOrDefault(stage, stage),
            DealStatus = state,
            CapexAmount = capexAmount,
            CapexCurrency = "QAR",
        };
    }

    private string ResolveOwnerName(JsonElement r) =>
        _d365.GetNestedString(r, "owninguser", "fullname")
        ?? _d365.GetNestedString(r, "owningteam", "name")
        ?? "";

    // Fix 2: single batch CAPEX query for all account IDs on the page — replaces N+1 per-deal calls.
    private async Task<Dictionary<Guid, decimal>> FetchCapexBatchAsync(List<Guid> accountIds)
    {
        if (accountIds.Count == 0) return [];
        try
        {
            var inValues = string.Concat(accountIds.Select(id => $"<value>{id:D}</value>"));
            var fetchXml = "<fetch><entity name=\"qfza_grandeconomicanalysis\">" +
                           "<attribute name=\"qfza_totalcapex\" />" +
                           "<attribute name=\"_qfza_investorid_value\" />" +
                           "<filter><condition attribute=\"qfza_investorid\" operator=\"in\">" +
                           inValues + "</condition></filter>" +
                           "</entity></fetch>";
            var json = await _d365.GetListAsync("qfza_grandeconomicanalysises", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var result = new Dictionary<Guid, decimal>();
            foreach (var item in _d365.GetValueArray(json))
            {
                var investorId = _d365.GetGuid(item, "_qfza_investorid_value");
                var capex = _d365.GetDecimal(item, "qfza_totalcapex") ?? 0;
                if (investorId.HasValue)
                    result[investorId.Value] = result.GetValueOrDefault(investorId.Value) + capex;
            }
            return result;
        }
        catch
        {
            return [];
        }
    }

    private static string StripBraces(string id) => id.Replace("{", "").Replace("}", "");

    private static string FormatBillions(decimal value) => $"${value / 1000000000M:F2}B";

    private static decimal ComputePercentage(decimal value, decimal target) =>
        target > 0 ? Math.Round(value / target * 100, 1) : 0;
}
