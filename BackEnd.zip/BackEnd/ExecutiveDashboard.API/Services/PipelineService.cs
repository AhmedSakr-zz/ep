using System.Text.Json;
using ExecutiveDashboard.API.Models;

namespace ExecutiveDashboard.API.Services;

public interface IPipelineService
{
    Task<PipelineStageDetail?> GetStageDetailsAsync(string stage, int page, int limit);
}

public class PipelineService : IPipelineService
{
    private readonly ID365Service _d365;

    // Matches DashboardService's L3StaticTarget2026/L4StaticTarget2026 so the pipeline stage detail
    // card and the overview's L3VsTarget/L4VsTarget card agree on the same targets.
    private const decimal L3StaticTarget = 2000000000m;
    private const decimal L4StaticTarget = 250000000m;

    // L3/L4 pipeline value: same source as DashboardService's L3VsTarget/L4VsTarget — qualifying
    // requests joined through their investor account to qfza_grandeconomicanalysis, summing
    // qfza_totalinvestmentsize. Kept identical to DashboardService.L3InvestmentFetchXml/L4InvestmentFetchXml.
    private const string L3InvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><attribute name=\"hexa_name\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"createdon\" operator=\"on-or-after\" value=\"2026-01-01\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"56c1a88f-96db-ee11-904b-000d3a683c1b\" uiname=\"Cancelled\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"8deb3274-437e-ee11-8179-0022489fd7a3\" uiname=\"Draft\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"c0f16dfa-c4db-ee11-904b-000d3a64f065\" uiname=\"Rejected\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"43bf51a5-20d7-4d85-a080-f6491bd75d0e\" uiname=\"Lead Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<attribute name=\"name\" />" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    private const string L4InvestmentFetchXml =
        "<fetch><entity name=\"hexa_request\"><attribute name=\"hexa_name\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"createdon\" operator=\"on-or-after\" value=\"2026-01-01\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"56c1a88f-96db-ee11-904b-000d3a683c1b\" uiname=\"Cancelled\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"c0f16dfa-c4db-ee11-904b-000d3a64f065\" uiname=\"Rejected\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"70681513-8c21-ef11-840a-0022489c4c2a\" uiname=\"License Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"account\" from=\"accountid\" to=\"hexa_customer\" link-type=\"inner\" alias=\"customer\">" +
        "<attribute name=\"name\" />" +
        "<link-entity name=\"qfza_grandeconomicanalysis\" from=\"qfza_investorid\" to=\"accountid\" link-type=\"inner\" alias=\"grandEconomicData\">" +
        "<attribute name=\"qfza_totalinvestmentsize\" />" +
        "</link-entity></link-entity></entity></fetch>";

    private async Task<decimal> FetchInvestmentTotalAsync(string fetchXml)
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            return _d365.GetValueArray(json).Sum(i => _d365.GetDecimal(i, "grandEconomicData.qfza_totalinvestmentsize") ?? 0);
        }
        catch
        {
            return 0;
        }
    }

    // L1: hexa_requests in the Lead Application process, not Draft/Inactive, with a current step
    // resolving to a KPI instance (ensures the request has progressed into an active review step).
    // Size/Power Demand come straight off the request; CAPEX and Deal Owner are sourced separately
    // (CAPEX from the linked account's Grand Economic Analysis, Owner from the "BD Review Stage 1" step).
    private const string L1RequestsFetchXml =
        "<fetch><entity name=\"hexa_request\">" +
        "<attribute name=\"hexa_requestid\" /><attribute name=\"createdon\" /><attribute name=\"hexa_name\" />" +
        "<attribute name=\"qfza_facilitysizeinsqme\" /><attribute name=\"qfza_electricity\" />" +
        "<attribute name=\"hexa_customer\" />" +
        "<filter type=\"and\">" +
        "<condition attribute=\"createdon\" operator=\"on-or-after\" value=\"2026-01-01\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"ne\" value=\"8deb3274-437e-ee11-8179-0022489fd7a3\" uiname=\"Draft\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"statecode\" operator=\"ne\" value=\"1\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"43bf51a5-20d7-4d85-a080-f6491bd75d0e\" uiname=\"Lead Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"hexa_requeststep\" from=\"hexa_requeststepid\" to=\"hexa_currentstep\" link-type=\"inner\" alias=\"currentStep\">" +
        "<link-entity name=\"slakpiinstance\" from=\"slakpiinstanceid\" to=\"qfza_resolvebykpiid\" link-type=\"inner\" alias=\"ResolveByKPI\">" +
        "<attribute name=\"status\" />" +
        "</link-entity></link-entity></entity></fetch>";

    // L2: same shape as L1RequestsFetchXml, but for Lead Application requests that have been Approved
    // (internalstatus Approved, statecode Inactive) instead of still in progress.
    private const string L2RequestsFetchXml =
        "<fetch><entity name=\"hexa_request\">" +
        "<attribute name=\"hexa_requestid\" /><attribute name=\"createdon\" /><attribute name=\"hexa_name\" />" +
        "<attribute name=\"qfza_facilitysizeinsqme\" /><attribute name=\"qfza_electricity\" />" +
        "<attribute name=\"hexa_customer\" />" +
        "<filter type=\"and\">" +
        "<condition attribute=\"createdon\" operator=\"on-or-after\" value=\"2026-01-01\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"eq\" value=\"be3c386e-437e-ee11-8179-0022489fd7a3\" uiname=\"Approved\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"1\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"43bf51a5-20d7-4d85-a080-f6491bd75d0e\" uiname=\"Lead Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"hexa_requeststep\" from=\"hexa_requeststepid\" to=\"hexa_currentstep\" link-type=\"inner\" alias=\"currentStep\">" +
        "<link-entity name=\"slakpiinstance\" from=\"slakpiinstanceid\" to=\"qfza_resolvebykpiid\" link-type=\"inner\" alias=\"ResolveByKPI\">" +
        "<attribute name=\"status\" />" +
        "</link-entity></link-entity></entity></fetch>";

    // L3: same shape as L1/L2RequestsFetchXml, but for License Application requests that have been
    // Approved (internalstatus Approved, statecode Inactive). Only the grid's per-deal fields (name,
    // size, power, owner, CAPEX) come from this — the stage's SummaryMetrics stay on
    // L3InvestmentFetchXml/L3StaticTarget so the pipeline modal keeps agreeing with the overview's
    // L3VsTarget card.
    private const string L3RequestsFetchXml =
        "<fetch><entity name=\"hexa_request\">" +
        "<attribute name=\"hexa_requestid\" /><attribute name=\"createdon\" /><attribute name=\"hexa_name\" />" +
        "<attribute name=\"qfza_facilitysizeinsqme\" /><attribute name=\"qfza_electricity\" />" +
        "<attribute name=\"hexa_customer\" />" +
        "<filter type=\"and\">" +
        "<condition attribute=\"createdon\" operator=\"on-or-after\" value=\"2026-01-01\" />" +
        "<condition attribute=\"hexa_internalstatus\" operator=\"eq\" value=\"be3c386e-437e-ee11-8179-0022489fd7a3\" uiname=\"Approved\" uitype=\"hexa_processstatustemplate\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"1\" />" +
        "<condition attribute=\"hexa_processtemplate\" operator=\"eq\" value=\"70681513-8c21-ef11-840a-0022489c4c2a\" uiname=\"License Application\" uitype=\"hexa_processtemplate\" />" +
        "</filter>" +
        "<link-entity name=\"hexa_requeststep\" from=\"hexa_requeststepid\" to=\"hexa_currentstep\" link-type=\"inner\" alias=\"currentStep\">" +
        "<link-entity name=\"slakpiinstance\" from=\"slakpiinstanceid\" to=\"qfza_resolvebykpiid\" link-type=\"inner\" alias=\"ResolveByKPI\">" +
        "<attribute name=\"status\" />" +
        "</link-entity></link-entity></entity></fetch>";

    // Deal Owner: most recent "BD Review Stage 1" step per request, joined to its owning systemuser.
    // {0} is substituted with <value>{requestId}</value> entries for a batch "in" lookup.
    private const string DealOwnerFetchXmlTemplate =
        "<fetch><entity name=\"hexa_requeststep\">" +
        "<attribute name=\"hexa_name\" /><attribute name=\"hexa_request\" /><attribute name=\"createdon\" />" +
        "<filter type=\"and\">" +
        "<condition attribute=\"hexa_name\" operator=\"eq\" value=\"BD Review Stage 1\" />" +
        "<condition attribute=\"hexa_request\" operator=\"in\">{0}</condition>" +
        "</filter>" +
        "<order attribute=\"createdon\" descending=\"true\" />" +
        "<link-entity name=\"systemuser\" from=\"systemuserid\" to=\"ownerid\" link-type=\"inner\" alias=\"owner\">" +
        "<attribute name=\"fullname\" /><attribute name=\"internalemailaddress\" /><attribute name=\"systemuserid\" />" +
        "</link-entity></entity></fetch>";

    // Batched per-request owner lookup — one query for the page instead of one call per deal.
    // Results are ordered by createdon descending, so the first row seen per request is the latest step.
    private async Task<Dictionary<Guid, string>> FetchDealOwnersBatchAsync(List<Guid> requestIds)
    {
        if (requestIds.Count == 0) return [];
        try
        {
            var inValues = string.Concat(requestIds.Select(id => $"<value>{id:D}</value>"));
            var fetchXml = string.Format(DealOwnerFetchXmlTemplate, inValues);
            var json = await _d365.GetListAsync("hexa_requeststeps", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var result = new Dictionary<Guid, string>();
            foreach (var item in _d365.GetValueArray(json))
            {
                var requestId = _d365.GetGuid(item, "_hexa_request_value");
                var ownerName = _d365.GetString(item, "owner.fullname");
                if (requestId.HasValue && ownerName != null && !result.ContainsKey(requestId.Value))
                    result[requestId.Value] = ownerName;
            }
            return result;
        }
        catch
        {
            return [];
        }
    }

    private static readonly Dictionary<string, string> StageLabels = new()
    {
        ["L0"] = "L0 (PreApplication Created)",
        ["L1"] = "L1 (Application Submission)", ["L2"] = "L2 (Application Approved)",
        ["L3"] = "L3 (License Granted)", ["L4"] = "L4 (Construction Started)",
        ["L5"] = "L5 (Construction Completed)"
    };

    private static readonly Dictionary<string, string> StageDisplayLabels = new()
    {
        ["L0"] = "PreApplication Created",
        ["L1"] = "Application Submission", ["L2"] = "Application Approved",
        ["L3"] = "License Granted", ["L4"] = "Construction Started",
        ["L5"] = "Construction Completed"
    };

    // L4/L5: registered accounts (active, company status 548240000) with an action tracker step at the
    // corresponding pipeline stage (401820004 = L4, 401820005 = L5) whose actionstatus is Open
    // (401820004) and not Completed (401820005), joined through to the tied hexa_request for the grid's
    // Land Size/Power Demand fields. An account can have more than one qualifying action-tracker step
    // (and so more than one joined request row) — deduped per account in GetAccountPipelineStageDetailsAsync.
    private const string L4PipelineAccountsFetchXml =
        "<fetch distinct=\"true\"><entity name=\"account\">" +
        "<attribute name=\"accountid\" /><attribute name=\"name\" /><attribute name=\"ownerid\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"createdon\" operator=\"on-or-after\" value=\"2026-01-01\" />" +
        "<condition attribute=\"qfza_companystatus\" operator=\"eq\" value=\"548240000\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
        "</filter>" +
        "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionSteps\">" +
        "<attribute name=\"qfza_requestid\" />" +
        "<filter>" +
        "<condition attribute=\"qfza_pipeline\" operator=\"eq\" value=\"401820004\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"eq\" value=\"401820004\" />" +
        "</filter>" +
        "<link-entity name=\"hexa_request\" from=\"hexa_requestid\" to=\"qfza_requestid\" link-type=\"inner\" alias=\"requestDetails\">" +
        "<attribute name=\"hexa_requestid\" /><attribute name=\"hexa_name\" />" +
        "<attribute name=\"qfza_facilitysizeinsqme\" /><attribute name=\"qfza_electricity\" />" +
        "</link-entity>" +
        "</link-entity></entity></fetch>";

    // Same shape as L4PipelineAccountsFetchXml — qfza_pipeline 401820005 identifies L5 action tracker
    // steps (matches the count query DashboardService already used before this grid was added).
    private const string L5PipelineAccountsFetchXml =
        "<fetch distinct=\"true\"><entity name=\"account\">" +
        "<attribute name=\"accountid\" /><attribute name=\"name\" /><attribute name=\"ownerid\" /><attribute name=\"createdon\" />" +
        "<filter>" +
        "<condition attribute=\"createdon\" operator=\"on-or-after\" value=\"2026-01-01\" />" +
        "<condition attribute=\"qfza_companystatus\" operator=\"eq\" value=\"548240000\" />" +
        "<condition attribute=\"statecode\" operator=\"eq\" value=\"0\" />" +
        "</filter>" +
        "<link-entity name=\"qfza_actiontrackersteps\" from=\"qfza_accountid\" to=\"accountid\" link-type=\"inner\" alias=\"actionSteps\">" +
        "<attribute name=\"qfza_requestid\" />" +
        "<filter>" +
        "<condition attribute=\"qfza_pipeline\" operator=\"eq\" value=\"401820005\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"ne\" value=\"401820005\" />" +
        "<condition attribute=\"qfza_actionstatus\" operator=\"eq\" value=\"401820004\" />" +
        "</filter>" +
        "<link-entity name=\"hexa_request\" from=\"hexa_requestid\" to=\"qfza_requestid\" link-type=\"inner\" alias=\"requestDetails\">" +
        "<attribute name=\"hexa_requestid\" /><attribute name=\"hexa_name\" />" +
        "<attribute name=\"qfza_facilitysizeinsqme\" /><attribute name=\"qfza_electricity\" />" +
        "</link-entity>" +
        "</link-entity></entity></fetch>";

    public PipelineService(ID365Service d365)
    {
        _d365 = d365;
    }

    public Task<PipelineStageDetail?> GetStageDetailsAsync(string stage, int page, int limit)
    {
        if (!StageLabels.ContainsKey(stage))
            return Task.FromResult<PipelineStageDetail?>(null);

        return stage switch
        {
            "L0" => GetL0StageDetailsAsync(page, limit),
            "L1" => GetLeadStageDetailsAsync("L1", L1RequestsFetchXml, "Active", page, limit),
            "L2" => GetLeadStageDetailsAsync("L2", L2RequestsFetchXml, "Inactive", page, limit),
            "L3" => GetL3StageDetailsAsync(page, limit),
            "L4" => GetAccountPipelineStageDetailsAsync("L4", L4PipelineAccountsFetchXml, page, limit),
            "L5" => GetAccountPipelineStageDetailsAsync("L5", L5PipelineAccountsFetchXml, page, limit),
            _ => Task.FromResult<PipelineStageDetail?>(null)
        };
    }

    // L3: deal name, size, and power demand come straight off the request; CAPEX and Deal Owner are
    // sourced the same way as L1/L2 (CAPEX via the linked account's Grand Economic Analysis, Owner via
    // the "BD Review Stage 1" step). SummaryMetrics stay on L3InvestmentFetchXml/L3StaticTarget so the
    // pipeline modal's L3 card keeps agreeing with the overview's L3VsTarget card.
    private async Task<PipelineStageDetail?> GetL3StageDetailsAsync(int page, int limit)
    {
        try
        {
            var dataTask = _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(L3RequestsFetchXml)}");
            var investTask = FetchInvestmentTotalAsync(L3InvestmentFetchXml);
            await Task.WhenAll(dataTask, investTask);

            var allDeals = _d365.GetValueArray(dataTask.Result)
                .Select(r => (
                    Deal: ToLeadStageDeal(r, "L3", "Inactive"),
                    AccountId: _d365.GetGuid(r, "_hexa_customer_value"),
                    RequestId: _d365.GetGuid(r, "hexa_requestid")))
                .ToList();

            var pipelineValue = investTask.Result;

            var skip = (page - 1) * limit;
            var pagedSlice = allDeals.Skip(skip).Take(limit).ToList();

            var accountIds = pagedSlice.Where(x => x.AccountId.HasValue).Select(x => x.AccountId!.Value).ToList();
            var capexByAccount = await FetchCapexBatchAsync(accountIds);
            foreach (var (deal, accountId, _) in pagedSlice)
            {
                if (accountId.HasValue && capexByAccount.TryGetValue(accountId.Value, out var capex))
                {
                    deal.CapexAmount = capex;
                    deal.CapexLabel = FormatCapexLabel(capex);
                }
            }

            var requestIds = pagedSlice.Where(x => x.RequestId.HasValue).Select(x => x.RequestId!.Value).ToList();
            var ownersByRequest = await FetchDealOwnersBatchAsync(requestIds);
            foreach (var (deal, _, requestId) in pagedSlice)
            {
                if (requestId.HasValue && ownersByRequest.TryGetValue(requestId.Value, out var owner))
                    deal.OwnerName = owner;
            }
            var pagedDeals = pagedSlice.Select(x => x.Deal).ToList();

            return new PipelineStageDetail
            {
                Stage = "L3",
                StageLabel = StageLabels["L3"],
                SubLabel = "Deals converted to L3 from Jan 2026",
                LastUpdated = DateTime.UtcNow,
                SummaryMetrics = new StageSummaryMetrics
                {
                    PipelineValue = pipelineValue,
                    PipelineValueLabel = FormatBillions(pipelineValue),
                    Target = L3StaticTarget,
                    TargetLabel = FormatBillions(L3StaticTarget),
                    ProgressPercentage = ComputePercentage(pipelineValue, L3StaticTarget)
                },
                Deals = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = allDeals.Count,
                    TotalPages = (int)Math.Ceiling((double)allDeals.Count / limit),
                    CurrentPage = page,
                    ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return null;
        }
    }

    // L1/L2: deal name, size, and power demand come straight off the request; CAPEX is looked up via
    // the linked account's Grand Economic Analysis, and Deal Owner via the request's "BD Review Stage 1"
    // step. The two stages differ only in the fetchXml filter (in-progress vs. Approved) and DealStatus.
    private async Task<PipelineStageDetail?> GetLeadStageDetailsAsync(string stage, string fetchXml, string dealStatus, int page, int limit)
    {
        try
        {
            var json = await _d365.GetListAsync("hexa_requests", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var allDeals = _d365.GetValueArray(json)
                .Select(r => (
                    Deal: ToLeadStageDeal(r, stage, dealStatus),
                    AccountId: _d365.GetGuid(r, "_hexa_customer_value"),
                    RequestId: _d365.GetGuid(r, "hexa_requestid")))
                .ToList();

            var accountIds = allDeals.Where(x => x.AccountId.HasValue).Select(x => x.AccountId!.Value).Distinct().ToList();
            var capexByAccount = await FetchCapexBatchAsync(accountIds);
            foreach (var (deal, accountId, _) in allDeals)
            {
                if (accountId.HasValue && capexByAccount.TryGetValue(accountId.Value, out var capex))
                {
                    deal.CapexAmount = capex;
                    deal.CapexLabel = FormatCapexLabel(capex);
                }
            }

            var filteredDeals = allDeals.Select(x => x.Deal).ToList();
            var pipelineValue = filteredDeals.Sum(d => d.CapexAmount ?? 0);

            var skip = (page - 1) * limit;
            var pagedSlice = allDeals.Skip(skip).Take(limit).ToList();

            var requestIds = pagedSlice.Where(x => x.RequestId.HasValue).Select(x => x.RequestId!.Value).ToList();
            var ownersByRequest = await FetchDealOwnersBatchAsync(requestIds);
            foreach (var (deal, _, requestId) in pagedSlice)
            {
                if (requestId.HasValue && ownersByRequest.TryGetValue(requestId.Value, out var owner))
                    deal.OwnerName = owner;
            }
            var pagedDeals = pagedSlice.Select(x => x.Deal).ToList();

            return new PipelineStageDetail
            {
                Stage = stage,
                StageLabel = StageLabels[stage],
                SubLabel = $"Deals converted to {stage} from Jan 2026",
                LastUpdated = DateTime.UtcNow,
                SummaryMetrics = new StageSummaryMetrics
                {
                    PipelineValue = pipelineValue,
                    PipelineValueLabel = FormatBillions(pipelineValue),
                    Target = pipelineValue,
                    TargetLabel = FormatBillions(pipelineValue),
                    ProgressPercentage = 100
                },
                Deals = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = filteredDeals.Count,
                    TotalPages = (int)Math.Ceiling((double)filteredDeals.Count / limit),
                    CurrentPage = page,
                    ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return null;
        }
    }

    private StageDeal ToLeadStageDeal(JsonElement r, string stage, string dealStatus) => new()
    {
        DealId = StripBraces(_d365.GetGuid(r, "hexa_requestid")?.ToString() ?? ""),
        DealName = _d365.GetString(r, "hexa_name") ?? "Unnamed Request",
        OwnerName = "",
        CurrentStage = stage,
        CurrentStageLabel = StageDisplayLabels[stage],
        DealStatus = dealStatus,
        CapexAmount = null,
        CapexCurrency = "QAR",
        // qfza_facilitysizeinsqme is a CRM choice field (e.g. "3,000 - 10,000"), not a raw number —
        // resolve its label rather than reading it as a decimal.
        LandSizeLabel = _d365.GetFormattedValue(r, "qfza_facilitysizeinsqme"),
        PowerDemandMw = _d365.GetDecimal(r, "qfza_electricity"),
    };

    // L0: leads with no QFZ number assigned yet (qfza_qfznumber eq null) have no hexa_request record,
    // so they're sourced from the leads entity instead. Same source query as DealService's L0 handling.
    private async Task<PipelineStageDetail?> GetL0StageDetailsAsync(int page, int limit)
    {
        try
        {
            var json = await _d365.GetListAsync("leads",
                "$select=leadid,subject,fullname,createdon,statecode,statuscode,"
                + "qfza_capexqarmn,qfza_l0actualdate,qfza_landsizesqm,qfza_powerdemandmw"
                + "&$filter=qfza_qfznumber eq null and createdon ge 2026-01-01T00:00:00Z"
                + "&$expand=owninguser($select=fullname),owningteam($select=name)");
            var allDeals = _d365.GetValueArray(json).Select(ToLeadStageDeal).ToList();

            var skip = (page - 1) * limit;
            var pagedDeals = allDeals.Skip(skip).Take(limit).ToList();

            return new PipelineStageDetail
            {
                Stage = "L0",
                StageLabel = StageLabels["L0"],
                SubLabel = "Leads with no QFZ number assigned yet",
                LastUpdated = DateTime.UtcNow,
                SummaryMetrics = new StageSummaryMetrics
                {
                    PipelineValue = 0,
                    PipelineValueLabel = FormatBillions(0),
                    Target = 0,
                    TargetLabel = FormatBillions(0),
                    ProgressPercentage = 0
                },
                Deals = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = allDeals.Count,
                    TotalPages = (int)Math.Ceiling((double)allDeals.Count / limit),
                    CurrentPage = page,
                    ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return null;
        }
    }

    private StageDeal ToLeadStageDeal(JsonElement r)
    {
        var state = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
            ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");

        // qfza_capexqarmn is CAPEX in QAR millions, same convention as hexa_request's qfza_capexmil.
        var capexQarMn = _d365.GetDecimal(r, "qfza_capexqarmn");
        var capexAmount = capexQarMn.HasValue ? capexQarMn * 1000000 : null;

        return new StageDeal
        {
            DealId = StripBraces(_d365.GetGuid(r, "leadid")?.ToString() ?? ""),
            DealName = _d365.GetString(r, "subject") ?? _d365.GetString(r, "fullname") ?? "Unnamed Lead",
            OwnerName = ResolveOwnerName(r),
            CurrentStage = "L0",
            CurrentStageLabel = StageDisplayLabels["L0"],
            DealStatus = state,
            CapexAmount = capexAmount,
            CapexCurrency = "QAR",
            CapexLabel = capexAmount.HasValue ? FormatCapexLabel(capexAmount.Value) : null,
            ForecastDate = _d365.GetDateTime(r, "qfza_l0actualdate")?.ToString("yyyy-MM-dd"),
            LandSizeSqm = _d365.GetDecimal(r, "qfza_landsizesqm"),
            PowerDemandMw = _d365.GetDecimal(r, "qfza_powerdemandmw"),
        };
    }

    // L4/L5: deals at these stages live on the account's action tracker steps, not hexa_requests.
    // CAPEX is looked up via the account's own Grand Economic Analysis (the account is already the
    // primary entity here, unlike L1/L2/L3 where it's reached through the request's customer lookup).
    private async Task<PipelineStageDetail?> GetAccountPipelineStageDetailsAsync(string stage, string fetchXml, int page, int limit)
    {
        try
        {
            // Fix 1: run accounts fetch and investment total in parallel
            var accountsTask = _d365.GetListAsync("accounts", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var investTask = stage == "L4" ? FetchInvestmentTotalAsync(L4InvestmentFetchXml) : Task.FromResult(0m);
            await Task.WhenAll(accountsTask, investTask);

            // An account can have more than one qualifying action-tracker step, so more than one joined
            // request row — keep the first row seen per account for the grid's request-derived fields.
            var rowsByAccount = _d365.GetValueArray(accountsTask.Result)
                .GroupBy(r => _d365.GetGuid(r, "accountid"))
                .Where(g => g.Key.HasValue)
                .ToDictionary(g => g.Key!.Value, g => g.First());

            var allDeals = rowsByAccount
                .Select(kv => (Deal: ToAccountStageDeal(kv.Value, stage), AccountId: kv.Key))
                .ToList();
            var pipelineValue = investTask.Result;
            var target = stage == "L4" ? L4StaticTarget : 0;

            var skip = (page - 1) * limit;
            var pagedSlice = allDeals.Skip(skip).Take(limit).ToList();

            var accountIds = pagedSlice.Select(x => x.AccountId).ToList();
            var capexByAccount = await FetchCapexBatchAsync(accountIds);
            foreach (var (deal, accountId) in pagedSlice)
            {
                if (capexByAccount.TryGetValue(accountId, out var capex))
                {
                    deal.CapexAmount = capex;
                    deal.CapexLabel = FormatCapexLabel(capex);
                }
            }
            var pagedDeals = pagedSlice.Select(x => x.Deal).ToList();

            return new PipelineStageDetail
            {
                Stage = stage,
                StageLabel = StageLabels[stage],
                SubLabel = $"Accounts active in the {stage} pipeline",
                LastUpdated = DateTime.UtcNow,
                SummaryMetrics = new StageSummaryMetrics
                {
                    PipelineValue = pipelineValue,
                    PipelineValueLabel = FormatBillions(pipelineValue),
                    Target = target,
                    TargetLabel = FormatBillions(target),
                    ProgressPercentage = ComputePercentage(pipelineValue, target)
                },
                Deals = pagedDeals,
                Pagination = new PaginationInfo
                {
                    TotalItems = allDeals.Count,
                    TotalPages = (int)Math.Ceiling((double)allDeals.Count / limit),
                    CurrentPage = page,
                    ItemsPerPage = limit
                }
            };
        }
        catch
        {
            return null;
        }
    }

    private StageDeal ToAccountStageDeal(JsonElement r, string stage)
    {
        var state = _d365.GetString(r, "statecode@OData.Community.Display.V1.FormattedValue")
            ?? (_d365.GetInt(r, "statecode") == 1 ? "Inactive" : "Active");

        return new StageDeal
        {
            DealId = StripBraces(_d365.GetGuid(r, "accountid")?.ToString() ?? ""),
            DealName = _d365.GetString(r, "name") ?? "Unnamed Account",
            OwnerName = _d365.GetFormattedValue(r, "_ownerid_value") ?? "",
            CurrentStage = stage,
            CurrentStageLabel = StageDisplayLabels[stage],
            DealStatus = state,
            CapexAmount = null,
            CapexCurrency = "QAR",
            // qfza_facilitysizeinsqme is a CRM choice field (e.g. "3,000 - 10,000"), not a raw number —
            // resolve its label rather than reading it as a decimal.
            LandSizeLabel = _d365.GetFormattedValue(r, "requestDetails.qfza_facilitysizeinsqme"),
            PowerDemandMw = _d365.GetDecimal(r, "requestDetails.qfza_electricity"),
        };
    }

    private string ResolveOwnerName(JsonElement r) =>
        _d365.GetNestedString(r, "owninguser", "fullname")
        ?? _d365.GetNestedString(r, "owningteam", "name")
        ?? "";

    // Fix 2: single batch CAPEX query for all account IDs on the page — replaces N+1 per-deal calls.
    private async Task<Dictionary<Guid, decimal>> FetchCapexBatchAsync(List<Guid> accountIds)
    {
        if (accountIds.Count == 0) return [];
        try
        {
            var inValues = string.Concat(accountIds.Select(id => $"<value>{id:D}</value>"));
            var fetchXml = "<fetch><entity name=\"qfza_grandeconomicanalysis\">" +
                           "<attribute name=\"qfza_totalcapex\" />" +
                           "<attribute name=\"_qfza_investorid_value\" />" +
                           "<filter><condition attribute=\"qfza_investorid\" operator=\"in\">" +
                           inValues + "</condition></filter>" +
                           "</entity></fetch>";
            var json = await _d365.GetListAsync("qfza_grandeconomicanalysises", $"fetchXml={Uri.EscapeDataString(fetchXml)}");
            var result = new Dictionary<Guid, decimal>();
            foreach (var item in _d365.GetValueArray(json))
            {
                var investorId = _d365.GetGuid(item, "_qfza_investorid_value");
                var capex = _d365.GetDecimal(item, "qfza_totalcapex") ?? 0;
                if (investorId.HasValue)
                    result[investorId.Value] = result.GetValueOrDefault(investorId.Value) + capex;
            }
            return result;
        }
        catch
        {
            return [];
        }
    }

    private static string StripBraces(string id) => id.Replace("{", "").Replace("}", "");

    private static string FormatBillions(decimal value) => $"${value / 1000000000M:F2}B";

    private static string FormatCapexLabel(decimal amount) => $"QAR {amount / 1000000M:F1}M";

    private static decimal ComputePercentage(decimal value, decimal target) =>
        target > 0 ? Math.Round(value / target * 100, 1) : 0;
}
