/** @type {import('tailwindcss').Config} */
import PrimeUI from "tailwindcss-primeui";

module.exports = {
  darkMode: "class", // Enables standard class-based dark mode (looks for .dark)
  content: [
    "./src/**/*.{html,ts}", // Scans all Angular templates and component logic
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Montserrat", "system-ui", "sans-serif"],
      },
      colors: {
        // Navy – dark card / sidebar accents
        ...{ primaryBtn: "#0066FF", secondaryBtn: "#0048B5" },
        navy: {
          50: "#f0f4fa",
          100: "#d9e3f0",
          200: "#b3c7e1",
          300: "#7fa0c8",
          400: "#4d79b0",
          500: "#2b5799",
          600: "#1e4080",
          700: "#163066",
          800: "#0f2048",
          900: "#0a1a38",
          950: "#060f22",
        },
        // Brand blue – interactive / progress
        brand: {
          50: "#eff6ff",
          100: "#dbeafe",
          200: "#bfdbfe",
          300: "#93c5fd",
          400: "#60a5fa",
          500: "#3b82f6",
          600: "#2563eb",
          700: "#1d4ed8",
          800: "#1e40af",
          900: "#1e3a8a",
        },
        // Status configurations
        success: {
          50: "#ecfdf5",
          100: "#d1fae5",
          500: "#10b981",
          600: "#059669",
          700: "#047857",
        },
        warning: {
          50: "#fffbeb",
          100: "#fef3c7",
          500: "#f59e0b",
          600: "#d97706",
        },
        danger: {
          50: "#fef2f2",
          100: "#fee2e2",
          500: "#ef4444",
          600: "#dc2626",
        },
      },
      borderRadius: {
        card: "0.75rem",
      },
    },
  },
  plugins: [PrimeUI], // Bridges your custom palette smoothly into PrimeNG elements
};
