# Executive Dashboard API Specification

## 1. Dashboard Overview & Filtering

- **Method:** `GET`
- **URL:** `dashboard/overview`
- **Description:** Fetches comprehensive analytics metrics, pipeline data, forecasting details, and goal tracking parameters for the executive dashboard. Supports multi-dimensional filtering across departments, deal stages, and investment ranges.
- **Authentication Required:** Yes (`withCredentials: true`)

### Request Body (Filters)

```json
{
  "departmentId": "dept_investment_01",
  "stage": "L3",
  "timePeriod": "Q2-2026",
  "status": "ACTIVE",
  "period": "QUARTERLY",
  "investmentValueRangeId": "range_high_val"
}
```

Response Body

```json
{
  "lastUpdated": "2026-06-16T13:25:43.8849824Z",
  "keyMetrics": {
    "l3VsTarget": {
      "value": 3873000000,
      "currency": "USD",
      "valueLabel": "$3.87B",
      "target": 5000000000,
      "targetLabel": "$5.0B",
      "percentage": 77,
      "growthVsLastQuarter": 8.7
    },
    "l4VsTarget": {
      "value": 4306000000,
      "currency": "USD",
      "valueLabel": "$4.31B",
      "target": 2200000000,
      "targetLabel": "$2.2B",
      "percentage": 196,
      "growthVsLastQuarter": 8.7
    },
    "licensesAchievement": {
      "achieved": 70,
      "target": 84,
      "varianceVsLastQuarter": -10,
      "varianceLabel": "Expired vs Last quarter"
    },
    "dealsRequiringActions": {
      "total": 33,
      "breachedCount": 8,
      "atRiskCount": 8,
      "pendingCount": 10
    }
  },
  "pipeline": {
    "totalDeals": 48,
    "totalValue": 18092000000,
    "totalCurrency": "USD",
    "totalValueLabel": "$18.09B",
    "stages": [
      {
        "stage": "L1",
        "label": "Application Submission",
        "dealCount": 9,
        "growthCountVsLastMonth": 3,
        "value": 3052000000,
        "valueLabel": "$3.05B"
      },
      {
        "stage": "L2",
        "label": "Application Approved",
        "dealCount": 10,
        "growthCountVsLastMonth": 0,
        "value": 4350000000,
        "valueLabel": "$4.35B"
      },
      {
        "stage": "L3",
        "label": "License Granted",
        "dealCount": 11,
        "growthCountVsLastMonth": 0,
        "value": 3873000000,
        "valueLabel": "$3.87B"
      },
      {
        "stage": "L4",
        "label": "Construction Started",
        "dealCount": 11,
        "growthCountVsLastMonth": 0,
        "value": 4306000000,
        "valueLabel": "$4.31B"
      },
      {
        "stage": "L5",
        "label": "Construction Completed",
        "dealCount": 7,
        "growthCountVsLastMonth": 1,
        "value": 2511000000,
        "valueLabel": "$2.51B"
      }
    ]
  },
  "investmentValueForecast": {
    "l3ForecastValue": 15580000000,
    "l3ForecastLabel": "$15.58B",
    "l4ForecastValue": 34580000000,
    "l4ForecastLabel": "$34.58B",
    "combinedForecastValue": 50160000000,
    "combinedForecastLabel": "$50.16B",
    "growthPercentage": 18,
    "quarterlyBreakdown": [
      {
        "quarter": "Q1-2026",
        "l3ForecastValue": 0,
        "l3ForecastDelayedValue": 0,
        "l3ForecastOnTrackValue": 0,
        "l4ForecastValue": 0,
        "l4ForecastDelayedValue": 0,
        "l4ForecastOnTrackValue": 0
      },
      {
        "quarter": "Q2-2026",
        "l3ForecastValue": 82912704.0,
        "l3ForecastDelayedValue": 70.0,
        "l3ForecastOnTrackValue": 30.0,
        "l4ForecastValue": 81512704.0,
        "l4ForecastDelayedValue": 77.8,
        "l4ForecastOnTrackValue": 22.2
      },
      {
        "quarter": "Q3-2026",
        "l3ForecastValue": 0,
        "l3ForecastDelayedValue": 0,
        "l3ForecastOnTrackValue": 0,
        "l4ForecastValue": 0,
        "l4ForecastDelayedValue": 0,
        "l4ForecastOnTrackValue": 0
      },
      {
        "quarter": "Q4-2026",
        "l3ForecastValue": 0,
        "l3ForecastDelayedValue": 0,
        "l3ForecastOnTrackValue": 0,
        "l4ForecastValue": 0,
        "l4ForecastDelayedValue": 0,
        "l4ForecastOnTrackValue": 0
      }
    ]
  },
  "targetHealth": {
    "achievedPercentage": 84,
    "currentProgress": 4200000000,
    "currentProgressLabel": "$4.20B",
    "annualTarget": 5000000000,
    "annualTargetLabel": "$5.00B",
    "forecastedValue": 4700000000,
    "forecastedValueLabel": "$4.70B",
    "remainingGap": 800000000,
    "remainingGapLabel": "$800M",
    "status": "ON_TRACK",
    "statusText": "84% achieved with forecasted value close to annual target."
  }
}
```

## 2. Dashboard Deals table

- **Method:** `GET`
- **URL:** `deals`
- **Description:** Fetches comprehensive analytics metrics, pipeline data, forecasting details, and goal tracking parameters for the executive dashboard. Supports multi-dimensional filtering across departments, deal stages, and investment ranges.
- **Authentication Required:** Yes (`withCredentials: true`)

### Request Body (Pagination)

```json
{
  "page": 1,
  "limit": 5,
  "timePeriod": "Q2-2026",
  "status": "ACTIVE",
  "period": "QUARTERLY",
  "investmentValueRangeId": "range_high_val"
}
```

Response Body

```json
{
  "data": [
    {
      "dealId": "deal_al_noor_01",
      "dealName": "Al Noor Industrial Complex",
      "department": "Investment",
      "ownerName": "Ahmed Hassan",
      "ownerAvatar": null,
      "stage": "L4",
      "stageLabel": "Construction Started",
      "dueDate": "2026-05-19",
      "daysRemaining": 1,
      "slaStatus": "DELAYED",
      "requiredAction": "Review missing license document",
      "priority": "HIGH",
      "capexAmount": 220000000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 220M"
    },
    {
      "dealId": "deal_al_noor_04",
      "dealName": "Al Noor Industrial Complex",
      "department": "Investment",
      "ownerName": "Ahmed Hassan",
      "ownerAvatar": null,
      "stage": "L4",
      "stageLabel": "Construction Started",
      "dueDate": "2026-05-29",
      "daysRemaining": 4,
      "slaStatus": "ON_TRACK",
      "requiredAction": "Resolve blocked approval",
      "priority": "HIGH",
      "capexAmount": 220000000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 220M"
    },
    {
      "dealId": "deal_blue_lagoon_05",
      "dealName": "Blue Lagoon Workspace",
      "department": "Operations",
      "ownerName": "Lina Mansour",
      "ownerAvatar": null,
      "stage": "L3",
      "stageLabel": "License Granted",
      "dueDate": "2026-05-29",
      "daysRemaining": 0,
      "slaStatus": "SLA_BREACH",
      "requiredAction": "Update project timeline for Q3",
      "priority": "HIGH",
      "capexAmount": 220000000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 220M"
    },
    {
      "dealId": "deal_green_valley_02",
      "dealName": "Green Valley Tech Park",
      "department": "Development",
      "ownerName": "Sara Ali",
      "ownerAvatar": null,
      "stage": "L2",
      "stageLabel": "Application Approved",
      "dueDate": "2026-05-21",
      "daysRemaining": 2,
      "slaStatus": "BLOCKED",
      "requiredAction": "Resolve blocked approval",
      "priority": "HIGH",
      "capexAmount": 150000000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 150M"
    },
    {
      "dealId": "deal_lusail_09",
      "dealName": "Lusail Smart City Phase 2",
      "department": "Investment",
      "ownerName": "Abdullah Al-Huzaymi",
      "ownerAvatar": null,
      "stage": "L4",
      "stageLabel": "Construction Started",
      "dueDate": "2026-06-20",
      "daysRemaining": 35,
      "slaStatus": "ON_TRACK",
      "requiredAction": "Monitor construction progress",
      "priority": "LOW",
      "capexAmount": 780000000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 780M"
    }
  ],
  "pagination": {
    "totalItems": 48,
    "totalPages": 10,
    "currentPage": 1,
    "itemsPerPage": 5
  }
}
```

## 3. Dashboard Deal Item Details

- **Method:** `GET`
- **URL:** `deals/{dealId}`
- **Description:** Fetches comprehensive analytics metrics, pipeline data, forecasting details, and goal tracking parameters for the executive dashboard. Supports multi-dimensional filtering across departments, deal stages, and investment ranges.
- **Authentication Required:** Yes (`withCredentials: true`)

### Request Body (Pagination)

```json
{
  "dealId": "deal_al_noor_01"
}
```

Response Body

```json
{
  "dealId": "deal_al_noor_01",
  "dealName": "Al Noor Industrial Complex",
  "slaStatus": "DELAYED",
  "lastUpdated": "2026-05-17T09:42:00Z",
  "currentStage": "L4",
  "currentStageLabel": "Construction Started",
  "stages": [
    {
      "stage": "L1",
      "label": "Application Submission",
      "status": "COMPLETED"
    },
    {
      "stage": "L2",
      "label": "Application Approved",
      "status": "COMPLETED"
    },
    {
      "stage": "L3",
      "label": "License Granted",
      "status": "COMPLETED"
    },
    {
      "stage": "L4",
      "label": "Construction Started",
      "status": "ACTIVE"
    },
    {
      "stage": "L5",
      "label": "Construction Completed",
      "status": "UPCOMING"
    }
  ],
  "reviewer": {
    "name": "Abdullah Al-Huzaymi",
    "department": "Investment Department",
    "avatarUrl": null
  },
  "overview": {
    "companyOverview": "Al Noor Industrial Group is a leading manufacturer of building materials with operations across the GCC. The company is expanding its production capacity in Qatar through QFZA.",
    "projectOverview": "Construction of a state-of-the-art manufacturing facility for advanced building materials, with a focus on sustainable production and export to regional markets."
  },
  "investmentDetails": {
    "status": "Active",
    "dealOwner": "Ahmed Hassan",
    "assetType": "Industrial",
    "firmSizeSqm": 52000,
    "firmSizeLabel": "52,000 sqm",
    "dealCapex": {
      "amount": 220000000,
      "currency": "QAR",
      "label": "QAR 220M"
    },
    "qfzCapex": {
      "amount": 220000000,
      "currency": "QAR",
      "label": "QAR 220M"
    }
  },
  "investmentStatusUpdate": {
    "status": "DELAYED",
    "currentSituation": "Infrastructure approval is delayed due to pending environmental clearance. This is impacting the ability to move to the next construction phase.",
    "actionCategory": "401820000",
    "actionableNextStep": "Submit environmental clearance to the Ministry.",
    "keyChallenges": "Pending environmental clearance from the Ministry."
  },
  "actionableNextSteps": {
    "targetDate": "2026-05-29",
    "steps": [
      "Submit environmental clearance to the Ministry.",
      "Obtain final infrastructure approval from Public Works Authority.",
      "Complete construction permit requirements.",
      "Support needed from DO leadership to expedite approvals."
    ],
    "source": null
  },
  "milestones": {
    "lastContactWithInvestor": "2026-05-12",
    "nextContactWithInvestor": "2026-05-21",
    "completionDateOfPreviousStage": "2026-04-18",
    "targetDateToNextStage": "2026-06-15",
    "targetDateToL3OrL4": "2026-05-29"
  },
  "notes": "For deals in L1-L2, target date to L3; for deals in L3, target date to L4."
}
```

## 4. Dashboard Pipeline Details

- **Method:** `GET`
- **URL:** `pipeline/details`
- **Description:** Fetches comprehensive analytics metrics, pipeline data, forecasting details, and goal tracking parameters for the executive dashboard. Supports multi-dimensional filtering across departments, deal stages, and investment ranges.
- **Authentication Required:** Yes (`withCredentials: true`)

### Request Body (Pagination)

```json
{
  "stage": "L1 (Application Submission)",
  "page": 1,
  "limit": 5
}
```

Response Body

```josn
{
  "stage": "L1",
  "stageLabel": "L1 (Application Submission)",
  "subLabel": "Deals converted to L1 from Jan 2026",
  "lastUpdated": "2026-06-17T09:21:15.4822181Z",
  "summaryMetrics": {
    "pipelineValue": 1149900000,
    "pipelineValueLabel": "$1.15B",
    "target": 1149900000,
    "targetLabel": "$1.15B",
    "progressPercentage": 100
  },
  "deals": [
    {
      "dealId": "deal_anablon_11",
      "dealName": "Anablon Biotech Production",
      "ownerName": "Fatma Elsayed Qassem",
      "ownerAvatar": null,
      "capexAmount": 174700000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 174.7M",
      "currentStage": "L1",
      "currentStageLabel": "L1 (Application Submission)",
      "forecastDate": "2026-05-19",
      "dealStatus": "ACTIVE",
      "landSizeSqm": null,
      "powerDemandMw": 3.35
    },
    {
      "dealId": "deal_air_liquide_12",
      "dealName": "Air Liquide Maritime",
      "ownerName": "Menna Alaa Hanafi",
      "ownerAvatar": null,
      "capexAmount": 65100000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 65.1M",
      "currentStage": "L1",
      "currentStageLabel": "L1 (Application Submission)",
      "forecastDate": "2026-05-21",
      "dealStatus": "ACTIVE",
      "landSizeSqm": 22592,
      "powerDemandMw": null
    },
    {
      "dealId": "deal_apex_water_13",
      "dealName": "Apex Water Solutions and Service",
      "ownerName": "Marco George Zikri",
      "ownerAvatar": null,
      "capexAmount": 54600000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 54.6M",
      "currentStage": "L1",
      "currentStageLabel": "L1 (Application Submission)",
      "forecastDate": "2026-05-24",
      "dealStatus": "ACTIVE",
      "landSizeSqm": 10361,
      "powerDemandMw": 0.63
    },
    {
      "dealId": "deal_gulf_green_14",
      "dealName": "Gulf Green",
      "ownerName": "Reem Salehman Ali",
      "ownerAvatar": null,
      "capexAmount": 10000000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 10M",
      "currentStage": "L1",
      "currentStageLabel": "L1 (Application Submission)",
      "forecastDate": "2026-05-29",
      "dealStatus": "ACTIVE",
      "landSizeSqm": 30740,
      "powerDemandMw": null
    },
    {
      "dealId": "deal_bin_juamh_15",
      "dealName": "Bin Juamh Soft Drinks",
      "ownerName": "Mokhtar Gamal Mukhtar",
      "ownerAvatar": null,
      "capexAmount": 6500000,
      "capexCurrency": "QAR",
      "capexLabel": "QAR 6.5M",
      "currentStage": "L1",
      "currentStageLabel": "L1 (Application Submission)",
      "forecastDate": "2026-05-29",
      "dealStatus": "ACTIVE",
      "landSizeSqm": 26958,
      "powerDemandMw": 0.63
    }
  ],
  "pagination": {
    "totalItems": 10,
    "totalPages": 2,
    "currentPage": 1,
    "itemsPerPage": 5
  }
}
```

## 5. Dashboard Filter Data For Dropdowns and Date Calendars

- **Method:** `GET`
- **URL:** `dashboard/filters`
- **Description:** Fetches comprehensive analytics metrics, pipeline data, forecasting details, and goal tracking parameters for the executive dashboard. Supports multi-dimensional filtering across departments, deal stages, and investment ranges.
- **Authentication Required:** Yes (`withCredentials: true`)

### Request Body

```json
{}
```

Response Body

```json
{
  "departments": [
    {
      "id": "dept_investment",
      "label": "Investment",
      "name": "Investment"
    },
    {
      "id": "dept_development",
      "label": "Development",
      "name": "Development"
    },
    {
      "id": "dept_marketing",
      "label": "Marketing",
      "name": "Marketing"
    },
    {
      "id": "dept_operations",
      "label": "Operations",
      "name": "Operations"
    }
  ],
  "stages": [
    {
      "id": "L1",
      "label": "L1 (Application Submission)",
      "name": "Application Submission"
    },
    {
      "id": "L2",
      "label": "L2 (Application Approved)",
      "name": "Application Approved"
    },
    {
      "id": "L3",
      "label": "L3 (License Granted)",
      "name": "License Granted"
    },
    {
      "id": "L4",
      "label": "L4 (Construction Started)",
      "name": "Construction Started"
    },
    {
      "id": "L5",
      "label": "L5 (Construction Completed)",
      "name": "Construction Completed"
    }
  ],
  "statuses": [
    {
      "id": "ACTIVE",
      "label": "Active",
      "name": null
    },
    {
      "id": "DELAYED",
      "label": "Delayed",
      "name": null
    },
    {
      "id": "BLOCKED",
      "label": "Blocked",
      "name": null
    },
    {
      "id": "PENDING",
      "label": "Pending",
      "name": null
    },
    {
      "id": "ON_TRACK",
      "label": "On Track",
      "name": null
    },
    {
      "id": "SLA_BREACH",
      "label": "SLA Breach",
      "name": null
    }
  ],
  "priorities": [
    {
      "id": "HIGH",
      "label": "High",
      "name": null
    },
    {
      "id": "MEDIUM",
      "label": "Medium",
      "name": null
    },
    {
      "id": "LOW",
      "label": "Low",
      "name": null
    }
  ],
  "investmentValueRanges": [
    {
      "id": "under_100m",
      "label": "Under QAR 100M",
      "min": 0,
      "max": 100000000
    },
    {
      "id": "100m_500m",
      "label": "QAR 100M - QAR 500M",
      "min": 100000000,
      "max": 500000000
    },
    {
      "id": "above_500m",
      "label": "Above QAR 500M",
      "min": 500000000,
      "max": null
    }
  ],
  "timePeriods": [
    {
      "id": "2026",
      "label": "2026",
      "name": null
    },
    {
      "id": "2025",
      "label": "2025",
      "name": null
    }
  ]
}
```
