import { Component, Input, ChangeDetectionStrategy } from "@angular/core";

export interface KpiBadge {
  label: string;
  variant: "danger" | "warning" | "neutral" | "L3";
}

@Component({
  selector: "app-kpi-card",
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  /*
   * host: h-full makes the <app-kpi-card> custom element stretch to the
   * full CSS-grid row height so every card in the row is equal-height.
   */
  host: { class: "h-full" },
  templateUrl: './kpi-card.component.html',
})
export class KpiCardComponent {
  @Input({ required: true }) title!: string;
  @Input({ required: true }) value!: string;
  @Input({ required: true }) currency!: string;
  @Input({ required: true }) isBrownProgress: boolean = false;
  @Input() dark = false;
  @Input() progress?: number;
  @Input() target?: string;
  @Input() change?: string;
  @Input() changePositive = true;
  @Input() subtitle?: string;
  @Input() iconSlot?: "refresh" | "clock" | "warning" | "L3";
  @Input() badges?: KpiBadge[];
}
