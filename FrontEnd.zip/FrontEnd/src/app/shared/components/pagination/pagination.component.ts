import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-pagination',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (totalPages > 1) {
      <div class="pg-root">

        <!-- Previous -->
        <button class="pg-nav-btn" [disabled]="page === 0" (click)="prev()">
          <i class="pi pi-arrow-left pg-arrow"></i>
          <span class="pg-nav-label">Previous</span>
        </button>

        <!-- Desktop: numbered pages -->
        <div class="pg-numbers">
          @for (p of pageNumbers; track $index) {
            @if (p === '...') {
              <span class="pg-ellipsis">...</span>
            } @else {
              <button
                class="pg-page-btn"
                [class.pg-page-btn--active]="p === page + 1"
                (click)="go(p)"
              >{{ p }}</button>
            }
          }
        </div>

        <!-- Mobile: "Page X of Y" -->
        <span class="pg-mobile-info">
          Page <strong>{{ page + 1 }}</strong> of {{ totalPages }}
        </span>

        <!-- Next -->
        <button class="pg-nav-btn" [disabled]="page === totalPages - 1" (click)="next()">
          <span class="pg-nav-label">Next</span>
          <i class="pi pi-arrow-right pg-arrow"></i>
        </button>

      </div>
    }
  `,
  styles: [`
    :host {
      display: block;
      font-family: 'Montserrat', system-ui, sans-serif;
    }

    .pg-root {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.5rem;
    }

    /* ── Nav buttons (Previous / Next) ─────────────────────────────────── */
    .pg-nav-btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 0.45rem 1rem;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      background: #fff;
      font-size: 0.8125rem;
      font-weight: 600;
      color: #374151;
      cursor: pointer;
      font-family: inherit;
      white-space: nowrap;
      flex-shrink: 0;
      transition: background 0.12s, border-color 0.12s;
    }
    .pg-nav-btn:hover:not([disabled]) {
      background: #f8fafc;
      border-color: #cbd5e1;
    }
    .pg-nav-btn[disabled] {
      opacity: 0.4;
      cursor: not-allowed;
    }
    .pg-arrow {
      font-size: 11px;
    }

    /* ── Desktop numbered pages ─────────────────────────────────────────── */
    .pg-numbers {
      display: flex;
      align-items: center;
      gap: 0.25rem;
    }

    .pg-page-btn {
      min-width: 2rem;
      height: 2rem;
      padding: 0 0.25rem;
      border-radius: 8px;
      border: 1px solid transparent;
      background: transparent;
      font-size: 0.8125rem;
      font-weight: 500;
      color: #6b7280;
      cursor: pointer;
      font-family: inherit;
      transition: background 0.12s;
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .pg-page-btn:hover:not(.pg-page-btn--active) {
      background: #f1f5f9;
    }
    .pg-page-btn--active {
      background: #dbeafe;
      color: #1d4ed8;
      border-color: #bfdbfe;
      font-weight: 700;
    }

    .pg-ellipsis {
      min-width: 2rem;
      height: 2rem;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 0.8125rem;
      color: #9ca3af;
    }

    /* ── Mobile "Page X of Y" indicator (hidden on desktop) ────────────── */
    .pg-mobile-info {
      display: none;
      font-size: 0.8125rem;
      color: #6b7280;
      white-space: nowrap;
    }
    .pg-mobile-info strong {
      color: #1d4ed8;
      font-weight: 700;
    }

    /* ── Responsive breakpoint ──────────────────────────────────────────── */
    @media (max-width: 639px) {
      .pg-numbers       { display: none; }
      .pg-mobile-info   { display: block; }

      .pg-nav-btn {
        padding: 0.4rem 0.75rem;
        font-size: 0.75rem;
        gap: 5px;
      }
      .pg-nav-label { display: none; }
      .pg-nav-btn {
        width: 2.25rem;
        height: 2.25rem;
        padding: 0;
        justify-content: center;
      }
    }
  `],
})
export class PaginationComponent {
  @Input({ required: true }) page = 0;           // 0-based current page
  @Input({ required: true }) totalPages = 1;
  @Output() pageChange = new EventEmitter<number>(); // emits 0-based index

  get pageNumbers(): (number | '...')[] {
    const total = this.totalPages;
    const cur   = this.page + 1;
    if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
    if (cur <= 3)           return [1, 2, 3, '...', total - 2, total - 1, total];
    if (cur >= total - 2)   return [1, 2, 3, '...', total - 2, total - 1, total];
    return [1, '...', cur - 1, cur, cur + 1, '...', total];
  }

  prev(): void { if (this.page > 0) this.pageChange.emit(this.page - 1); }
  next(): void { if (this.page < this.totalPages - 1) this.pageChange.emit(this.page + 1); }
  go(p: number | '...'): void { if (typeof p === 'number') this.pageChange.emit(p - 1); }
}
