import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { Tag } from 'primeng/tag';

export type BadgeStatus = 'delayed' | 'blocked' | 'pending' | 'on-track' | 'sla-breach';

type PrimeSeverity = 'success' | 'info' | 'warn' | 'danger' | 'secondary' | 'contrast';

const STATUS_SEVERITY: Record<BadgeStatus, PrimeSeverity> = {
  'delayed':    'danger',
  'blocked':    'danger',
  'pending':    'secondary',
  'on-track':   'success',
  'sla-breach': 'warn',
};

const STATUS_LABEL: Record<BadgeStatus, string> = {
  'delayed':    'Delayed',
  'blocked':    'Blocked',
  'pending':    'Pending',
  'on-track':   'On Track',
  'sla-breach': 'SLA breach',
};

const STATUS_ICON: Record<BadgeStatus, string> = {
  'delayed':    'pi-clock',
  'blocked':    'pi-times-circle',
  'pending':    'pi-spinner-dotted',
  'on-track':   'pi-check-circle',
  'sla-breach': 'pi-exclamation-triangle',
};

const STATUS_CSS: Record<BadgeStatus, string> = {
  'delayed':    'bg-[#F4F0EA] text-[#8C682A]',
  'blocked':    'badge-blocked',
  'pending':    'badge-pending',
  'on-track':   'bg-[#EAF4EE]',
  'sla-breach': 'badge-sla-breach',
};

@Component({
  selector: 'app-badge',
  standalone: true,
  imports: [Tag],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <p-tag
      [value]="label ?? defaultLabel"
      [severity]="severity"
      [icon]="'pi ' + icon"
      [class]="cssClass"
    />
  `,
})
export class BadgeComponent {
  @Input({ required: true }) status!: BadgeStatus;
  @Input() label?: string;

  get severity(): PrimeSeverity { return STATUS_SEVERITY[this.status]; }
  get defaultLabel(): string    { return STATUS_LABEL[this.status]; }
  get icon(): string            { return STATUS_ICON[this.status]; }
  get cssClass(): string        { return STATUS_CSS[this.status]; }
}
