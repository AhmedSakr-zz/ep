import {
  Component,
  Input,
  Output,
  EventEmitter,
  ContentChild,
  TemplateRef,
  ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';

export type DialogPosition =
  | 'center' | 'top' | 'bottom' | 'left' | 'right'
  | 'topleft' | 'topright' | 'bottomleft' | 'bottomright';

@Component({
  selector: 'app-shared-dialog',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, DialogModule],
  templateUrl: './shared-dialog.component.html',
  styleUrl: './shared-dialog.component.css',
})
export class SharedDialogComponent {
  /** Open / close state — supports two-way [(visible)] binding */
  @Input() visible = false;
  @Output() visibleChange = new EventEmitter<boolean>();

  /** Header string shown when no #dialogHeader template is projected */
  @Input() header = '';

  /** Optional subtitle rendered below the title in the default header */
  @Input() subheader = '';

  /**
   * PrimeNG icon name (without the "pi" prefix) shown in the default header.
   * e.g. "sliders-h"  →  renders <i class="pi pi-sliders-h">
   */
  @Input() headerIcon = '';

  /** Dialog width — any valid CSS value, e.g. "720px", "50vw" */
  @Input() width = '50vw';

  /** Position of the dialog on screen */
  @Input() position: DialogPosition = 'center';

  /** Whether to show a modal backdrop */
  @Input() modal = true;

  /** Whether to show the built-in close (×) button */
  @Input() closable = true;

  @Input() draggable = false;
  @Input() resizable = false;

  /**
   * Additional CSS class appended to the dialog element.
   * Base class `sd-dialog` is always present.
   */
  @Input() styleClass = '';

  /** Inline styles merged onto the dialog host (width is set separately) */
  @Input() style: Record<string, string> = {};

  /** PrimeNG responsive breakpoints map, e.g. { '768px': '90vw' } */
  @Input() breakpoints: Record<string, string> = {
    '960px': '75vw',
    '640px': '92vw',
  };

  /** Emitted after the dialog finishes its open animation */
  @Output() dialogShow = new EventEmitter<void>();

  /** Emitted after the dialog finishes its close animation */
  @Output() dialogHide = new EventEmitter<void>();

  /**
   * Project a custom header by adding #dialogHeader to a child <ng-template>.
   * When present it fully replaces the default icon + title + subtitle rendering.
   *
   * Example:
   *   <ng-template #dialogHeader>
   *     <div class="flex items-center gap-2">
   *       <i class="pi pi-filter"></i>
   *       <span>My Custom Title</span>
   *     </div>
   *   </ng-template>
   */
  @ContentChild('dialogHeader') customHeader?: TemplateRef<unknown>;

  /**
   * Project footer content by adding #dialogFooter to a child <ng-template>.
   * When absent no footer section is rendered.
   *
   * Example:
   *   <ng-template #dialogFooter>
   *     <div class="flex justify-between w-full">
   *       <button (click)="cancel()">Cancel</button>
   *       <button (click)="submit()">Apply</button>
   *     </div>
   *   </ng-template>
   */
  @ContentChild('dialogFooter') customFooter?: TemplateRef<unknown>;

  get resolvedStyleClass(): string {
    return ['sd-dialog', this.styleClass].filter(Boolean).join(' ');
  }

  get resolvedStyle(): Record<string, string> {
    return { width: this.width, ...this.style };
  }
}
