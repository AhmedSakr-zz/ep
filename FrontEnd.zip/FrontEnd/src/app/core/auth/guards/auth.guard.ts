import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isAuthenticated()) return true;

  // Access token is memory-only; redirect to login so the user can re-authenticate.
  // The refresh token cookie and cached user will be available after login if needed.
  return router.createUrlTree(['/login']);
};
