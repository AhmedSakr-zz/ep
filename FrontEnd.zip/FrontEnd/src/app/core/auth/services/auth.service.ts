import {
  Injectable,
  signal,
  computed,
  inject,
  PLATFORM_ID,
} from "@angular/core";
import { isPlatformBrowser } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { Observable, catchError, finalize, shareReplay, tap, throwError } from "rxjs";
import { environment } from "../../../../environments/environment";
import { LoginResponse, RefreshResponse, User } from "../models/auth.models";

const USER_KEY = "current_user";
const REFRESH_TOKEN_COOKIE = "refresh_token";
// Note: httpOnly cookies can only be set by the server via Set-Cookie header.
// The access token is kept in memory (most XSS-resistant client-side option).
// The refresh token uses a JS-accessible cookie with Secure + SameSite=Strict.

@Injectable({ providedIn: "root" })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);

  private readonly _accessToken = signal<string | null>(null);
  private readonly _currentUser = signal<User | null>(
    this.loadUserFromStorage(),
  );

  // Shared observable used to prevent multiple concurrent refresh calls on simultaneous 401s.
  private _refresh$: Observable<RefreshResponse> | null = null;

  readonly token = this._accessToken.asReadonly();
  readonly currentUser = this._currentUser.asReadonly();
  readonly isAuthenticated = computed(() => this._accessToken() !== null);
  readonly userFullName = computed(() => {
    const u = this._currentUser();
    return u ? `${u.firstName} ${u.lastName}` : null;
  });

  login(email: string, password: string): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(`${environment.apiUrl}auth/login`, { email, password })
      .pipe(
        tap((res) => {
          this._accessToken.set(res.token);
          this.persistUser(res.user);
          this.persistRefreshToken(res.refreshToken);
        }),
      );
  }

  logout(): Observable<void> {
    return this.http
      .post<void>(`${environment.apiUrl}auth/logout`, {
        refreshToken: this.getRefreshToken(),
      })
      .pipe(
        tap(() => this.clearSession()),
        catchError((err) => {
          // Always clear local session even if the server call fails
          this.clearSession();
          return throwError(() => err);
        }),
      );
  }

  /**
   * Exchanges the stored refresh token for a new access token.
   * Shared across all callers — only one HTTP request fires even when
   * multiple requests hit a 401 simultaneously.
   */
  refreshAccessToken(): Observable<RefreshResponse> {
    if (!this._refresh$) {
      this._refresh$ = this.http
        .post<RefreshResponse>(`${environment.apiUrl}auth/refresh`, {
          refreshToken: this.getRefreshToken(),
        })
        .pipe(
          tap((res) => {
            this._accessToken.set(res.token);
            this.persistRefreshToken(res.refreshToken);
          }),
          catchError((err) => {
            this.clearSession();
            return throwError(() => err);
          }),
          finalize(() => {
            this._refresh$ = null;
          }),
          shareReplay(1),
        );
    }
    return this._refresh$;
  }

  clearSession(): void {
    this._accessToken.set(null);
    this._currentUser.set(null);
    this.clearPersistedData();
  }

  getRefreshToken(): string | null {
    return this.readCookie(REFRESH_TOKEN_COOKIE);
  }

  private persistUser(user: User): void {
    this._currentUser.set(user);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    }
  }

  private persistRefreshToken(token: string): void {
    if (!isPlatformBrowser(this.platformId)) return;
    const sevenDays = 7 * 24 * 60 * 60 * 1000;
    const expires = new Date(Date.now() + sevenDays);
    document.cookie =
      `${REFRESH_TOKEN_COOKIE}=${encodeURIComponent(token)}` +
      `; expires=${expires.toUTCString()}; path=/; SameSite=Strict`;
  }

  private readCookie(name: string): string | null {
    if (!isPlatformBrowser(this.platformId)) return null;
    const match = document.cookie.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
    return match ? decodeURIComponent(match[1]) : null;
  }

  private clearPersistedData(): void {
    if (!isPlatformBrowser(this.platformId)) return;
    localStorage.removeItem(USER_KEY);
    document.cookie = `${REFRESH_TOKEN_COOKIE}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
  }

  private loadUserFromStorage(): User | null {
    if (!isPlatformBrowser(this.platformId) && typeof localStorage === "undefined")
      return null;
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? (JSON.parse(raw) as User) : null;
    } catch {
      return null;
    }
  }
}
