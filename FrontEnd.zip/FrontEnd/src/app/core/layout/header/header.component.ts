import { Component, ChangeDetectionStrategy } from "@angular/core";
import { inject } from "@angular/core";
import { AuthService } from "../../auth/services/auth.service";
import { ButtonModule } from "primeng/button";
import { MenubarModule } from "primeng/menubar";
import { MenuItem } from "primeng/api";
import { NotificationCenterComponent } from "../notification-center/notification-center.component";
import { ProfileMenuComponent } from "../profile-menu/profile-menu.component";
import { Router } from "@angular/router";

@Component({
  selector: "app-header",
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: "./header.component.html",
  styleUrl: "./header.component.css",
  imports: [ButtonModule, MenubarModule, NotificationCenterComponent, ProfileMenuComponent],
})
export class HeaderComponent {
  readonly auth = inject(AuthService);
  readonly route = inject(Router);
  items: MenuItem[] = [
    {
      label: "Executive Overview",
      icon: "pi pi-th-large",
      routerLink: "/dashboard",
      styleClass: "header-menu-item-cust",
    },
  ];
  get now(): string {
    return new Date().toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }
  logout() {
    this.auth.logout().subscribe({
      next: () => {
        // Optionally, you can navigate to the login page or show a message
        // this.router.navigate(['/login']);
          this.route.navigate(["/login"]);

      },
      error: () => {
        // Handle logout error if needed
      },
    });
  }
}
