import {
  Component,
  ChangeDetectionStrategy,
  signal,
  computed,
  viewChild,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Popover, PopoverModule } from 'primeng/popover';
import { ScrollerModule } from 'primeng/scroller';
import { ButtonModule } from 'primeng/button';
import { BadgeModule } from 'primeng/badge';

export interface AppNotification {
  id: number;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  icon: string;
  iconBg: string;
  iconColor: string;
}

@Component({
  selector: 'app-notification-center',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './notification-center.component.html',
  styleUrl: './notification-center.component.css',
  imports: [CommonModule, PopoverModule, ScrollerModule, ButtonModule, BadgeModule],
})
export class NotificationCenterComponent {
  private readonly panel = viewChild.required<Popover>('notifPanel');

  readonly notifications = signal<AppNotification[]>(
    this.generateMockNotifications(60)
  );

  readonly unreadCount = computed(
    () => this.notifications().filter((n) => !n.read).length
  );

  toggle(event: Event): void {
    this.panel().toggle(event);
  }

  markAllAsRead(): void {
    this.notifications.update((list) => list.map((n) => ({ ...n, read: true })));
  }

  formatTime(date: Date): string {
    const diff = Date.now() - date.getTime();
    const m = Math.floor(diff / 60_000);
    if (m < 1) return 'Just now';
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.floor(h / 24)}d ago`;
  }

  private generateMockNotifications(count: number): AppNotification[] {
    const templates: Omit<AppNotification, 'id' | 'timestamp' | 'read'>[] = [
      {
        title: 'New Deal Closed',
        message: 'A new deal worth $1.2M has been closed by the Gulf region sales team.',
        icon: 'pi pi-briefcase',
        iconBg: '#ecfdf5',
        iconColor: '#10b981',
      },
      {
        title: 'Pipeline Alert',
        message: 'Pipeline value has dropped below the Q4 target threshold. Immediate review is required.',
        icon: 'pi pi-exclamation-triangle',
        iconBg: '#fffbeb',
        iconColor: '#f59e0b',
      },
      {
        title: 'Report Ready',
        message: 'The monthly executive summary for November 2024 is ready for your review.',
        icon: 'pi pi-file-pdf',
        iconBg: '#eff6ff',
        iconColor: '#3b82f6',
      },
      {
        title: 'Target Achieved',
        message: 'Revenue target of $5M for Q3 has been achieved three weeks ahead of schedule.',
        icon: 'pi pi-check-circle',
        iconBg: '#f5f3ff',
        iconColor: '#8b5cf6',
      },
      {
        title: 'Team Update',
        message: 'Sarah Alharbi has been promoted to Regional Sales Director, effective immediately.',
        icon: 'pi pi-users',
        iconBg: '#ecfeff',
        iconColor: '#06b6d4',
      },
    ];

    return Array.from({ length: count }, (_, i) => {
      const t = templates[i % templates.length];
      const minsAgo = Math.floor(Math.random() * 10_080); // up to 7 days ago
      return {
        ...t,
        id: i + 1,
        timestamp: new Date(Date.now() - minsAgo * 60_000),
        read: i >= 5,
      };
    });
  }
}
