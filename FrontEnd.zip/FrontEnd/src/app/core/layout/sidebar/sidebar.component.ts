import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

interface NavItem {
  label: string;
  route: string;
  icon: string; // PrimeIcons name e.g. 'pi-th-large'
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    .logo-bar-1 { background: #0a1a38; }   /* navy-900 */
    .logo-bar-2 { background: #2563eb; }   /* brand-600 */
    .logo-bar-3 { background: #60a5fa; }   /* brand-400 */
  `],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css',
})
export class SidebarComponent {
  readonly navItems: NavItem[] = [
    { label: 'Executive Overview', route: '/dashboard', icon: 'pi-th-large' },
  ];
}
