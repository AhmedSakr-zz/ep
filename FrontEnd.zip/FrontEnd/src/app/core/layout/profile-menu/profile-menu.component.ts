import {
  Component,
  ChangeDetectionStrategy,
  Output,
  EventEmitter,
  signal,
  viewChild,
} from '@angular/core';
import { Menu, MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { AvatarModule } from 'primeng/avatar';
import { MenuItem } from 'primeng/api';

export interface UserProfile {
  name: string;
  role: string;
  initials: string;
  avatar?: string;
}

@Component({
  selector: 'app-profile-menu',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './profile-menu.component.html',
  styleUrl: './profile-menu.component.css',
  imports: [MenuModule, ButtonModule, AvatarModule],
})
export class ProfileMenuComponent {
  @Output() onLogout = new EventEmitter<void>();

  private readonly menu = viewChild.required<Menu>('profileMenu');

  readonly avatarError = signal(false);

  readonly user: UserProfile = {
    name: 'Abdullah Al-Huzaymi',
    role: 'Manager',
    initials: 'AH',
    avatar: undefined,
  };

  readonly menuItems: MenuItem[] = [
    {
      label: 'My Profile',
      icon: 'pi pi-user',
      styleClass: 'profile-menu-item',
      command: () => { /* TODO: navigate to profile */ },
    },
    {
      label: 'Account Settings',
      icon: 'pi pi-cog',
      styleClass: 'profile-menu-item',
      command: () => { /* TODO: navigate to settings */ },
    },
    { separator: true },
    {
      label: 'Logout',
      icon: 'pi pi-sign-out',
      styleClass: 'profile-menu-item profile-menu-item--logout',
      command: () => this.logout(),
    },
  ];

  toggle(event: Event): void {
    this.menu().toggle(event);
  }

  logout(): void {
    this.onLogout.emit();
  }
}
