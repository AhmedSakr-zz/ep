import { ApplicationConfig, inject, provideAppInitializer, provideZonelessChangeDetection } from '@angular/core';
import {
  provideRouter,
  withComponentInputBinding,
  withViewTransitions,
  withRouterConfig,
} from '@angular/router';
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { providePrimeNG } from 'primeng/config';
import Aura from '@primeuix/themes/aura';
import { catchError, of } from 'rxjs';
import { appRoutes } from './app.routes';
import { authInterceptor } from './core/auth/interceptors/auth.interceptor';
import { tokenRefreshInterceptor } from '@core/auth/interceptors/token-refresh.interceptor';
import { AuthService } from './core/auth/services/auth.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZonelessChangeDetection(),

    provideRouter(
      appRoutes,
      withComponentInputBinding(),
      withViewTransitions(),
      withRouterConfig({ onSameUrlNavigation: 'reload' }),
    ),

    provideHttpClient(
      withFetch(),
      withInterceptors([authInterceptor, tokenRefreshInterceptor]),
    ),

    provideAppInitializer(() => {
      const auth = inject(AuthService);
      if (!auth.getRefreshToken()) return of(null);
      return auth.refreshAccessToken().pipe(catchError(() => of(null)));
    }),

    provideAnimationsAsync(),

    providePrimeNG({
      theme: {
        preset: Aura,
        options: {
          /*
           * Use a CSS cascade layer for PrimeNG so Tailwind utility
           * classes always win in specificity.  The layer order here
           * must match the @layer declaration at the top of styles.css.
           */
          cssLayer: {
            name: 'primeng',
            order: 'tailwind-base, primeng, tailwind-utilities' // Targets v3 cascade order cleanly
          },
          darkModeSelector: '.dark',
        },
      },
    }),
  ],
};
