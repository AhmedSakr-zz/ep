import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  inject,
} from "@angular/core";
import { KpiCardComponent } from "@shared/components/kpi-card/kpi-card.component";
import { PipelineStageComponent } from "./components/pipeline-stage/pipeline-stage.component";
import { InvestmentForecastComponent } from "./components/investment-forecast/investment-forecast.component";
import { TargetHealthComponent } from "./components/target-health/target-health.component";
import { DealsTableComponent } from "./components/deals-table/deals-table.component";
import { ButtonModule } from "primeng/button";
import { DatePickerModule } from "primeng/datepicker";
import { FormsModule } from "@angular/forms";
import { FeatureFilterComponent, FilterValues } from "./components/feature-filter/feature-filter.component";
import { SelectModule } from "primeng/select";
import { DashboardFacadeService } from "./services/facade/dashboard-facade.service";

@Component({
  selector: "app-dashboard",
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    KpiCardComponent,
    PipelineStageComponent,
    InvestmentForecastComponent,
    TargetHealthComponent,
    DealsTableComponent,
    ButtonModule,
    DatePickerModule,
    FormsModule,
    // FeatureFilterComponent,
    SelectModule,
  ],
  templateUrl: "./dashboard.component.html",
  styleUrl: "./dashboard.component.css",
})
export class DashboardComponent implements OnInit {
  readonly facade = inject(DashboardFacadeService);

  selectedYear: Date | null = null;
  selectedDepartment: string | null = null;
  selectedStage: string | null = null;
  activeForecastTab: 'L3' | 'L4' = 'L3';

  ngOnInit(): void {
    this.facade.loadFilters();
    this.facade.loadOverview();
    this.facade.loadDeals(1);
  }

  onQuickFilterChange(): void {
    const timePeriod = this.selectedYear
      ? String(this.selectedYear.getFullYear())
      : null;
    this.facade.applyQuickFilters(this.selectedDepartment, this.selectedStage, timePeriod);
  }

  onFiltersCleared(): void {
    this.selectedDepartment = null;
    this.selectedStage = null;
    this.selectedYear = null;
    this.facade.applyQuickFilters(null, null, null);
  }

  onFiltersApplied(filters: FilterValues): void {
    this.facade.applyFilters(filters);
  }

  onForecastTabChange(tab: 'L3' | 'L4'): void {
    this.activeForecastTab = tab;
  }
}
