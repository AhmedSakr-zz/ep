import { BadgeStatus } from "@shared/components/badge/badge.component";

// ─── UI layer models (consumed by components) ──────────────────────────────

export interface DealStageStep {
  code: string;
  name: string;
}

export interface DealMilestone {
  label: string;
  date: string;
}

export interface DealDetail {
  id: string;
  dealName: string;
  slaStatus: BadgeStatus;
  lastUpdated: string;
  assignee: string;
  department: string;
  currentStageIndex: number;
  pipelineStages: DealStageStep[];
  companyOverview: string;
  projectOverview: string;
  investmentStatus: "Active" | "Pending";
  dealOwner: string;
  assetType: string;
  firmSize: string;
  costCapex: string;
  gfcCapex: string;
  currentChallenges: string;
  actionCategory: string;
  actionableNextStep: string;
  keyChallenges: string;
  actionableSteps: string[];
  actionableStepsDate: string;
  milestones: DealMilestone[];
}

export interface PipelineStage {
  code: string;
  name: string;
  count: number;
  change: number;
  score: number;
}

export interface ForecastQuarter {
  label: string;
  l3: number;
  l4: number;
}

export interface StatusBreakdown {
  delayed: number;
  onTrack: number;
}

export interface ForecastQuarterWithStatus {
  label: string;
  l3: number;
  l4: number;
  l3Status: StatusBreakdown;
  l4Status: StatusBreakdown;
}

export interface TargetHealth {
  achievedPct: number;
  currentProgress: number;
  annualTarget: number;
  forecastedValue: number;
  remainingGap: number;
  statusMessage: string;
}

export interface DealItem {
  id: string;
  dealName: string;
  type: string;
  assignee: string;
  stage: string;
  dueDate: string;
  daysLeft: number;
  slaStatus: BadgeStatus;
  requiredAction: string;
  requestNumber: string;
  requester: string;
}

export interface DashboardSummary {
  l3Value: string;
  l3Currency: string;
  l3Progress: number;
  l3Target: string;
  l3Change: string;

  l4Value: string;
  l4currency: string;
  l4Progress: number;
  l4Target: string;
  l4Change: string;

  licensesCount: number;
  licensesExpiredChange: string;
  licensesSubtitle: string;

  dealsActionCount: number;
  dealsBadges: { label: string; variant: "danger" | "warning" | "neutral" }[];

  pipelineTotal: number;
  pipelineValue: string;
  stages: PipelineStage[];

  pipelineL3: string;
  actualL3: string;
  pipelineL4: string;
  actualL4: string;
  forecastCombined: string;
  forecastGrowth: string;
  forecastQuarters: ForecastQuarterWithStatus[];

  targetHealth: {
    l3: TargetHealth;
    l4: TargetHealth;
  };

  deals: DealItem[];
  dealsTotal: number;
}

// ─── API request models ────────────────────────────────────────────────────

export interface DashboardFilters {
  departmentId?: string;
  stage?: string;
  timePeriod?: string;
  status?: string;
  period?: string;
  investmentValueRangeId?: string;
}

export interface DealsRequest {
  page: number;
  limit: number;
  timePeriod?: string;
  status?: string;
  period?: string;
  investmentValueRangeId?: string;
}

// ─── API response models ───────────────────────────────────────────────────

interface ApiMetricTarget {
  value: number;
  currency: string;
  valueLabel: string;
  target: number;
  targetLabel: string;
  percentage: number;
  growthVsLastQuarter: number;
}

interface ApiPipelineStage {
  stage: string;
  label: string;
  dealCount: number;
  growthCountVsLastMonth: number;
  value: number;
  valueLabel: string;
}

interface ApiQuarterBreakdown {
  quarter: string;
  l3ForecastValue: number;
  l3ForecastDelayedValue: number;
  l3ForecastOnTrackValue: number;
  l4ForecastValue: number;
  l4ForecastDelayedValue: number;
  l4ForecastOnTrackValue: number;
}

export interface ApiOverviewResponse {
  lastUpdated: string;
  keyMetrics: {
    l3VsTarget: ApiMetricTarget;
    l4VsTarget: ApiMetricTarget;
    licensesAchievement: {
      achieved: number;
      target: number;
      varianceVsLastQuarter: number;
      varianceLabel: string;
    };
    dealsRequiringActions: {
      total: number;
      breachedCount: number;
      atRiskCount: number;
      pendingCount: number;
    };
  };
  pipeline: {
    totalDeals: number;
    totalValue: number;
    totalCurrency: string;
    totalValueLabel: string;
    stages: ApiPipelineStage[];
  };
  investmentValueForecast: {
    l3PipelineValue: string;
    l3ActualValue: string;
    l4PipelineValue: string;
    l4ActualValue: string;
    combinedForecastValue: number;
    combinedForecastLabel: string;
    growthPercentage: number;
    quarterlyBreakdown: ApiQuarterBreakdown[];
  };
  targetHealth: {
    l3: targetHealthLabels;
    l4: targetHealthLabels;
  };
}
export interface targetHealthLabels {
  achievedPercentage: number;
  currentProgress: number;
  currentProgressLabel: string;
  annualTarget: number;
  annualTargetLabel: string;
  forecastedValue: number;
  forecastedValueLabel: string;
  remainingGap: number;
  remainingGapLabel: string;
  status: string;
  statusText: string;
}
export interface ApiDealItem {
  dealId: string;
  dealName: string;
  department: string;
  ownerName: string;
  ownerAvatar: string | null;
  stage: string;
  stageLabel: string;
  dueDate: string;
  daysRemaining: number;
  slaStatus: string;
  requiredAction: string;
  priority: string;
  capexAmount: number;
  capexCurrency: string;
  capexLabel: string;
  requestNumber: string;
  requester: string;
}

export interface ApiDealsResponse {
  data: ApiDealItem[];
  pagination: {
    totalItems: number;
    totalPages: number;
    currentPage: number;
    itemsPerPage: number;
  };
}

// ─── Deal detail API response (GET deals/{dealId}) ─────────────────────────

export interface ApiDealDetailStage {
  stage: string;
  label: string;
  status: "COMPLETED" | "ACTIVE" | "UPCOMING";
}

export interface ApiDealDetailResponse {
  dealId: string;
  dealName: string;
  slaStatus: string;
  lastUpdated: string;
  currentStage: string;
  currentStageLabel: string;
  stages: ApiDealDetailStage[];
  reviewer: {
    name: string;
    department: string;
    avatarUrl: string | null;
  };
  overview: {
    companyOverview: string;
    projectOverview: string;
  };
  investmentDetails: {
    status: string;
    dealOwner: string;
    assetType: string;
    firmSizeSqm: number | null;
    firmSizeLabel: string | null;
    dealCapex: { amount: number; currency: string; label: string };
    qfzCapex: { amount: number; currency: string; label: string };
  };
  investmentStatusUpdate: {
    status: string;
    currentSituation: string;
    actionCategory: string | null;
    actionableNextStep: string | null;
    keyChallenges: string | null;
  };
  actionableNextSteps: {
    targetDate: string;
    steps: string[];
    source: string | null;
  };
  milestones: {
    lastContactWithInvestor: string;
    nextContactWithInvestor: string;
    completionDateOfPreviousStage: string;
    targetDateToNextStage: string;
    targetDateToL3OrL4: string;
  };
  notes: string;
}

// ─── Filters API (GET dashboard/filters) ──────────────────────────────────

export interface ApiFilterOption {
  id: string;
  label: string;
  name: string | null;
}

export interface ApiInvestmentValueRange {
  id: string;
  label: string;
  min: number;
  max: number | null;
}

export interface ApiFiltersResponse {
  departments: ApiFilterOption[];
  stages: ApiFilterOption[];
  statuses: ApiFilterOption[];
  priorities: ApiFilterOption[];
  investmentValueRanges: ApiInvestmentValueRange[];
  timePeriods: ApiFilterOption[];
}

// ─── Pipeline details API (GET pipeline/details) ───────────────────────────

export interface PipelineDetailsRequest {
  stage: string;
  page: number;
  limit: number;
}

export interface ApiPipelineDetailsDeal {
  dealId: string;
  dealName: string;
  ownerName: string;
  ownerAvatar: string | null;
  capexAmount: number;
  capexCurrency: string;
  capexLabel: string;
  currentStage: string;
  currentStageLabel: string;
  forecastDate: string;
  dealStatus: string;
  landSizeSqm: number | null;
  powerDemandMw: number | null;
}

export interface ApiPipelineDetailsResponse {
  stage: string;
  stageLabel: string;
  subLabel: string;
  lastUpdated: string;
  summaryMetrics: {
    pipelineValue: number;
    pipelineValueLabel: string;
    target: number;
    targetLabel: string;
    progressPercentage: number;
  };
  deals: ApiPipelineDetailsDeal[];
  pagination: {
    totalItems: number;
    totalPages: number;
    currentPage: number;
    itemsPerPage: number;
  };
}
