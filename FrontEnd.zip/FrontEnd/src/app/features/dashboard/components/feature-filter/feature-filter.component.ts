import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  signal,
  inject,
  Output,
  EventEmitter,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { DatePickerModule } from 'primeng/datepicker';
import { SharedDialogComponent } from '@shared/components/shared-dialog/shared-dialog.component';
import { DashboardFacadeService } from '@features/dashboard/services/facade/dashboard-facade.service';

export interface FilterValues {
  dateFrom: Date | null;
  dateTo: Date | null;
  stage: string | null;
  status: string | null;
  department: string | null;
  priority: string | null;
  investmentValue: string | null;
}

@Component({
  selector: 'app-feature-filter',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './feature-filter.component.html',
  styleUrl: './feature-filter.component.css',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ButtonModule,
    SelectModule,
    DatePickerModule,
    SharedDialogComponent,
  ],
})
export class FeatureFilterComponent implements OnInit {
  @Output() filtersApplied  = new EventEmitter<FilterValues>();
  @Output() filtersCleared  = new EventEmitter<void>();

  private readonly fb     = inject(FormBuilder);
  readonly facade         = inject(DashboardFacadeService);

  readonly dialogVisible = signal(false);

  filterForm!: FormGroup;

  ngOnInit(): void {
    this.facade.loadFilters();
    this.filterForm = this.fb.group({
      timePeriod:      [null],
      stage:           [null],
      status:          [null],
      department:      [null],
      priority:        [null],
      investmentValue: [null],
    });
  }

  openDialog(): void {
    this.dialogVisible.set(true);
  }

  clearFilters(): void {
    this.filterForm.reset();
    this.filtersCleared.emit();
    this.dialogVisible.set(false);
  }

  applyFilters(): void {
    const { timePeriod, ...rest } = this.filterForm.value;
    this.filtersApplied.emit({
      dateFrom: (timePeriod as Date) ?? null,
      dateTo:   null,
      ...rest,
    });
    this.dialogVisible.set(false);
  }

  get hasActiveFilters(): boolean {
    return Object.values(this.filterForm?.value ?? {}).some((v) => v !== null);
  }
}
