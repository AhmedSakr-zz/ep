import {
  Component,
  ChangeDetectionStrategy,
  signal,
  inject,
} from "@angular/core";
import { TableModule } from "primeng/table";
import { BadgeComponent } from "@shared/components/badge/badge.component";
import { PaginationComponent } from "@shared/components/pagination/pagination.component";
import { DealItem } from "../../models/dashboard.model";
import { DashboardFacadeService } from "../../services/facade/dashboard-facade.service";
import { DealDetailModalComponent } from "../deal-detail-modal/deal-detail-modal.component";

@Component({
  selector: "app-deals-table",
  standalone: true,
  imports: [
    TableModule,
    BadgeComponent,
    PaginationComponent,
    DealDetailModalComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrl: "./deals-table.component.css",
  templateUrl: "./deals-table.component.html",
})
export class DealsTableComponent {
  readonly facade = inject(DashboardFacadeService);

  readonly modalVisible = signal(false);

  readonly pagedRows  = this.facade.dealsData;
  readonly totalPages = this.facade.dealsTotalPages;
  readonly page       = this.facade.dealsPageIndex;

  onPageChange(pageIndex: number): void {
    this.facade.loadDeals(pageIndex + 1);
  }

  onViewDeal(deal: DealItem): void {
    this.modalVisible.set(true);
    this.facade.loadDealDetail(deal.id);
  }

  onModalClose(): void {
    this.modalVisible.set(false);
    this.facade.clearDealDetail();
  }
}
