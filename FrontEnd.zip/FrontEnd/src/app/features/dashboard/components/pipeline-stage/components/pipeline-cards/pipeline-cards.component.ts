import { NgClass } from "@angular/common";
import { Component, Input, output } from "@angular/core";
import { PipelineStage } from "@features/dashboard/models/dashboard.model";

const STAGE_STYLES: Record<
  string,
  { bgClass: string; countColorClass: string }
> = {
  L1: {
    bgClass: "bg-[#f4f7fc] hover:bg-[#ebf0fa] border-slate-100",
    countColorClass: "text-[#1e3a8a]",
  },
  L2: {
    bgClass: "bg-[#f4faf7] hover:bg-[#e6f5ee] border-slate-100",
    countColorClass: "text-[#15803d]",
  },
  L3: {
    bgClass: "bg-[#faf8f4] hover:bg-[#f5eeda] border-slate-100",
    countColorClass: "text-[#a16207]",
  },
  L4: {
    bgClass: "bg-[#f4fafb] hover:bg-[#e3f4f6] border-slate-100",
    countColorClass: "text-[#047857]",
  },
  L5: {
    bgClass: "bg-[#f6f4fc] hover:bg-[#eee9fa] border-slate-100",
    countColorClass: "text-[#4338ca]",
  },
};
const DEFAULT_STYLE = {
  bgClass: "bg-slate-50 hover:bg-slate-100 border-slate-100",
  countColorClass: "text-slate-700",
};

@Component({
  selector: "app-pipeline-cards",
  templateUrl: "./pipeline-cards.component.html",
  styleUrls: ["./pipeline-cards.component.css"],
  imports: [NgClass],
  standalone: true,
})
export class PipelineCardsComponent {
  @Input({ required: true }) stages!: PipelineStage[];
  @Input() total = 0;
  @Input() value = "";
  formattingStrategies = [
    { threshold: 1_000_000_000, suffix: "B", divisor: 1_000_000_000 },
    { threshold: 1_000_000, suffix: "M", divisor: 1_000_000 },
    { threshold: 1_000, suffix: "K", divisor: 1_000 },
  ];
  readonly onOpenModal = output<string>();
  readonly stageSelected = output<string>();

  get displayCards() {
    return this.stages.map((s) => ({
      ...s,
      ...(STAGE_STYLES[s.code] ?? DEFAULT_STYLE),
    }));
  }
  formatNumber(value: number): string {
    // Find the first matching strategy (checking largest to smallest)
    const strategy = this.formattingStrategies.find((s) => value >= s.threshold);

    // If a strategy matches, divide and format it. Otherwise, return the raw rounded number.
    return strategy
      ? (value / strategy.divisor).toFixed(2) + strategy.suffix
      : value.toFixed(2);
  }
  openModal(code: string): void {
    this.onOpenModal.emit(code);
  }

  protected formatChange(change: number): string {
    if (change > 0) return `↑ ${change} vs`;
    if (change < 0) return `↓ ${Math.abs(change)} vs`;
    return `- ${change} vs`;
  }
}
