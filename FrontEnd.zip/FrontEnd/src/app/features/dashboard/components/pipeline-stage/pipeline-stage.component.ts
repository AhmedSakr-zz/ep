import {
  Component,
  Input,
  ChangeDetectionStrategy,
  signal,
  output,
} from "@angular/core";
import { PipelineStage } from "../../models/dashboard.model";
import { PipelineDetailsModalComponent } from "../pipeline-details-modal/pipeline-details-modal.component";
import { PipelineChartComponent } from "../pipeline-chart/pipeline-chart.component";
import { PipelineCardsComponent } from "./components/pipeline-cards/pipeline-cards.component";
export interface PipelineCardMetric {
  code: "L1" | "L2" | "L3" | "L4" | "L5";
  name: string;
  count: number;
  change: number;
  score: number;
  // Specific styling hooks to match the unique colors of each card in the snapshot
  bgClass: string;
  countColorClass: string;
}
@Component({
  selector: "app-pipeline-stage",
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    PipelineDetailsModalComponent,
    PipelineChartComponent,
    PipelineCardsComponent,
  ],
  templateUrl: "./pipeline-stage.component.html",
  styleUrl: "./pipeline-stage.component.css",
})
export class PipelineStageComponent {
  @Input({ required: true }) stages!: PipelineStage[];
  @Input() total = 0;
  @Input() value = "";
  showChart = signal<boolean>(false);
  showCards = signal<boolean>(true);

  readonly selectedStageCode = signal<string>('');
  readonly modalVisible = signal(false);

  openModal(code: string): void {    
    this.selectedStageCode.set(code);
    this.modalVisible.set(true);
  }

  // Output event to notify the parent component (e.g., to open your modal)
  readonly stageSelected = output<string>();

  // Mocking the raw metric data matching your image perfectly
  readonly cards = signal<PipelineCardMetric[]>([
    {
      code: "L1",
      name: "Application Submission",
      count: 21,
      change: 3,
      score: 5.07,
      bgClass: "bg-[#f4f7fc] hover:bg-[#ebf0fa] border-slate-100",
      countColorClass: "text-[#1e3a8a]", // Dark Indigo Blue
    },
    {
      code: "L2",
      name: "Application Approved",
      count: 14,
      change: 2,
      score: 0.56,
      bgClass: "bg-[#f4faf7] hover:bg-[#e6f5ee] border-slate-100",
      countColorClass: "text-[#15803d]", // Emerald Green
    },
    {
      code: "L3",
      name: "License Granted",
      count: 14,
      change: 1,
      score: 0.87,
      bgClass: "bg-[#faf8f4] hover:bg-[#f5eeda] border-slate-100",
      countColorClass: "text-[#a16207]", // Warm Amber Brown
    },
    {
      code: "L4",
      name: "Construction Started",
      count: 9,
      change: 0,
      score: 0.98,
      bgClass: "bg-[#f4fafb] hover:bg-[#e3f4f6] border-slate-100",
      countColorClass: "text-[#047857]", // Teal Dark Green
    },
    {
      code: "L5",
      name: "Construction Completed",
      count: 9,
      change: 1,
      score: 0.77,
      bgClass: "bg-[#f6f4fc] hover:bg-[#eee9fa] border-slate-100",
      countColorClass: "text-[#4338ca]", // Indigo Purple
    },
  ]);

  onCardClick(code: string): void {
    this.stageSelected.emit(code);
  }

  // Format utility method matching your dashboard logic
  protected formatChange(change: number): string {
    if (change > 0) return `↑ ${change} vs`;
    if (change < 0) return `↓ ${Math.abs(change)} vs`;
    return `- ${change} vs`;
  }
  showPipelineChart() {
    if (this.showChart()) return; 
    this.showChart.set(true);
    this.showCards.set(false);
  }
  showPipelineCards() {
    if (this.showCards()) return; 
    this.showChart.set(false);
    this.showCards.set(true);
  }
}
