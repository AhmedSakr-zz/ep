import {
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  ChangeDetectionStrategy,
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { ChartModule } from "primeng/chart";
import { PipelineStage } from "@features/dashboard/models/dashboard.model";

@Component({
  selector: "app-pipeline-chart",
  standalone: true,
  imports: [CommonModule, ChartModule],
  templateUrl: "./pipeline-chart.component.html",
  styleUrl: "./pipeline-chart.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PipelineChartComponent implements OnChanges {
  @Input({ required: true }) stages!: PipelineStage[];

  chartData: any;
  chartOptions: any;
  formattingStrategies = [
    { threshold: 1_000_000_000, suffix: "B", divisor: 1_000_000_000 },
    { threshold: 1_000_000, suffix: "M", divisor: 1_000_000 },
    { threshold: 1_000, suffix: "K", divisor: 1_000 },
  ];
  ngOnChanges(changes: SimpleChanges): void {
    if (changes["stages"] && this.stages?.length) {
      this.buildChartConfig();
    }
  }
  formatNumber(value: number): string {
    // Find the first matching strategy (checking largest to smallest)
    const strategy = this.formattingStrategies.find(
      (s) => value >= s.threshold,
    );

    // If a strategy matches, divide and format it. Otherwise, return the raw rounded number.
    return strategy
      ? (value / strategy.divisor).toFixed(2) + strategy.suffix
      : value.toFixed(2);
  }
  private buildChartConfig(): void {
    const s = this.stages;
    const maxScore = Math.max(...s.map((x) => x.score), 1);
    const yMax = Math.ceil(maxScore * 1.2 * 10) / 10;

    this.chartData = {
      labels: s.map((x) => `${x.code} (${x.name})`),
      datasets: [
        {
          data: s.map((x) => x.score),
          backgroundColor: "#e6f0fa",
          hoverBackgroundColor: "#dbeafe",
          borderWidth: 0,
          borderRadius: 6,
          barPercentage: 0.55,
          categoryPercentage: 0.85,
        },
      ],
    };    
    this.chartOptions = {
      maintainAspectRatio: false,
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#1e293b",
          titleFont: { family: "Montserrat", size: 12, weight: "600" },
          bodyFont: { family: "Montserrat", size: 11 },
          padding: 10,
          callbacks: {
            label: (context: any) => {
              const stage = s[context.dataIndex];
              return ` Score: ${this.formatNumber(context.raw)} | Deals: ${stage.count}`;
            },
          },
        },
      },
      layout: { padding: { bottom: 20 } },
      scales: {
        x: {
          ticks: {
            color: "#94a3b8",
            font: { family: "Montserrat", size: 11, weight: "500" },
            padding: 8,
          },
          grid: { display: false },
        },
        y: {
          min: 0,
          max: yMax,
          ticks: { display: false },
          grid: { color: "#f8fafc", drawTicks: false },
          border: { display: false },
        },
      },
      animation: {
        onComplete: (animation: any) => {
          const chart = animation.chart;
          const ctx = chart.ctx;

          chart.getDatasetMeta(0).data.forEach((bar: any, idx: number) => {
            const stage = s[idx];

            ctx.font = "bold 13px 'Montserrat', sans-serif";
            ctx.fillStyle = "#1e293b";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            const barHeight = bar.base - bar.y;
            const centerY = bar.y + barHeight / 2;
            ctx.fillText(this.formatNumber(stage.score), bar.x, centerY);

            ctx.font = "bold 12px 'Montserrat', sans-serif";
            ctx.textBaseline = "top";
            ctx.fillText(stage.count.toString(), bar.x, bar.base + 34);
          });
        },
      },
    };    
  }
}
