import {
  Component,
  Input,
  Output,
  EventEmitter,
  ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MeterGroupModule, MeterItem } from 'primeng/metergroup';
import { SharedDialogComponent } from '@shared/components/shared-dialog/shared-dialog.component';
import { BadgeComponent } from '@shared/components/badge/badge.component';
import { DealDetail } from '../../models/dashboard.model';

@Component({
  selector: 'app-deal-detail-modal',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MeterGroupModule, SharedDialogComponent, BadgeComponent, DatePipe],
  templateUrl: './deal-detail-modal.component.html',
})
export class DealDetailModalComponent {
  @Input() visible = false;
  @Output() visibleChange = new EventEmitter<boolean>();
  @Input() deal: DealDetail | null = null;
  @Input() loading = false;

  @Output() dialogShow = new EventEmitter<void>();

  get stageMeterItems(): MeterItem[][] {
    if (!this.deal) return [];
    const { currentStageIndex: idx } = this.deal;
    return this.deal.pipelineStages.map((_, i) => [{
      label: '',
      value: 100,
      color: i < idx  ? '#10b981'
           : i === idx ? '#2563eb'
           : '#e2e8f0',
    }]);
  }
}
