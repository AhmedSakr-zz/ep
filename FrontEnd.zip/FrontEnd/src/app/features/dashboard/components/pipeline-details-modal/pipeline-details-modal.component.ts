import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  ChangeDetectionStrategy,
  signal,
  inject,
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { SelectModule } from "primeng/select";
import { ButtonModule } from "primeng/button";
import { TableModule } from "primeng/table";
import { SharedDialogComponent } from "@shared/components/shared-dialog/shared-dialog.component";
import { PaginationComponent } from "@shared/components/pagination/pagination.component";
import { PipelineStage, ApiPipelineDetailsDeal } from "../../models/dashboard.model";
import { DealDetailModalComponent } from "../deal-detail-modal/deal-detail-modal.component";
import { DashboardFacadeService } from "../../services/facade/dashboard-facade.service";

@Component({
  selector: "app-pipeline-details-modal",
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: "./pipeline-details-modal.component.html",
  styleUrl: "./pipeline-details-modal.component.css",
  imports: [
    CommonModule,
    FormsModule,
    SelectModule,
    ButtonModule,
    TableModule,
    SharedDialogComponent,
    PaginationComponent,
    DealDetailModalComponent,
  ],
})
export class PipelineDetailsModalComponent implements OnChanges {
  @Input({ required: true }) stages!: PipelineStage[];
  @Input() initialStageCode: string= '';
  @Input() visible = false;
  @Output() visibleChange = new EventEmitter<boolean>();

  readonly facade = inject(DashboardFacadeService);

  readonly dealModalVisible = signal(false);
  selectedStageCode: string= '';

  get stageOptions() {
    return this.stages.map(s => ({ label: `${s.code} (${s.name})`, value: s.code }));
  }

  get data() {
    return this.facade.pipelineDetailsData();
  }

  get deals(): ApiPipelineDetailsDeal[] {
    return this.data?.deals ?? [];
  }

  get lastUpdatedLabel(): string {
    const raw = this.data?.lastUpdated;
    if (!raw) return '';
    try {
      return new Date(raw).toLocaleString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric',
        hour: '2-digit', minute: '2-digit',
      });
    } catch {
      return raw;
    }
  }

  dealStatusLabel(status: string): string {
    return status === 'ACTIVE' ? 'Active' : 'Pending';
  }

  circleDash(pct: number): string {
    return `${pct} ${100 - pct}`;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['visible']?.currentValue === true || changes['initialStageCode']) {
      if (this.visible) {
        this.selectedStageCode = this.initialStageCode;
        this.facade.loadPipelineDetails(this.selectedStageCode ?? 'L1', 1);
      }
    }
    if (!this.visible) {
      this.facade.clearPipelineDetails();
    }
  }

  onStageChange(): void {
    this.facade.loadPipelineDetails(this.selectedStageCode ?? 'L1', 1);
  }

  onPageChange(pageIndex: number): void {
    this.facade.loadPipelineDetails(this.selectedStageCode ?? 'L1', pageIndex + 1);
  }

  openViewDetails(deal: ApiPipelineDetailsDeal): void {
    this.facade.loadDealDetail(deal.dealId);
    this.dealModalVisible.set(true);
  }

  onDealModalClose(): void {
    this.dealModalVisible.set(false);
    this.facade.clearDealDetail();
  }
}
