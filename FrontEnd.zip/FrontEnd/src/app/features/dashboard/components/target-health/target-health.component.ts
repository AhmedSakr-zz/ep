import {
  Component,
  Input,
  OnDestroy,
  ElementRef,
  viewChild,
  afterNextRender,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  inject
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { Chart, DoughnutController, ArcElement, Tooltip } from "chart.js";
import { TargetHealth } from "../../models/dashboard.model";

Chart.register(DoughnutController, ArcElement, Tooltip);

const FONT = "'Montserrat', system-ui, sans-serif";

export interface TargetHealthData {
  l3: TargetHealth;
  l4: TargetHealth;
}

@Component({
  selector: "app-target-health",
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: "./target-health.component.html",
})
export class TargetHealthComponent implements OnDestroy {
  private cdr = inject(ChangeDetectorRef);
  private _data?: TargetHealthData;
  private _activeTab: 'L3' | 'L4' = 'L3';
  private chartInstance?: Chart;
  private hasRendered = false;
  private observer?: IntersectionObserver;
  private isChartBuilt = false;

  @Input() set activeTab(v: 'L3' | 'L4') {
    this._activeTab = v;
    if (this.hasRendered && this.isChartBuilt) {
      this.refreshChart();
      this.cdr.detectChanges();
    }
  }

  @Input() set health(v: TargetHealthData | undefined) {
    this._data = v;
    if (this.hasRendered && this.isChartBuilt) {
      this.refreshChart();
      this.cdr.detectChanges();
    }
  }

  get activeHealth(): TargetHealth | undefined {
    return this._activeTab === 'L3' ? this._data?.l3 : this._data?.l4;
  }

  readonly canvasRef = viewChild.required<ElementRef<HTMLCanvasElement>>("chart");

  constructor() {
    afterNextRender(() => {
      this.hasRendered = true;
      this.setupIntersectionObserver();
    });
  }

  private setupIntersectionObserver(): void {
    try {
      const element = this.canvasRef().nativeElement;
      this.observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              this.isChartBuilt = true;
              setTimeout(() => {
                this.refreshChart();
                this.cdr.detectChanges();
              }, 150);
              this.observer?.disconnect();
            }
          });
        },
        { threshold: 0.10 }
      );
      this.observer.observe(element);
    } catch {
      this.refreshChart();
      this.cdr.detectChanges();
    }
  }

  get metricRows() {
    const h = this.activeHealth;
    if (!h) return [];
    return [
      { label: "Current Progress", value: h.currentProgress, danger: false },
      { label: "Annual Target",    value: h.annualTarget,    danger: false },
      { label: "Pipeline Value", value: h.forecastedValue, danger: false },
      { label: "Remaining Gap",    value: h.remainingGap,    danger: true  },
    ];
  }

  private refreshChart(): void {
    const h = this.activeHealth;
    if (!h) return;
    try {
      const canvas = this.canvasRef().nativeElement;
      this.chartInstance?.destroy();

      const achieved  = h.achievedPct;
      const remaining = 100 - achieved;

      this.chartInstance = new Chart(canvas, {
        type: "doughnut",
        data: {
          labels: ["Achieved", "Remaining"],
          datasets: [{
            data:            [achieved, remaining],
            backgroundColor: ["#0048B5", "#F0F0F0"],
            borderWidth:     0,
            hoverOffset:     0,
            borderRadius:    [15, 0],
          }],
        },
        options: {
          responsive:          true,
          maintainAspectRatio: false,
          resizeDelay:         50,
          cutout:              "76%",
          plugins: {
            legend: { display: false },
            tooltip: {
              enabled:   true,
              titleFont: { family: FONT, size: 12, weight: "bold" },
              bodyFont:  { family: FONT, size: 11 },
              callbacks: {
                label: (ctx) => ` ${ctx.label}: ${(ctx.parsed as number).toFixed(1)}%`,
              },
            },
          },
          animation: { animateRotate: true, duration: 800 },
        },
      });
    } catch {
      /* canvas not ready */
    }
  }

  formatValue(v: number): string {
    if (v >= 1e9) return `${(v / 1e9).toFixed(2)}B QAR`;
    if (v >= 1e6) return `${(v / 1e6).toFixed(2)}M QAR`;
    if (v >= 1e3) return `${(v / 1e3).toFixed(0)}K QAR`;
    return `${String(v)} QAR`;
  }

  ngOnDestroy(): void {
    this.observer?.disconnect();
    this.chartInstance?.destroy();
  }
}
