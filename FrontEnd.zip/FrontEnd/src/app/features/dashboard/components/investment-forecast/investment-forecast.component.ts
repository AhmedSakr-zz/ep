import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  inject,
} from "@angular/core";
import { CommonModule } from "@angular/common";
import { ChartModule } from "primeng/chart";
import {
  ForecastQuarterWithStatus,
  StatusBreakdown,
} from "../../models/dashboard.model";

// Bottom-to-top render order: problem statuses at base, on-track caps the bar
const STATUS_ORDER = ["delayed", "onTrack"] as const;
type StatusKey = (typeof STATUS_ORDER)[number];

const STATUS_COLORS: Record<StatusKey, string> = {
  delayed: "#FEF0C7",
  onTrack: "#A6F4C5",
};

const STATUS_LABELS: Record<StatusKey, string> = {
  delayed: "Delayed",
  onTrack: "On Track",
};

interface SummaryKpi {
  title: string;
  value: string;
  colorClass: string;
}

@Component({
  selector: "app-investment-forecast",
  standalone: true,
  imports: [CommonModule, ChartModule],
  templateUrl: "./investment-forecast.component.html",
  styleUrl: "./investment-forecast.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InvestmentForecastComponent implements OnChanges {
  @Input() pipelineL3 = "";
  @Input() pipelineL4 = "";
  @Input() actualL3 = "";
  @Input() actualL4 = "";
  @Input() quarters: ForecastQuarterWithStatus[] = [];

  private readonly cdr = inject(ChangeDetectorRef);

  @Output() readonly tabChange = new EventEmitter<"L3" | "L4">();

  summaryKpis: SummaryKpi[] = [];
  chartData: any;
  chartOptions: any;
  activeTab: "L3" | "L4" = "L3";

  ngOnChanges(changes: SimpleChanges): void {
    if (
      changes["pipelineL3"] ||
      changes["pipelineL4"] ||
      changes["actualL3"] ||
      changes["actualL4"]
    ) {
      this.summaryKpis = [
        {
          title: "L3 Pipeline Value",
          value: this.pipelineL3,
          colorClass: "text-blue-500",
        },
        {
          title: "L3 Actual Value",
          value: this.actualL3,
          colorClass: "text-blue-500",
        },
      ];
    }
    if (changes["quarters"] && this.quarters.length) {
      this.buildBarChart();
    }
  }

  switchView(mode: "L3" | "L4"): void {
    this.activeTab = mode;
    this.tabChange.emit(mode);
    if (this.quarters?.length) {
      this.buildBarChart();
      this.cdr.markForCheck();
    }
    switch (this.activeTab) {
      case "L3":
        this.summaryKpis = [
          {
            title: "L3 Pipeline Value",
            value: this.pipelineL3,
            colorClass: "text-blue-500",
          },
          {
            title: "L3 Actual Value",
            value: this.actualL3,
            colorClass: "text-blue-500",
          },
        ];
        break;
      case "L4":
        this.summaryKpis = [
          {
            title: "L4 Pipeline Value",
            value: this.pipelineL4,
            colorClass: "text-blue-700",
          },
          {
            title: "L4 Actual Value",
            value: this.actualL4,
            colorClass: "text-blue-700",
          },
        ];
        break;
    }
  }

  // ── True stacked bar chart ────────────────────────────────────────────────

  private buildBarChart(): void {
    const qs = this.quarters;
    const statusKey = (
      this.activeTab === "L3" ? "l3Status" : "l4Status"
    ) as keyof ForecastQuarterWithStatus;
    const totalKey = (this.activeTab === "L3" ? "l3" : "l4") as "l3" | "l4";

    const tickLabel = (v: number): string => {
      if (v === 0) return "0";
      if (v >= 1e9) return `${(v / 1e9).toFixed(0)}B`;
      if (v >= 1e6) return `${(v / 1e6).toFixed(0)}M`;
      if (v >= 1e3) return `${(v / 1e3).toFixed(0)}k`;
      return String(v);
    };

    // One real value per dataset — Chart.js stacking handles accumulation
    const datasets = STATUS_ORDER.map((status) => ({
      label: STATUS_LABELS[status],
      data: qs.map((q) => (q[statusKey] as StatusBreakdown)[status] ?? 0),
      backgroundColor: STATUS_COLORS[status],
      hoverBackgroundColor: STATUS_COLORS[status],
      borderWidth: 0,
      barPercentage: 0.55,
      categoryPercentage: 0.85,
      borderRadius:
        status === "onTrack"
          ? { topLeft: 4, topRight: 4, bottomLeft: 0, bottomRight: 0 }
          : { topLeft: 0, topRight: 0, bottomLeft: 4, bottomRight: 4 },
      borderSkipped: false,
    }));

    const self = this;

    this.chartData = { labels: qs.map((q) => q.label), datasets };

    this.chartOptions = {
      maintainAspectRatio: false,
      responsive: true,
      layout: { padding: { top: 24, bottom: 10 } },
      plugins: {
        legend: {
          display: true,
          position: "top",
          align: "end",
          labels: {
            color: "#64748b",
            font: { family: "Montserrat", size: 11, weight: "500" },
            boxWidth: 8,
            boxHeight: 8,
            usePointStyle: true,
            pointStyle: "circle",
          },
        },
        tooltip: {
          backgroundColor: "#1e293b",
          titleFont: { family: "Montserrat", size: 12, weight: "600" },
          bodyFont: { family: "Montserrat", size: 11 },
          padding: 10,
          cornerRadius: 6,
          callbacks: {
            label: (ctx: any) =>
              ` ${ctx.dataset.label}: ${ctx.raw as number}%`,
          },
        },
      },
      scales: {
        x: {
          stacked: true,
          ticks: {
            color: "#94a3b8",
            font: { family: "Montserrat", size: 11, weight: "500" },
          },
          grid: { display: false },
        },
        y: {
          stacked: true,
          min: 0,
          ticks: {
            display: true,
            maxTicksLimit: 6,
            color: "#94a3b8",
            font: { family: "Montserrat", size: 11, weight: "500" },
            callback: (value: number) => tickLabel(value),
          },
          grid: { color: "#f1f5f9", drawTicks: false },
          border: { display: false },
        },
      },
      animation: {
        onComplete: ({ chart }: any) => {
          const ctx = chart.ctx;
          ctx.save();
          ctx.font = "bold 11px 'Montserrat', sans-serif";
          ctx.textAlign = "center";
          ctx.textBaseline = "bottom";
          ctx.fillStyle = "#506373";

          qs.forEach((q, idx) => {
            const total = q[totalKey] as number;
            if (total <= 0) return;

            let topY = Infinity;
            let barX = 0;

            for (let di = 0; di < chart.data.datasets.length; di++) {
              const bar = chart.getDatasetMeta(di).data[idx];
              if (!bar) continue;
              barX = bar.x;
              if (bar.y < topY) topY = bar.y;
            }

            if (topY === Infinity) return;
            ctx.fillText(self.formatValue(total), barX, topY - 6);
          });

          ctx.restore();
        },
      },
    };
  }

  formatValue(v: number): string {
    if (v >= 1e9) return `${(v / 1e9).toFixed(2)}B QAR`;
    if (v >= 1e6) return `${(v / 1e6).toFixed(2)}M QAR`;
    if (v >= 1e3) return `${(v / 1e3).toFixed(0)}K QAR`;
    return `${String(v)} QAR`;
  }
}
