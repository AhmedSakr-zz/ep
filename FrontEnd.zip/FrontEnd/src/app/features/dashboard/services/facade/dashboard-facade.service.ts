import { Injectable, inject, signal, computed } from "@angular/core";
import { Subscription } from "rxjs";
import { BadgeStatus } from "@shared/components/badge/badge.component";
import { DashboardHttpService } from "../http/dashboard.service";
import { FilterValues } from "../../components/feature-filter/feature-filter.component";
import {
  DashboardFilters,
  DashboardSummary,
  DealItem,
  DealDetail,
  ApiOverviewResponse,
  ApiDealItem,
  ApiDealDetailResponse,
  ApiPipelineDetailsResponse,
  ApiFiltersResponse,
} from "../../models/dashboard.model";

const SLA_STATUS_MAP: Record<string, BadgeStatus> = {
  DELAYED: "delayed",
  ON_TRACK: "on-track",
  SLA_BREACH: "sla-breach",
  BLOCKED: "blocked",
};

@Injectable({ providedIn: "root" })
export class DashboardFacadeService {
  private readonly http = inject(DashboardHttpService);

  // ── Active filters ────────────────────────────────────────────────────────
  readonly filters = signal<DashboardFilters>({});

  // ── Overview state ────────────────────────────────────────────────────────
  readonly overviewLoading = signal(false);
  readonly overviewData = signal<DashboardSummary | null>(null);
  readonly overviewError = signal<string | null>(null);

  // ── Deals list state ──────────────────────────────────────────────────────
  readonly dealsLoading = signal(false);
  readonly dealsData = signal<DealItem[]>([]);
  readonly dealsTotal = signal(0);
  readonly dealsTotalPages = signal(0);
  readonly dealsCurrentPage = signal(1);
  readonly dealsError = signal<string | null>(null);

  // 0-indexed page alias for the pagination component
  readonly dealsPageIndex = computed(() => this.dealsCurrentPage() - 1);

  // ── Deal detail state ─────────────────────────────────────────────────────
  readonly dealDetailLoading = signal(false);
  readonly dealDetailData = signal<DealDetail | null>(null);
  readonly dealDetailError = signal<string | null>(null);

  // ── Filters state (dropdown options + date bounds) ────────────────────────
  readonly filtersLoading = signal(false);
  readonly filtersData = signal<ApiFiltersResponse | null>(null);

  readonly stageOptions = computed(() =>
    (this.filtersData()?.stages ?? []).map((s) => ({
      label: s.label,
      value: s.id,
    })),
  );
  readonly statusOptions = computed(() =>
    (this.filtersData()?.statuses ?? []).map((s) => ({
      label: s.label,
      value: s.id,
    })),
  );
  readonly departmentOptions = computed(() =>
    (this.filtersData()?.departments ?? []).map((d) => ({
      label: d.label,
      value: d.id,
    })),
  );
  readonly priorityOptions = computed(() =>
    (this.filtersData()?.priorities ?? []).map((p) => ({
      label: p.label,
      value: p.id,
    })),
  );
  readonly investmentValueOptions = computed(() =>
    (this.filtersData()?.investmentValueRanges ?? []).map((r) => ({
      label: r.label,
      value: r.id,
    })),
  );

  readonly filterMinDate = computed<Date | null>(() => {
    const periods = this.filtersData()?.timePeriods;
    if (!periods?.length) return null;
    const minYear = Math.min(...periods.map((p) => parseInt(p.id, 10)));
    return isNaN(minYear) ? null : new Date(minYear, 0, 1);
  });
  readonly filterMaxDate = computed<Date | null>(() => {
    const periods = this.filtersData()?.timePeriods;
    if (!periods?.length) return null;
    const maxYear = Math.max(...periods.map((p) => parseInt(p.id, 10)));
    return isNaN(maxYear) ? null : new Date(maxYear, 11, 31);
  });

  // ── Pipeline details state ────────────────────────────────────────────────
  readonly pipelineDetailsLoading = signal(false);
  readonly pipelineDetailsData = signal<ApiPipelineDetailsResponse | null>(
    null,
  );
  readonly pipelineDetailsError = signal<string | null>(null);
  readonly pipelineDetailsPage = signal(1);
  readonly pipelineDetailsTotalPages = computed(
    () => this.pipelineDetailsData()?.pagination.totalPages ?? 0,
  );
  readonly pipelineDetailsPageIndex = computed(
    () => this.pipelineDetailsPage() - 1,
  );

  private filtersSub: Subscription | null = null;
  private overviewSub: Subscription | null = null;
  private dealsSub: Subscription | null = null;
  private dealDetailSub: Subscription | null = null;
  private pipelineDetailsSub: Subscription | null = null;

  // ── Public API ────────────────────────────────────────────────────────────

  loadFilters(): void {
    if (this.filtersData()) return;
    this.filtersSub?.unsubscribe();
    this.filtersLoading.set(true);
    this.filtersSub = this.http.getFilters().subscribe({
      next: (res) => {
        this.filtersData.set(res);
        this.filtersLoading.set(false);
      },
      error: () => this.filtersLoading.set(false),
    });
  }

  applyFilters(filterValues: FilterValues): void {
    const mapped = this.mapFilterValues(filterValues);
    this.filters.set(mapped);
    this.loadOverview(mapped);
    this.loadDeals(1, mapped);
  }

  applyQuickFilters(
    departmentId: string | null,
    stageId: string | null,
    timePeriod: string | null,
  ): void {
    const filters: DashboardFilters = {};
    if (departmentId) filters.departmentId = departmentId;
    if (stageId) filters.stage = stageId;
    if (timePeriod) filters.timePeriod = timePeriod;
    this.filters.set(filters);
    this.loadOverview(filters);
    this.loadDeals(1, filters);
  }

  loadOverview(filters: DashboardFilters = this.filters()): void {
    this.overviewSub?.unsubscribe();
    this.overviewLoading.set(true);
    this.overviewError.set(null);

    this.overviewSub = this.http.getOverview(filters).subscribe({
      next: (res) => {
        this.overviewData.set(this.mapOverview(res));
        this.overviewLoading.set(false);
      },
      error: () => {
        this.overviewError.set("Failed to load dashboard data.");
        this.overviewLoading.set(false);
      },
    });
  }

  loadDeals(page: number, filters: DashboardFilters = this.filters()): void {
    this.dealsSub?.unsubscribe();
    this.dealsLoading.set(true);
    this.dealsError.set(null);
    this.dealsCurrentPage.set(page);

    this.dealsSub = this.http
      .getDeals({ page, limit: 5, ...filters })
      .subscribe({
        next: (res) => {
          this.dealsData.set(this.mapDeals(res.data));
          this.dealsTotal.set(res.pagination.totalItems);
          this.dealsTotalPages.set(res.pagination.totalPages);
          this.dealsLoading.set(false);
        },
        error: () => {
          this.dealsError.set("Failed to load deals.");
          this.dealsLoading.set(false);
        },
      });
  }

  loadDealDetail(dealId: string): void {
    this.dealDetailSub?.unsubscribe();
    this.dealDetailLoading.set(true);
    this.dealDetailData.set(null);
    this.dealDetailError.set(null);

    this.dealDetailSub = this.http.getDealDetail(dealId).subscribe({
      next: (res) => {
        this.dealDetailData.set(this.mapDealDetail(res));
        this.dealDetailLoading.set(false);
      },
      error: () => {
        this.dealDetailError.set("Failed to load deal details.");
        this.dealDetailLoading.set(false);
      },
    });
  }

  clearDealDetail(): void {
    this.dealDetailSub?.unsubscribe();
    this.dealDetailData.set(null);
    this.dealDetailError.set(null);
    this.dealDetailLoading.set(false);
  }

  loadPipelineDetails(stage: string, page: number): void {
    this.pipelineDetailsSub?.unsubscribe();
    this.pipelineDetailsLoading.set(true);
    this.pipelineDetailsError.set(null);
    this.pipelineDetailsPage.set(page);

    this.pipelineDetailsSub = this.http
      .getPipelineDetails({ stage, page, limit: 5 })
      .subscribe({
        next: (res) => {
          this.pipelineDetailsData.set(res);
          this.pipelineDetailsLoading.set(false);
        },
        error: () => {
          this.pipelineDetailsError.set("Failed to load pipeline details.");
          this.pipelineDetailsLoading.set(false);
        },
      });
  }

  clearPipelineDetails(): void {
    this.pipelineDetailsSub?.unsubscribe();
    this.pipelineDetailsData.set(null);
    this.pipelineDetailsError.set(null);
    this.pipelineDetailsLoading.set(false);
    this.pipelineDetailsPage.set(1);
  }

  // ── Mappers ───────────────────────────────────────────────────────────────

  private mapFilterValues(f: FilterValues): DashboardFilters {
    const out: DashboardFilters = {};
    if (f.stage) out.stage = f.stage;
    if (f.status) out.status = f.status;
    if (f.department) out.departmentId = f.department;
    if (f.investmentValue) out.investmentValueRangeId = f.investmentValue;
    if (f.dateFrom) out.timePeriod = String(f.dateFrom.getFullYear());
    return out;
  }

  private mapOverview(res: ApiOverviewResponse): DashboardSummary {
    const {
      keyMetrics: m,
      pipeline: p,
      investmentValueForecast: f,
      targetHealth: t,
    } = res;
    return {
      l3Value: m.l3VsTarget.valueLabel.replace("$", ""),
      l3Currency: m.l3VsTarget.currency,
      l3Progress: m.l3VsTarget.percentage,
      l3Target: m.l3VsTarget.targetLabel.replace("$", ""),
      l3Change: `+${m.l3VsTarget.growthVsLastQuarter}% vs last quarter`,

      l4Value: m.l4VsTarget.valueLabel.replace("$", ""),
      l4currency: m.l4VsTarget.currency,
      l4Progress: m.l4VsTarget.percentage,
      l4Target: m.l4VsTarget.targetLabel.replace("$", ""),
      l4Change: `+${m.l4VsTarget.growthVsLastQuarter}% vs last quarter`,

      licensesCount: m.licensesAchievement.achieved,
      licensesExpiredChange: `${m.licensesAchievement.varianceVsLastQuarter} ${m.licensesAchievement.varianceLabel}`,
      licensesSubtitle: `${m.licensesAchievement.achieved} of ${m.licensesAchievement.target} licenses achieved`,

      dealsActionCount: m.dealsRequiringActions.total,
      dealsBadges: [
        {
          label: `${m.dealsRequiringActions.breachedCount} breached`,
          variant: "danger",
        },
        {
          label: `${m.dealsRequiringActions.atRiskCount} at risk`,
          variant: "warning",
        },
        {
          label: `${m.dealsRequiringActions.pendingCount} pending`,
          variant: "neutral",
        },
      ],

      pipelineTotal: p.totalDeals,
      pipelineValue: p.totalValueLabel.replace("$", "").replace("B", "M"),
      stages: p.stages.map((s: any) => ({
        code: s.stage,
        name: s.label,
        count: s.dealCount,
        change: s.growthCountVsLastMonth,
        score:
          s.stage != "L3" && s.stage != "L4"
            ? 0
            : s.stage == "L3"
              ? m.l3VsTarget.value
              : m.l4VsTarget.value,
      })),

      pipelineL3: f.l3PipelineValue.replace("$", "") + " " + "QAR",
      actualL3: f.l3ActualValue.replace("$", "") + " " + "QAR",
      pipelineL4: f.l4PipelineValue.replace("$", "") + " " + "QAR",
      actualL4: f.l4ActualValue.replace("$", "") + " " + "QAR",
      forecastCombined: f.combinedForecastLabel,
      forecastGrowth: `{f.growthPercentage}% + ' ' + QAR`,
      forecastQuarters: f.quarterlyBreakdown.map((q) => ({
        label: q.quarter,
        l3: q.l3ForecastValue,
        l4: q.l4ForecastValue,
        l3Status: {
          delayed: q.l3ForecastDelayedValue,
          onTrack: q.l3ForecastOnTrackValue,
        },
        l4Status: {
          delayed: q.l4ForecastDelayedValue,
          onTrack: q.l4ForecastOnTrackValue,
        },
      })),

      targetHealth: {
        l3: {
          achievedPct: t.l3.achievedPercentage,
          currentProgress: t.l3.currentProgress,
          annualTarget: t.l3.annualTarget,
          forecastedValue: t.l3.forecastedValue,
          remainingGap: t.l3.remainingGap,
          statusMessage: t.l3.statusText,
        },
        l4: {
          achievedPct: t.l4.achievedPercentage,
          currentProgress: t.l4.currentProgress,
          annualTarget: t.l4.annualTarget,
          forecastedValue: t.l4.forecastedValue,
          remainingGap: t.l4.remainingGap,
          statusMessage: t.l4.statusText,
        },
      },

      deals: [],
      dealsTotal: 0,
    };
  }

  private mapDeals(items: ApiDealItem[]): DealItem[] {
    return items.map((item) => ({
      id: item.dealId,
      dealName: item.dealName,
      type: item.department,
      assignee: item.ownerName,
      stage: item.stage,
      dueDate: item.dueDate,
      daysLeft: item.daysRemaining,
      slaStatus: SLA_STATUS_MAP[item.slaStatus] ?? "pending",
      requiredAction: item.requiredAction,
      requester: item.requester,
      requestNumber: item.requestNumber
    }));
  }

  private mapDealDetail(res: ApiDealDetailResponse): DealDetail {
    const activeIndex = res.stages.findIndex((s) => s.status === "ACTIVE");
    const inv = res.investmentDetails;

    return {
      id: res.dealId,
      dealName: res.dealName,
      slaStatus: SLA_STATUS_MAP[res.slaStatus] ?? "pending",
      lastUpdated: this.formatDate(res.lastUpdated),
      assignee: res.reviewer.name,
      department: res.reviewer.department,
      currentStageIndex: activeIndex >= 0 ? activeIndex : 0,
      pipelineStages: res.stages.map((s) => ({ code: s.stage, name: s.label })),
      companyOverview: res.overview.companyOverview,
      projectOverview: res.overview.projectOverview,
      investmentStatus: inv.status === "Active" ? "Active" : "Pending",
      dealOwner: inv.dealOwner,
      assetType: inv.assetType,
      firmSize: inv.firmSizeLabel ?? "",
      costCapex: inv.dealCapex.label.replace("$", ""),
      gfcCapex: inv.qfzCapex.label,
      investmentStatusUpdates: res.investmentStatusUpdate.map((u) => ({
        status:            u.status,
        currentSituation:  u.currentSituation,
        actionCategory:    u.actionCategory    ?? "",
        actionableNextStep: u.actionableNextStep ?? "",
        keyChallenges:     u.keyChallenges      ?? "",
        lastContactWithInvestor: u.lastContactWithInvestor ?? "",
        nextContactWithInvestor: u.nextContactWithInvestor ?? "",
      })),
      actionableSteps: res.actionableNextSteps.steps,
      actionableStepsDate: res.actionableNextSteps.targetDate,
      milestones: [
        {
          label: "Last contact with investor",
          date: res.milestones.lastContactWithInvestor,
        },
        {
          label: "Next contact with investor",
          date: res.milestones.nextContactWithInvestor,
        },
        {
          label: "Completion date of previous stage",
          date: res.milestones.completionDateOfPreviousStage,
        },
        {
          label: "Target date to next stage",
          date: res.milestones.targetDateToNextStage,
        },
        {
          label: "Target date to L3 or L4",
          date: res.milestones.targetDateToL3OrL4,
        },
      ],
    };
  }

  private formatDate(iso: string): string {
    try {
      return new Date(iso).toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return iso;
    }
  }
}
