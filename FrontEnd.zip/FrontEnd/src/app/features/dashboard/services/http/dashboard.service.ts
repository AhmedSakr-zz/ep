import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '@environments/environment';
import {
  DashboardFilters,
  ApiOverviewResponse,
  DealsRequest,
  ApiDealsResponse,
  ApiDealDetailResponse,
  PipelineDetailsRequest,
  ApiPipelineDetailsResponse,
  ApiFiltersResponse,
} from '@features/dashboard/models/dashboard.model';

@Injectable({ providedIn: 'root' })
export class DashboardHttpService {
  private readonly http = inject(HttpClient);

  getOverview(filters: DashboardFilters = {}): Observable<ApiOverviewResponse> {
    const params = this.toParams(filters);
    return this.http.get<ApiOverviewResponse>(
      `${environment.apiUrl}dashboard/overview`,
      { params },
    );
  }

  getDeals(request: DealsRequest): Observable<ApiDealsResponse> {
    const params = this.toParams(request);
    return this.http.get<ApiDealsResponse>(
      `${environment.apiUrl}deals`,
      { params },
    );
  }

  getDealDetail(dealId: string): Observable<ApiDealDetailResponse> {
    return this.http.get<ApiDealDetailResponse>(
      `${environment.apiUrl}deals/${dealId}`,
    );
  }

  getFilters(): Observable<ApiFiltersResponse> {
    return this.http.get<ApiFiltersResponse>(`${environment.apiUrl}dashboard/filters`);
  }

  getPipelineDetails(request: PipelineDetailsRequest): Observable<ApiPipelineDetailsResponse> {
    const params = this.toParams(request);
    return this.http.get<ApiPipelineDetailsResponse>(
      `${environment.apiUrl}pipeline/details`,
      { params },
    );
  }

  private toParams<T extends object>(obj: T): HttpParams {
    return (Object.entries(obj) as [string, unknown][]).reduce(
      (params, [key, value]) =>
        value != null && value !== '' ? params.set(key, String(value)) : params,
      new HttpParams(),
    );
  }
}
