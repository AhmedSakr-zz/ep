export const environment = {
  production: false,
  apiUrl: 'https://localhost:5162/api/',
};
